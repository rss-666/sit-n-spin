<?php
/**
 * Fallback for all single posts and pages.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="<?php echo esc_attr( pdu_content_offset_class() ); ?>">
	<?php
	while ( have_posts() ) :
		the_post();
		get_template_part( 'template-parts/content/single', get_post_type() );
	endwhile;
	?>
</div>

<?php
get_footer();
