<?php
/**
 * Comments template.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

if ( post_password_required() ) {
	return;
}
?>

<section id="comments" class="mx-auto max-w-3xl border-t border-ink-400 pt-12">

	<?php if ( have_comments() ) : ?>
		<h2 class="text-2xl">
			<?php
			$pdu_count = get_comments_number();
			printf(
				esc_html(
					/* translators: %s: comment count. */
					_n( '%s Response', '%s Responses', $pdu_count, 'plague-dr-universe' )
				),
				esc_html( number_format_i18n( $pdu_count ) )
			);
			?>
		</h2>

		<ol class="mt-8 list-none space-y-6 p-0">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'avatar_size' => 48,
					'short_ping'  => true,
					'callback'    => 'pdu_comment_callback',
				)
			);
			?>
		</ol>

		<?php
		the_comments_pagination(
			array(
				'prev_text' => esc_html__( '&larr; Older', 'plague-dr-universe' ),
				'next_text' => esc_html__( 'Newer &rarr;', 'plague-dr-universe' ),
				'class'     => 'pagination mt-10 flex flex-wrap gap-2',
			)
		);
		?>
	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() ) : ?>
		<p class="notice-pdu mt-8"><?php esc_html_e( 'Comments are closed on this entry.', 'plague-dr-universe' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form(
		array(
			'class_container'    => 'mt-12 border border-ink-400 bg-ink-800 p-6 md:p-8',
			'title_reply_before' => '<h2 class="text-2xl mb-6">',
			'title_reply_after'  => '</h2>',
			'title_reply'        => __( 'Leave a mark', 'plague-dr-universe' ),
			'class_submit'       => 'btn btn-primary',
			'comment_field'      => sprintf(
				'<p class="comment-form-comment"><label for="comment" class="mb-2 block font-display text-xs uppercase tracking-brand text-bone-300">%s</label>
				 <textarea id="comment" name="comment" required></textarea></p>',
				esc_html__( 'Your message', 'plague-dr-universe' )
			),
		)
	);
	?>
</section>
