<?php
/**
 * Site header.
 *
 * Outputs the document head, the skip link, the fixed banner with primary
 * navigation, utility actions (search / account / cart) and the mobile drawer.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<meta name="theme-color" content="#050507">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php // Flip the no-js class before paint to avoid a flash of unstyled state. ?>
	<script>document.documentElement.className=document.documentElement.className.replace(/\bno-js\b/,'js');</script>

	<?php wp_head(); ?>
</head>

<body <?php body_class( 'bg-ink-900 text-bone-200' ); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#main-content">
	<?php esc_html_e( 'Skip to main content', 'plague-dr-universe' ); ?>
</a>

<div id="page" class="site flex min-h-screen flex-col">

	<header id="masthead"
			class="site-header <?php echo is_front_page() ? '' : 'site-header--solid'; ?>"
			data-pdu-header>

		<?php
		/**
		 * Announcement bar. Driven by the Customizer so the client can swap
		 * drop announcements without touching code.
		 */
		$pdu_announce = get_theme_mod(
			'pdu_announcement',
			__( 'New chapter + soundtrack drop — free worldwide shipping on orders over $75', 'plague-dr-universe' )
		);
		if ( $pdu_announce ) :
			?>
			<div class="hidden bg-blood-700 text-center md:block">
				<p class="container py-2 font-display text-[0.7rem] uppercase tracking-wider2 text-bone-50">
					<?php echo esc_html( $pdu_announce ); ?>
				</p>
			</div>
		<?php endif; ?>

		<div class="container">
			<div class="flex h-[4.5rem] items-center justify-between gap-6">

				<?php // ---------- Brand ---------- ?>
				<div class="flex shrink-0 items-center">
					<?php if ( has_custom_logo() ) : ?>
						<?php the_custom_logo(); ?>
					<?php else : ?>
						<a class="brand-mark flex items-center gap-2.5" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<span class="text-blood-500" aria-hidden="true"><?php pdu_the_icon( 'skull', 30 ); ?></span>
							<span class="leading-tight">
								<span class="block text-[0.62rem] tracking-wider2 text-bone-400">
									<?php esc_html_e( 'The', 'plague-dr-universe' ); ?>
								</span>
								<?php esc_html_e( 'Plague', 'plague-dr-universe' ); ?><span>Dr</span>
							</span>
						</a>
					<?php endif; ?>
				</div>

				<?php // ---------- Primary navigation ---------- ?>
				<nav class="hidden lg:block" aria-label="<?php esc_attr_e( 'Primary navigation', 'plague-dr-universe' ); ?>">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'container'      => false,
							'menu_class'     => 'menu-main flex items-center gap-8 list-none m-0 p-0',
							'depth'          => 2,
							'walker'         => new PDU_Walker_Nav_Menu(),
							'fallback_cb'    => 'pdu_fallback_menu',
						)
					);
					?>
				</nav>

				<?php // ---------- Utilities ---------- ?>
				<div class="flex shrink-0 items-center gap-1.5">

					<button type="button"
							class="grid h-11 w-11 place-items-center text-bone-200 transition-colors hover:text-amber-300"
							data-pdu-search-toggle
							aria-expanded="false"
							aria-controls="pdu-search-panel">
						<span class="screen-reader-text"><?php esc_html_e( 'Search', 'plague-dr-universe' ); ?></span>
						<?php pdu_the_icon( 'search', 20 ); ?>
					</button>

					<?php if ( class_exists( 'WooCommerce' ) ) : ?>
						<a class="hidden h-11 w-11 place-items-center text-bone-200 transition-colors hover:text-amber-300 sm:grid"
							href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>">
							<span class="screen-reader-text"><?php esc_html_e( 'My account', 'plague-dr-universe' ); ?></span>
							<?php pdu_the_icon( 'user', 20 ); ?>
						</a>

						<a class="relative grid h-11 w-11 place-items-center text-bone-200 transition-colors hover:text-amber-300"
							href="<?php echo esc_url( wc_get_cart_url() ); ?>"
							data-pdu-cart-link>
							<span class="screen-reader-text"><?php esc_html_e( 'View cart', 'plague-dr-universe' ); ?></span>
							<?php pdu_the_icon( 'cart', 20 ); ?>
							<?php $pdu_count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0; ?>
							<span class="absolute -right-0.5 -top-0.5 grid h-5 min-w-[1.25rem] place-items-center rounded-full bg-blood-600 px-1 font-display text-[0.65rem] leading-none text-white <?php echo $pdu_count ? '' : 'hidden'; ?>"
									data-pdu-cart-count>
								<?php echo esc_html( (string) $pdu_count ); ?>
								<span class="screen-reader-text"><?php esc_html_e( 'items in cart', 'plague-dr-universe' ); ?></span>
							</span>
						</a>
					<?php endif; ?>

					<a class="btn btn-primary btn-sm ml-2 hidden xl:inline-flex"
						href="<?php echo esc_url( pdu_shop_url() ); ?>">
						<?php esc_html_e( 'Enter the Store', 'plague-dr-universe' ); ?>
					</a>

					<button type="button"
							class="burger ml-1"
							data-pdu-drawer-toggle
							aria-expanded="false"
							aria-controls="pdu-drawer">
						<span class="screen-reader-text"><?php esc_html_e( 'Open menu', 'plague-dr-universe' ); ?></span>
						<?php pdu_the_icon( 'menu', 22 ); ?>
					</button>
				</div>
			</div>
		</div>

		<?php // ---------- Slide-down search ---------- ?>
		<div id="pdu-search-panel"
				class="hidden border-t border-ink-400 bg-ink-800/98 backdrop-blur-md"
				data-pdu-search-panel>
			<div class="container py-6">
				<?php get_search_form(); ?>
			</div>
		</div>
	</header>

	<?php // ---------- Mobile drawer ---------- ?>
	<div id="pdu-drawer" class="drawer" data-pdu-drawer aria-hidden="true">
		<div class="container flex min-h-screen flex-col py-6">
			<div class="mb-8 flex items-center justify-between">
				<span class="brand-mark"><?php bloginfo( 'name' ); ?></span>
				<button type="button" class="grid h-11 w-11 place-items-center border border-ink-300 text-bone-100" data-pdu-drawer-close>
					<span class="screen-reader-text"><?php esc_html_e( 'Close menu', 'plague-dr-universe' ); ?></span>
					<?php pdu_the_icon( 'close', 22 ); ?>
				</button>
			</div>

			<nav aria-label="<?php esc_attr_e( 'Mobile navigation', 'plague-dr-universe' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'list-none m-0 p-0 [&_.sub-menu]:pl-4 [&_.sub-menu]:list-none',
						'depth'          => 2,
						'fallback_cb'    => 'pdu_fallback_menu',
					)
				);
				?>
			</nav>

			<div class="mt-auto space-y-5 pt-10">
				<a class="btn btn-primary btn-block" href="<?php echo esc_url( pdu_shop_url() ); ?>">
					<?php esc_html_e( 'Enter the Store', 'plague-dr-universe' ); ?>
				</a>
				<?php pdu_social_links(); ?>
			</div>
		</div>
	</div>

	<main id="main-content" class="site-main flex-1" tabindex="-1">
