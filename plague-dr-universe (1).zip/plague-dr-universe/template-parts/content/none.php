<?php
/**
 * "Nothing found" state.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;
?>

<section class="border border-ink-400 bg-ink-800 p-10 text-center md:p-16">
	<span class="mx-auto mb-6 grid h-16 w-16 place-items-center border border-blood-600/60 text-blood-400">
		<?php pdu_the_icon( 'skull', 30 ); ?>
	</span>

	<h2 class="text-2xl">
		<?php
		if ( is_search() ) {
			esc_html_e( 'Nothing surfaced', 'plague-dr-universe' );
		} else {
			esc_html_e( 'Nothing here yet', 'plague-dr-universe' );
		}
		?>
	</h2>

	<p class="lede mx-auto mt-4 max-w-xl">
		<?php
		if ( is_search() ) {
			esc_html_e( 'The archive came back empty. Try a different word — chapter titles, track names and product names are all searchable.', 'plague-dr-universe' );
		} else {
			esc_html_e( 'This part of the universe has not been published yet. Check back soon, or start with the graphic novel.', 'plague-dr-universe' );
		}
		?>
	</p>

	<div class="mx-auto mt-8 max-w-md">
		<?php get_search_form(); ?>
	</div>

	<div class="mt-8 flex flex-wrap justify-center gap-4">
		<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<?php esc_html_e( 'Back to the homepage', 'plague-dr-universe' ); ?>
		</a>
		<a class="btn btn-ghost" href="<?php echo esc_url( pdu_shop_url() ); ?>">
			<?php esc_html_e( 'Visit the store', 'plague-dr-universe' ); ?>
		</a>
	</div>
</section>
