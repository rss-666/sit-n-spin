<?php
/**
 * Single entry — default layout for posts, pages and any CPT without a
 * dedicated variant.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$pdu_type = get_post_type();

// Meta rows shown under the title, by post type.
$pdu_facts = array();

switch ( $pdu_type ) {
	case 'pdu_chapter':
		$pdu_facts = array_filter(
			array(
				__( 'Chapter', 'plague-dr-universe' )    => get_post_meta( get_the_ID(), 'pdu_chapter_number', true ),
				__( 'Pages', 'plague-dr-universe' )      => get_post_meta( get_the_ID(), 'pdu_page_count', true ),
				__( 'Story arc', 'plague-dr-universe' )  => strip_tags( get_the_term_list( get_the_ID(), 'pdu_arc', '', ', ' ) ),
			)
		);
		break;

	case 'pdu_track':
		$pdu_facts = array_filter(
			array(
				__( 'Album', 'plague-dr-universe' )    => get_post_meta( get_the_ID(), 'pdu_album', true ),
				__( 'Duration', 'plague-dr-universe' ) => get_post_meta( get_the_ID(), 'pdu_duration', true ),
				__( 'Genre', 'plague-dr-universe' )    => strip_tags( get_the_term_list( get_the_ID(), 'pdu_genre', '', ', ' ) ),
			)
		);
		break;

	case 'pdu_artwork':
		$pdu_facts = array_filter(
			array(
				__( 'Year', 'plague-dr-universe' )   => get_post_meta( get_the_ID(), 'pdu_year', true ),
				__( 'Medium', 'plague-dr-universe' ) => get_post_meta( get_the_ID(), 'pdu_dimensions', true ),
			)
		);
		break;

	case 'pdu_video':
		$pdu_facts = array_filter(
			array(
				__( 'Duration', 'plague-dr-universe' ) => get_post_meta( get_the_ID(), 'pdu_duration', true ),
				__( 'Format', 'plague-dr-universe' )   => strip_tags( get_the_term_list( get_the_ID(), 'pdu_video_type', '', ', ' ) ),
			)
		);
		break;
}
?>

<article <?php post_class( 'pdu-single' ); ?>>

	<?php // ---------- Header ---------- ?>
	<header class="relative overflow-hidden border-b border-ink-400 bg-ink-800">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'pdu-hero', array(
				'class'         => 'absolute inset-0 h-full w-full object-cover opacity-30',
				'loading'       => 'eager',
				'fetchpriority' => 'high',
				'alt'           => '',
			) ); ?>
		<?php else : ?>
			<img src="<?php echo esc_url( pdu_img( 'rain-street-noir.jpg' ) ); ?>" alt=""
					class="absolute inset-0 h-full w-full object-cover opacity-25"
					decoding="async" width="1024" height="1024">
		<?php endif; ?>

		<div class="absolute inset-0 bg-gradient-to-r from-ink-900 via-ink-900/90 to-ink-900/50" aria-hidden="true"></div>

		<div class="container relative py-16 md:py-24">
			<?php pdu_breadcrumbs(); ?>

			<div class="max-w-3xl">
				<h1 class="text-display-lg"><?php the_title(); ?></h1>

				<?php if ( 'post' === $pdu_type ) : ?>
					<div class="mt-6"><?php pdu_entry_meta(); ?></div>
				<?php endif; ?>

				<?php if ( has_excerpt() ) : ?>
					<p class="lede mt-6"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>

				<?php if ( $pdu_facts ) : ?>
					<dl class="mt-8 flex flex-wrap gap-x-10 gap-y-4">
						<?php foreach ( $pdu_facts as $label => $value ) : ?>
							<div class="stat">
								<dt class="stat-label"><?php echo esc_html( $label ); ?></dt>
								<dd class="m-0 mt-1 font-display text-lg text-bone-50"><?php echo esc_html( $value ); ?></dd>
							</div>
						<?php endforeach; ?>
					</dl>
				<?php endif; ?>
			</div>
		</div>
	</header>

	<?php // ---------- Media rail ---------- ?>
	<?php
	$pdu_audio = ( 'pdu_track' === $pdu_type ) ? get_post_meta( get_the_ID(), 'pdu_audio_url', true ) : '';
	$pdu_video = ( 'pdu_video' === $pdu_type ) ? get_post_meta( get_the_ID(), 'pdu_video_url', true ) : '';
	?>

	<?php if ( $pdu_audio || $pdu_video ) : ?>
		<div class="border-b border-ink-400 bg-ink-800/60">
			<div class="container py-8">
				<?php if ( $pdu_video ) : ?>
					<div class="mx-auto max-w-4xl [&_iframe]:aspect-video [&_iframe]:w-full [&_iframe]:border-0">
						<?php
						$pdu_embed = wp_oembed_get( $pdu_video, array( 'width' => 1200 ) );
						if ( $pdu_embed ) {
							echo wp_kses( $pdu_embed, array( 'iframe' => array( 'src' => true, 'width' => true, 'height' => true, 'title' => true, 'loading' => true, 'allow' => true, 'allowfullscreen' => true, 'frameborder' => true ) ) );
						} else {
							printf(
								'<video controls preload="metadata" class="w-full" src="%s"><a href="%s">%s</a></video>',
								esc_url( $pdu_video ),
								esc_url( $pdu_video ),
								esc_html__( 'Download the video', 'plague-dr-universe' )
							);
						}
						?>
					</div>
				<?php endif; ?>

				<?php if ( $pdu_audio ) : ?>
					<ul class="mx-auto max-w-3xl list-none p-0">
						<?php
						pdu_audio_track(
							array(
								'title'  => get_the_title(),
								'album'  => (string) get_post_meta( get_the_ID(), 'pdu_album', true ),
								'length' => (string) get_post_meta( get_the_ID(), 'pdu_duration', true ),
								'src'    => $pdu_audio,
								'index'  => 0,
							)
						);
						?>
					</ul>
				<?php endif; ?>
			</div>
		</div>
	<?php endif; ?>

	<?php // ---------- Body ---------- ?>
	<div class="container section-tight">
		<div class="mx-auto max-w-3xl prose-pdu">
			<?php
			the_content();

			wp_link_pages(
				array(
					'before' => '<nav class="pagination mt-10 flex flex-wrap gap-2" aria-label="' . esc_attr__( 'Page sections', 'plague-dr-universe' ) . '">',
					'after'  => '</nav>',
				)
			);
			?>
		</div>

		<?php // ---------- Buy / read CTA ---------- ?>
		<?php
		$pdu_cta_url = get_post_meta( get_the_ID(), 'pdu_buy_url', true )
			? get_post_meta( get_the_ID(), 'pdu_buy_url', true )
			: ( get_post_meta( get_the_ID(), 'pdu_read_url', true )
				? get_post_meta( get_the_ID(), 'pdu_read_url', true )
				: get_post_meta( get_the_ID(), 'pdu_print_url', true ) );
		?>
		<?php if ( $pdu_cta_url ) : ?>
			<div class="mx-auto mt-12 flex max-w-3xl flex-wrap items-center justify-between gap-4 border border-ink-400 bg-ink-800 p-6">
				<p class="m-0 font-display text-base uppercase tracking-wide text-bone-50">
					<?php esc_html_e( 'Take this one home', 'plague-dr-universe' ); ?>
				</p>
				<a class="btn btn-primary" href="<?php echo esc_url( $pdu_cta_url ); ?>">
					<?php pdu_the_icon( 'cart', 16 ); ?>
					<?php esc_html_e( 'Buy in the store', 'plague-dr-universe' ); ?>
				</a>
			</div>
		<?php endif; ?>

		<?php // ---------- Tags ---------- ?>
		<?php $pdu_tags = get_the_tag_list( '', '' ); ?>
		<?php if ( $pdu_tags ) : ?>
			<div class="mx-auto mt-10 max-w-3xl">
				<p class="meta mb-3"><?php esc_html_e( 'Tagged', 'plague-dr-universe' ); ?></p>
				<div class="flex flex-wrap gap-2 [&_a]:badge [&_a]:no-underline">
					<?php echo wp_kses_post( $pdu_tags ); ?>
				</div>
			</div>
		<?php endif; ?>

		<?php // ---------- Prev / next ---------- ?>
		<?php
		$pdu_prev = get_previous_post();
		$pdu_next = get_next_post();
		?>
		<?php if ( $pdu_prev || $pdu_next ) : ?>
			<nav class="mx-auto mt-14 grid max-w-3xl gap-4 border-t border-ink-400 pt-10 sm:grid-cols-2"
					aria-label="<?php esc_attr_e( 'Post navigation', 'plague-dr-universe' ); ?>">
				<?php if ( $pdu_prev ) : ?>
					<a class="group border border-ink-400 bg-ink-800 p-5 no-underline transition-colors hover:border-blood-500"
						href="<?php echo esc_url( get_permalink( $pdu_prev ) ); ?>" rel="prev">
						<span class="meta block"><?php esc_html_e( '&larr; Previous', 'plague-dr-universe' ); ?></span>
						<span class="mt-2 block font-display text-base uppercase leading-tight text-bone-50 group-hover:text-amber-300">
							<?php echo esc_html( get_the_title( $pdu_prev ) ); ?>
						</span>
					</a>
				<?php endif; ?>

				<?php if ( $pdu_next ) : ?>
					<a class="group border border-ink-400 bg-ink-800 p-5 text-right no-underline transition-colors hover:border-blood-500 sm:col-start-2"
						href="<?php echo esc_url( get_permalink( $pdu_next ) ); ?>" rel="next">
						<span class="meta block"><?php esc_html_e( 'Next &rarr;', 'plague-dr-universe' ); ?></span>
						<span class="mt-2 block font-display text-base uppercase leading-tight text-bone-50 group-hover:text-amber-300">
							<?php echo esc_html( get_the_title( $pdu_next ) ); ?>
						</span>
					</a>
				<?php endif; ?>
			</nav>
		<?php endif; ?>
	</div>
</article>
