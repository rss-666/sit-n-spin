<?php
/**
 * Generic post card used across archives and grids.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$post_type = get_post_type();
$badge     = '';

switch ( $post_type ) {
	case 'pdu_chapter':
		$num   = get_post_meta( get_the_ID(), 'pdu_chapter_number', true );
		$badge = $num ? sprintf( /* translators: %s: chapter number. */ __( 'Chapter %s', 'plague-dr-universe' ), $num ) : __( 'Chapter', 'plague-dr-universe' );
		break;
	case 'pdu_track':
		$badge = (string) get_post_meta( get_the_ID(), 'pdu_album', true );
		break;
	case 'pdu_video':
		$badge = (string) get_post_meta( get_the_ID(), 'pdu_duration', true );
		break;
	case 'pdu_artwork':
		$badge = (string) get_post_meta( get_the_ID(), 'pdu_year', true );
		break;
}
?>

<article <?php post_class( 'card flex flex-col' ); ?> data-pdu-reveal>
	<div class="card-media <?php echo ( 'pdu_chapter' === $post_type ) ? 'aspect-[3/4]' : ''; ?>">
		<?php pdu_featured_image( get_the_ID(), ( 'pdu_chapter' === $post_type ) ? 'pdu-panel' : 'pdu-card' ); ?>

		<?php if ( $badge ) : ?>
			<span class="absolute left-4 top-4 badge badge-blood"><?php echo esc_html( $badge ); ?></span>
		<?php endif; ?>
	</div>

	<div class="card-body flex flex-1 flex-col">
		<?php if ( 'post' === $post_type ) : ?>
			<?php pdu_entry_meta(); ?>
		<?php endif; ?>

		<h2 class="card-title <?php echo ( 'post' === $post_type ) ? 'mt-3' : ''; ?>">
			<a href="<?php the_permalink(); ?>" class="stretched-link"><?php the_title(); ?></a>
		</h2>

		<p class="mt-3 flex-1 text-sm leading-relaxed text-bone-300">
			<?php echo esc_html( get_the_excerpt() ); ?>
		</p>

		<p class="meta mt-5 inline-flex items-center gap-2 text-amber-400">
			<?php
			switch ( $post_type ) {
				case 'pdu_track':
					esc_html_e( 'Listen', 'plague-dr-universe' );
					break;
				case 'pdu_video':
					esc_html_e( 'Watch', 'plague-dr-universe' );
					break;
				case 'pdu_chapter':
					esc_html_e( 'Read chapter', 'plague-dr-universe' );
					break;
				case 'pdu_artwork':
					esc_html_e( 'View piece', 'plague-dr-universe' );
					break;
				default:
					esc_html_e( 'Read more', 'plague-dr-universe' );
			}
			pdu_the_icon( 'arrow', 14 );
			?>
		</p>
	</div>
</article>
