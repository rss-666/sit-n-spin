<?php
/**
 * Interior page header band.
 *
 * Accepts args via get_template_part( ..., array( 'title' => ..., 'lede' => ... ) ).
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$args = wp_parse_args(
	$args ?? array(),
	array(
		'title' => '',
		'lede'  => '',
		'image' => '',
	)
);

// Derive a sensible title when none was passed in.
if ( ! $args['title'] ) {
	if ( is_home() ) {
		$page_for_posts = get_option( 'page_for_posts' );
		$args['title']  = $page_for_posts ? get_the_title( $page_for_posts ) : __( 'Dispatches', 'plague-dr-universe' );
		$args['lede']   = $args['lede'] ? $args['lede'] : __( 'Process notes, release announcements and field recordings from the studio.', 'plague-dr-universe' );
	} elseif ( is_search() ) {
		/* translators: %s: search query. */
		$args['title'] = sprintf( __( 'Search: %s', 'plague-dr-universe' ), get_search_query() );
	} elseif ( is_archive() ) {
		$args['title'] = get_the_archive_title();
		$args['lede']  = wp_strip_all_tags( get_the_archive_description() );
	} elseif ( is_404() ) {
		$args['title'] = __( 'Lost in the Rain', 'plague-dr-universe' );
	} else {
		$args['title'] = get_the_title();
	}
}

$bg = $args['image'] ? $args['image'] : pdu_img( 'rain-street-noir.jpg' );
?>

<header class="relative overflow-hidden border-b border-ink-400 bg-ink-800">
	<img src="<?php echo esc_url( $bg ); ?>"
			alt=""
			class="absolute inset-0 h-full w-full object-cover opacity-25"
			loading="lazy" decoding="async" width="1024" height="1024">
	<div class="absolute inset-0 bg-gradient-to-r from-ink-900 via-ink-900/90 to-ink-900/55" aria-hidden="true"></div>

	<div class="container relative py-16 md:py-20">
		<?php pdu_breadcrumbs(); ?>

		<h1 class="text-display-lg">
			<?php echo wp_kses_post( $args['title'] ); ?>
		</h1>

		<?php if ( $args['lede'] ) : ?>
			<p class="lede mt-5"><?php echo wp_kses_post( $args['lede'] ); ?></p>
		<?php endif; ?>
	</div>
</header>
