<?php
/**
 * Soundtrack section — accessible track list wired to the shared audio player.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$tracks_q = new WP_Query(
	array(
		'post_type'      => 'pdu_track',
		'posts_per_page' => 6,
		'no_found_rows'  => true,
	)
);

$tracks = array();

if ( $tracks_q->have_posts() ) {
	while ( $tracks_q->have_posts() ) {
		$tracks_q->the_post();
		$tracks[] = array(
			'title'  => get_the_title(),
			'album'  => (string) get_post_meta( get_the_ID(), 'pdu_album', true ),
			'length' => (string) get_post_meta( get_the_ID(), 'pdu_duration', true ),
			'src'    => (string) get_post_meta( get_the_ID(), 'pdu_audio_url', true ),
			'tag'    => '',
		);
	}
	wp_reset_postdata();
} else {
	$tracks = array(
		array(
			'title'  => __( 'Take the Streets Back', 'plague-dr-universe' ),
			'album'  => __( 'Emerald Rot — Side A', 'plague-dr-universe' ),
			'length' => '3:48',
			'src'    => '',
			'tag'    => __( 'Heavy', 'plague-dr-universe' ),
		),
		array(
			'title'  => __( 'Sirens in the Distance', 'plague-dr-universe' ),
			'album'  => __( 'Emerald Rot — Side A', 'plague-dr-universe' ),
			'length' => '2:14',
			'src'    => '',
			'tag'    => __( 'Ambient', 'plague-dr-universe' ),
		),
		array(
			'title'  => __( 'No Answers in the Rain', 'plague-dr-universe' ),
			'album'  => __( 'Emerald Rot — Side B', 'plague-dr-universe' ),
			'length' => '5:02',
			'src'    => '',
			'tag'    => __( 'Piano / Doom', 'plague-dr-universe' ),
		),
		array(
			'title'  => __( 'Ballard Drawbridge', 'plague-dr-universe' ),
			'album'  => __( 'Emerald Rot — Side B', 'plague-dr-universe' ),
			'length' => '4:31',
			'src'    => '',
			'tag'    => __( 'Industrial', 'plague-dr-universe' ),
		),
		array(
			'title'  => __( 'Beak &amp; Bone', 'plague-dr-universe' ),
			'album'  => __( 'The Plague Dr Suite', 'plague-dr-universe' ),
			'length' => '6:19',
			'src'    => '',
			'tag'    => __( 'Doom', 'plague-dr-universe' ),
		),
		array(
			'title'  => __( 'Quiet Runs Too Deep', 'plague-dr-universe' ),
			'album'  => __( 'The Plague Dr Suite', 'plague-dr-universe' ),
			'length' => '4:07',
			'src'    => '',
			'tag'    => __( 'Ambient', 'plague-dr-universe' ),
		),
	);
}
?>

<section id="soundtracks" class="section relative overflow-hidden" aria-labelledby="pdu-audio-title">

	<img src="<?php echo esc_url( pdu_img( 'great-wheel-rain.jpg' ) ); ?>"
			alt=""
			class="absolute inset-0 h-full w-full object-cover opacity-[0.18]"
			loading="lazy" decoding="async" width="1024" height="559">
	<div class="absolute inset-0 bg-gradient-to-b from-ink-900 via-ink-900/92 to-ink-900" aria-hidden="true"></div>

	<div class="container relative">
		<div class="grid gap-12 lg:grid-cols-12 lg:gap-16">

			<?php // ---------- Intro column ---------- ?>
			<div class="lg:col-span-5">
				<p class="eyebrow"><?php esc_html_e( 'The Soundtrack', 'plague-dr-universe' ); ?></p>
				<h2 id="pdu-audio-title" class="section-title">
					<?php esc_html_e( 'Music Written in the Same Room as the Ink', 'plague-dr-universe' ); ?>
				</h2>
				<p class="lede mt-5">
					<?php esc_html_e( 'Every chapter has a score. Downtuned guitars, tape hiss, field recordings of real rain and a piano that never quite resolves. Play a preview, then take the full record home.', 'plague-dr-universe' ); ?>
				</p>

				<div class="mt-8 flex flex-wrap gap-4">
					<a class="btn btn-primary" href="<?php echo esc_url( pdu_shop_url( 'music-albums' ) ); ?>">
						<?php pdu_the_icon( 'disc', 16 ); ?>
						<?php esc_html_e( 'Buy the Albums', 'plague-dr-universe' ); ?>
					</a>
					<a class="btn btn-ghost" href="<?php echo esc_url( home_url( '/soundtracks/' ) ); ?>">
						<?php esc_html_e( 'All tracks', 'plague-dr-universe' ); ?>
						<?php pdu_the_icon( 'arrow', 16 ); ?>
					</a>
				</div>

				<figure class="mt-10 border-l-4 border-blood-600 bg-ink-800/80 p-6">
					<blockquote class="m-0 font-display text-lg uppercase leading-snug text-bone-100">
						&ldquo;<?php esc_html_e( 'Shadows stretch across the street, and the quiet runs too deep.', 'plague-dr-universe' ); ?>&rdquo;
					</blockquote>
					<figcaption class="meta mt-3">
						<?php esc_html_e( 'Take the Streets Back — Verse I', 'plague-dr-universe' ); ?>
					</figcaption>
				</figure>
			</div>

			<?php // ---------- Player column ---------- ?>
			<div class="lg:col-span-7">
				<div class="border border-ink-400 bg-ink-900/85 p-5 backdrop-blur-sm md:p-7">
					<div class="mb-5 flex items-center justify-between gap-4">
						<h3 class="text-base"><?php esc_html_e( 'Now Streaming', 'plague-dr-universe' ); ?></h3>
						<p class="meta"><?php esc_html_e( 'Previews', 'plague-dr-universe' ); ?></p>
					</div>

					<ul class="list-none space-y-3 p-0">
						<?php
						foreach ( $tracks as $index => $track ) {
							$track['index'] = $index;
							pdu_audio_track( $track );
						}
						?>
					</ul>

					<p class="mt-6 flex items-start gap-2 text-xs leading-relaxed text-bone-400">
						<?php pdu_the_icon( 'download', 14, 'mt-0.5 shrink-0' ); ?>
						<?php esc_html_e( 'Full-length lossless downloads (FLAC / WAV / 320k MP3) are included with every album purchase in the store.', 'plague-dr-universe' ); ?>
					</p>
				</div>
			</div>
		</div>
	</div>
</section>
