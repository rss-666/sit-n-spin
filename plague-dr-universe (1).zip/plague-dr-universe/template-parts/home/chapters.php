<?php
/**
 * Featured graphic novel chapters.
 *
 * Pulls real `pdu_chapter` posts when they exist and falls back to a fully
 * written editorial sample so the homepage is never empty on a fresh install.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$chapters = new WP_Query(
	array(
		'post_type'           => 'pdu_chapter',
		'posts_per_page'      => 3,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	)
);

$fallback = array(
	array(
		'num'   => '01',
		'title' => __( 'The Silence Between Sirens', 'plague-dr-universe' ),
		'text'  => __( 'Two days after the block went quiet, the Doctor walks First Avenue counting the windows that stayed dark. Nobody asked him to come back. He came anyway.', 'plague-dr-universe' ),
		'pages' => '28',
		'img'   => 'plague-doctor-first-ave.jpg',
		'alt'   => __( 'The Plague Doctor standing outside a brick storefront on First Avenue at dusk', 'plague-dr-universe' ),
	),
	array(
		'num'   => '02',
		'title' => __( 'Needle Through the Rain', 'plague-dr-universe' ),
		'text'  => __( 'Red and blue wash the Needle from the ground up. A patient who should not be walking leaves a trail of wet footprints all the way to the top.', 'plague-dr-universe' ),
		'pages' => '32',
		'img'   => 'space-needle-rain.jpg',
		'alt'   => __( 'The Space Needle at night in heavy rain, lit red and blue with reflections on wet asphalt', 'plague-dr-universe' ),
	),
	array(
		'num'   => '03',
		'title' => __( 'The Great Wheel Turns Anyway', 'plague-dr-universe' ),
		'text'  => __( 'On the waterfront the wheel keeps spinning through the downpour, carrying something that is no longer paying for the ride.', 'plague-dr-universe' ),
		'pages' => '30',
		'img'   => 'great-wheel-rain.jpg',
		'alt'   => __( 'The Seattle Great Wheel lit red and blue against a black waterfront in heavy rain', 'plague-dr-universe' ),
	),
);
?>

<section class="section" aria-labelledby="pdu-chapters-title">
	<div class="container">

		<?php
		pdu_section_heading(
			array(
				'eyebrow'  => __( 'The Graphic Novel', 'plague-dr-universe' ),
				'title'    => __( 'Featured Chapters', 'plague-dr-universe' ),
				'lede'     => __( 'A serialised noir told in ink, grain and negative space. Read the latest chapters below, or start at the beginning.', 'plague-dr-universe' ),
				'cta_url'  => home_url( '/chapters/' ),
				'cta_text' => __( 'All chapters', 'plague-dr-universe' ),
				'id'       => 'pdu-chapters-title',
			)
		);
		?>

		<div class="grid gap-8 md:grid-cols-3">
			<?php if ( $chapters->have_posts() ) : ?>
				<?php
				while ( $chapters->have_posts() ) :
					$chapters->the_post();
					$number = get_post_meta( get_the_ID(), 'pdu_chapter_number', true );
					$pages  = get_post_meta( get_the_ID(), 'pdu_page_count', true );
					?>
					<article class="card flex flex-col" data-pdu-reveal>
						<div class="card-media aspect-[3/4]">
							<?php pdu_featured_image( get_the_ID(), 'pdu-panel' ); ?>
							<?php if ( $number ) : ?>
								<span class="absolute left-4 top-4 badge badge-blood">
									<?php
									/* translators: %s: chapter number. */
									printf( esc_html__( 'Chapter %s', 'plague-dr-universe' ), esc_html( $number ) );
									?>
								</span>
							<?php endif; ?>
						</div>

						<div class="card-body flex flex-1 flex-col">
							<h3 class="card-title">
								<a href="<?php the_permalink(); ?>" class="stretched-link"><?php the_title(); ?></a>
							</h3>
							<p class="mt-3 flex-1 text-sm leading-relaxed text-bone-300"><?php echo esc_html( get_the_excerpt() ); ?></p>
							<p class="meta mt-5 flex items-center gap-2">
								<?php pdu_the_icon( 'book', 14 ); ?>
								<?php echo $pages ? esc_html( sprintf( /* translators: %s: page count. */ __( '%s pages', 'plague-dr-universe' ), $pages ) ) : esc_html__( 'Read now', 'plague-dr-universe' ); ?>
							</p>
						</div>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
				?>
			<?php else : ?>
				<?php foreach ( $fallback as $chapter ) : ?>
					<article class="card flex flex-col" data-pdu-reveal>
						<div class="card-media aspect-[3/4]">
							<img src="<?php echo esc_url( pdu_img( $chapter['img'] ) ); ?>"
									alt="<?php echo esc_attr( $chapter['alt'] ); ?>"
									loading="lazy" decoding="async" width="1200" height="1600">
							<span class="absolute left-4 top-4 badge badge-blood">
								<?php
								/* translators: %s: chapter number. */
								printf( esc_html__( 'Chapter %s', 'plague-dr-universe' ), esc_html( $chapter['num'] ) );
								?>
							</span>
						</div>

						<div class="card-body flex flex-1 flex-col">
							<h3 class="card-title">
								<a href="<?php echo esc_url( home_url( '/chapters/' ) ); ?>" class="stretched-link">
									<?php echo esc_html( $chapter['title'] ); ?>
								</a>
							</h3>
							<p class="mt-3 flex-1 text-sm leading-relaxed text-bone-300">
								<?php echo esc_html( $chapter['text'] ); ?>
							</p>
							<p class="meta mt-5 flex items-center gap-2">
								<?php pdu_the_icon( 'book', 14 ); ?>
								<?php
								/* translators: %s: page count. */
								printf( esc_html__( '%s pages', 'plague-dr-universe' ), esc_html( $chapter['pages'] ) );
								?>
							</p>
						</div>
					</article>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	</div>
</section>
