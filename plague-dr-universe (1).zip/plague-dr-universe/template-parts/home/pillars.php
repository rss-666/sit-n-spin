<?php
/**
 * Four-pillar strip: the shape of the universe at a glance.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$pillars = array(
	array(
		'icon'  => 'book',
		'title' => __( 'Graphic Novel', 'plague-dr-universe' ),
		'text'  => __( 'Serialised chapters in heavy ink and rain-washed greys. New pages every month.', 'plague-dr-universe' ),
		'url'   => home_url( '/chapters/' ),
		'cta'   => __( 'Read chapters', 'plague-dr-universe' ),
	),
	array(
		'icon'  => 'palette',
		'title' => __( 'Original Artwork', 'plague-dr-universe' ),
		'text'  => __( 'Panel art, character studies and city plates — available as archival prints.', 'plague-dr-universe' ),
		'url'   => home_url( '/artwork/' ),
		'cta'   => __( 'View gallery', 'plague-dr-universe' ),
	),
	array(
		'icon'  => 'disc',
		'title' => __( 'Soundtracks', 'plague-dr-universe' ),
		'text'  => __( 'Metal, doom-ambient and piano fragments written alongside the story.', 'plague-dr-universe' ),
		'url'   => home_url( '/soundtracks/' ),
		'cta'   => __( 'Listen now', 'plague-dr-universe' ),
	),
	array(
		'icon'  => 'video',
		'title' => __( 'Video Releases', 'plague-dr-universe' ),
		'text'  => __( 'Music videos, animatics and behind-the-glass process films.', 'plague-dr-universe' ),
		'url'   => home_url( '/videos/' ),
		'cta'   => __( 'Watch', 'plague-dr-universe' ),
	),
);
?>

<section id="pdu-pillars" class="section-tight border-b border-ink-400 bg-ink-800" aria-labelledby="pdu-pillars-title">
	<div class="container">
		<h2 id="pdu-pillars-title" class="screen-reader-text">
			<?php esc_html_e( 'What lives inside the universe', 'plague-dr-universe' ); ?>
		</h2>

		<ul class="grid list-none gap-px overflow-hidden border border-ink-400 bg-ink-400 p-0 sm:grid-cols-2 lg:grid-cols-4">
			<?php foreach ( $pillars as $pillar ) : ?>
				<li class="group relative bg-ink-800 p-8 transition-colors hover:bg-ink-700">
					<span class="inline-grid h-12 w-12 place-items-center border border-blood-600/60 text-blood-400 transition-colors group-hover:border-amber-500 group-hover:text-amber-400">
						<?php pdu_the_icon( $pillar['icon'], 22 ); ?>
					</span>

					<h3 class="mt-5 text-lg"><?php echo esc_html( $pillar['title'] ); ?></h3>

					<p class="mt-2.5 text-sm leading-relaxed text-bone-300">
						<?php echo esc_html( $pillar['text'] ); ?>
					</p>

					<a class="stretched-link mt-4 inline-flex items-center gap-2 font-display text-xs uppercase tracking-brand text-amber-400 no-underline"
						href="<?php echo esc_url( $pillar['url'] ); ?>">
						<?php echo esc_html( $pillar['cta'] ); ?>
						<?php pdu_the_icon( 'arrow', 14 ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
