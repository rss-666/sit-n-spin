<?php
/**
 * Homepage WooCommerce product grid.
 *
 * Renders real products when WooCommerce is active; otherwise shows a styled
 * preview of the four store categories so the layout is reviewable pre-install.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$categories = array(
	array(
		'slug'  => 'graphic-novels',
		'icon'  => 'book',
		'title' => __( 'Graphic Novels', 'plague-dr-universe' ),
		'text'  => __( 'Print volumes, signed editions and instant DRM-free digital downloads.', 'plague-dr-universe' ),
		'img'   => 'plague-doctor-first-ave.jpg',
		'from'  => '18',
	),
	array(
		'slug'  => 'original-artwork',
		'icon'  => 'palette',
		'title' => __( 'Original Artwork', 'plague-dr-universe' ),
		'text'  => __( 'One-of-one originals and numbered archival giclée prints.', 'plague-dr-universe' ),
		'img'   => 'rain-street-noir.jpg',
		'from'  => '35',
	),
	array(
		'slug'  => 'music-albums',
		'icon'  => 'disc',
		'title' => __( 'Music &amp; Albums', 'plague-dr-universe' ),
		'text'  => __( 'Vinyl, CD and lossless downloads of the full soundtrack catalogue.', 'plague-dr-universe' ),
		'img'   => 'great-wheel-rain.jpg',
		'from'  => '12',
	),
	array(
		'slug'  => 'apparel-merch',
		'icon'  => 'shirt',
		'title' => __( 'Apparel &amp; Merch', 'plague-dr-universe' ),
		'text'  => __( 'Heavyweight tees, hoodies, patches and enamel pins. Ethically printed.', 'plague-dr-universe' ),
		'img'   => 'space-needle-square.jpg',
		'from'  => '15',
	),
);
?>

<section id="store" class="section border-y border-ink-400 bg-ink-800/50" aria-labelledby="pdu-store-title">
	<div class="container">

		<?php
		pdu_section_heading(
			array(
				'eyebrow'  => __( 'The Store', 'plague-dr-universe' ),
				'title'    => __( 'Take Something Home', 'plague-dr-universe' ),
				'lede'     => __( 'Physical and digital goods straight from the studio. Every order is packed by hand and ships worldwide from Seattle.', 'plague-dr-universe' ),
				'cta_url'  => pdu_shop_url(),
				'cta_text' => __( 'Enter the store', 'plague-dr-universe' ),
				'id'       => 'pdu-store-title',
			)
		);
		?>

		<?php // ---------- Category rail ---------- ?>
		<ul class="mb-14 grid list-none gap-4 p-0 sm:grid-cols-2 lg:grid-cols-4">
			<?php foreach ( $categories as $cat ) : ?>
				<li class="group relative overflow-hidden border border-ink-400 bg-ink-900">
					<div class="absolute inset-0">
						<img src="<?php echo esc_url( pdu_img( $cat['img'] ) ); ?>"
								alt=""
								class="h-full w-full object-cover opacity-30 transition-transform duration-700 group-hover:scale-110"
								loading="lazy" decoding="async" width="800" height="800">
						<div class="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-900/85 to-ink-900/40"></div>
					</div>

					<div class="relative flex min-h-[15rem] flex-col justify-end p-6">
						<span class="mb-auto inline-grid h-11 w-11 place-items-center border border-amber-500/50 text-amber-400">
							<?php pdu_the_icon( $cat['icon'], 20 ); ?>
						</span>

						<h3 class="mt-6 text-lg"><?php echo wp_kses_post( $cat['title'] ); ?></h3>
						<p class="mt-2 text-sm leading-relaxed text-bone-300"><?php echo esc_html( $cat['text'] ); ?></p>

						<p class="meta mt-4 text-amber-400">
							<?php
							/* translators: %s: lowest price in the category. */
							printf( esc_html__( 'From $%s', 'plague-dr-universe' ), esc_html( $cat['from'] ) );
							?>
						</p>

						<a class="stretched-link mt-3 inline-flex items-center gap-2 font-display text-xs uppercase tracking-brand text-bone-100 no-underline"
							href="<?php echo esc_url( pdu_shop_url( $cat['slug'] ) ); ?>">
							<?php esc_html_e( 'Shop', 'plague-dr-universe' ); ?>
							<?php pdu_the_icon( 'arrow', 14 ); ?>
						</a>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>

		<?php // ---------- Product grid ---------- ?>
		<?php if ( class_exists( 'WooCommerce' ) ) : ?>
			<h3 class="mb-8 flex items-center gap-3 text-xl">
				<span class="h-px w-8 bg-blood-500" aria-hidden="true"></span>
				<?php esc_html_e( 'Latest Drops', 'plague-dr-universe' ); ?>
			</h3>

			<?php
			echo do_shortcode( '[products limit="8" columns="4" orderby="date" order="DESC" visibility="visible"]' );
			?>
		<?php else : ?>
			<div class="notice-pdu flex flex-wrap items-center justify-between gap-4">
				<p class="m-0">
					<strong class="text-bone-50"><?php esc_html_e( 'Store preview.', 'plague-dr-universe' ); ?></strong>
					<?php esc_html_e( 'Activate WooCommerce to replace this panel with the live product grid — the theme ships with fully styled catalog, cart, checkout and account templates.', 'plague-dr-universe' ); ?>
				</p>
				<a class="btn btn-secondary btn-sm shrink-0" href="<?php echo esc_url( admin_url( 'plugin-install.php?s=woocommerce&tab=search&type=term' ) ); ?>">
					<?php esc_html_e( 'Install WooCommerce', 'plague-dr-universe' ); ?>
				</a>
			</div>
		<?php endif; ?>

		<?php // ---------- Trust row ---------- ?>
		<ul class="mt-14 grid list-none gap-6 border-t border-ink-400 p-0 pt-10 sm:grid-cols-3">
			<?php
			$trust = array(
				array( 'truck', __( 'Ships worldwide', 'plague-dr-universe' ), __( 'Tracked dispatch from Seattle within 3 business days.', 'plague-dr-universe' ) ),
				array( 'download', __( 'Instant digital', 'plague-dr-universe' ), __( 'Downloads unlock the moment payment clears. DRM-free, forever.', 'plague-dr-universe' ) ),
				array( 'shield', __( 'Secure checkout', 'plague-dr-universe' ), __( 'PCI-compliant payments. We never store your card details.', 'plague-dr-universe' ) ),
			);
			foreach ( $trust as $item ) :
				?>
				<li class="flex gap-4">
					<span class="mt-0.5 shrink-0 text-amber-400"><?php pdu_the_icon( $item[0], 22 ); ?></span>
					<span>
						<span class="block font-display text-sm uppercase tracking-brand text-bone-50"><?php echo esc_html( $item[1] ); ?></span>
						<span class="mt-1 block text-sm leading-relaxed text-bone-400"><?php echo esc_html( $item[2] ); ?></span>
					</span>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
