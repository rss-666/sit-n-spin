<?php
/**
 * Latest journal posts ("Dispatches").
 *
 * Renders nothing at all when there are no published posts, so the homepage
 * never shows an empty shell.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$posts_q = new WP_Query(
	array(
		'post_type'           => 'post',
		'posts_per_page'      => 3,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	)
);

if ( ! $posts_q->have_posts() ) {
	return;
}
?>

<section class="section border-t border-ink-400" aria-labelledby="pdu-dispatch-title">
	<div class="container">

		<?php
		pdu_section_heading(
			array(
				'eyebrow'  => __( 'From the Studio', 'plague-dr-universe' ),
				'title'    => __( 'Dispatches', 'plague-dr-universe' ),
				'lede'     => __( 'Process notes, release announcements and the occasional field recording from a very wet city.', 'plague-dr-universe' ),
				'cta_url'  => get_permalink( get_option( 'page_for_posts' ) ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/blog/' ),
				'cta_text' => __( 'All dispatches', 'plague-dr-universe' ),
				'id'       => 'pdu-dispatch-title',
			)
		);
		?>

		<div class="grid gap-8 md:grid-cols-3">
			<?php
			while ( $posts_q->have_posts() ) :
				$posts_q->the_post();
				?>
				<article <?php post_class( 'card flex flex-col' ); ?> data-pdu-reveal>
					<div class="card-media">
						<?php pdu_featured_image( get_the_ID(), 'pdu-card' ); ?>
					</div>
					<div class="card-body flex flex-1 flex-col">
						<?php pdu_entry_meta(); ?>
						<h3 class="card-title mt-3">
							<a href="<?php the_permalink(); ?>" class="stretched-link"><?php the_title(); ?></a>
						</h3>
						<p class="mt-3 flex-1 text-sm leading-relaxed text-bone-300">
							<?php echo esc_html( get_the_excerpt() ); ?>
						</p>
					</div>
				</article>
				<?php
			endwhile;
			wp_reset_postdata();
			?>
		</div>
	</div>
</section>
