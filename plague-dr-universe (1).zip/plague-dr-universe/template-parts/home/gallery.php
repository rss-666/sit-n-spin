<?php
/**
 * Visual art gallery — asymmetric editorial grid with lightbox.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$artworks = new WP_Query(
	array(
		'post_type'      => 'pdu_artwork',
		'posts_per_page' => 5,
		'no_found_rows'  => true,
	)
);

$fallback = array(
	array(
		'img'   => 'plague-doctor-first-ave.jpg',
		'title' => __( 'First Avenue, 22:08', 'plague-dr-universe' ),
		'meta'  => __( 'Digital plate · 2025', 'plague-dr-universe' ),
		'alt'   => __( 'The Plague Doctor in a brass-buckled leather coat and beaked mask outside a brick storefront on First Avenue', 'plague-dr-universe' ),
		'span'  => 'md:col-span-2 md:row-span-2',
		'ratio' => 'aspect-[3/4] md:aspect-auto md:h-full',
	),
	array(
		'img'   => 'space-needle-rain.jpg',
		'title' => __( 'Needle, Red Shift', 'plague-dr-universe' ),
		'meta'  => __( 'City plate · 2025', 'plague-dr-universe' ),
		'alt'   => __( 'The Space Needle in heavy rain lit from below by red and blue emergency lights', 'plague-dr-universe' ),
		'span'  => 'md:col-span-2',
		'ratio' => 'aspect-[16/9]',
	),
	array(
		'img'   => 'great-wheel-rain.jpg',
		'title' => __( 'The Wheel Keeps Turning', 'plague-dr-universe' ),
		'meta'  => __( 'City plate · 2025', 'plague-dr-universe' ),
		'alt'   => __( 'The Seattle Great Wheel on the waterfront at night, red and blue light on wet boardwalk', 'plague-dr-universe' ),
		'span'  => '',
		'ratio' => 'aspect-square',
	),
	array(
		'img'   => 'rain-street-noir.jpg',
		'title' => __( 'Downtown, No Witnesses', 'plague-dr-universe' ),
		'meta'  => __( 'Background study · 2025', 'plague-dr-universe' ),
		'alt'   => __( 'An empty rain-slicked downtown street at night with red and blue signal lights reflected on the asphalt', 'plague-dr-universe' ),
		'span'  => '',
		'ratio' => 'aspect-square',
	),
	array(
		'img'   => 'storyboard-contact-sheet.jpg',
		'title' => __( 'Sequence Board — Chapter Two', 'plague-dr-universe' ),
		'meta'  => __( 'Storyboard contact sheet · 2025', 'plague-dr-universe' ),
		'alt'   => __( 'A sixteen-panel storyboard contact sheet of rainy night-time city scenes', 'plague-dr-universe' ),
		'span'  => 'md:col-span-2',
		'ratio' => 'aspect-[16/9]',
	),
);
?>

<section id="gallery" class="section border-y border-ink-400 bg-ink-800/50" aria-labelledby="pdu-gallery-title">
	<div class="container">

		<?php
		pdu_section_heading(
			array(
				'eyebrow'  => __( 'Visual Art', 'plague-dr-universe' ),
				'title'    => __( 'The Gallery', 'plague-dr-universe' ),
				'lede'     => __( 'Plates, panels and city studies drawn for the story and finished as standalone works. Select a piece to view it full-size.', 'plague-dr-universe' ),
				'cta_url'  => home_url( '/artwork/' ),
				'cta_text' => __( 'Full portfolio', 'plague-dr-universe' ),
				'id'       => 'pdu-gallery-title',
			)
		);
		?>

		<div class="grid auto-rows-[minmax(0,1fr)] gap-4 sm:grid-cols-2 md:grid-cols-4">
			<?php if ( $artworks->have_posts() ) : ?>
				<?php
				$i = 0;
				while ( $artworks->have_posts() ) :
					$artworks->the_post();
					$i++;
					$span  = ( 1 === $i ) ? 'md:col-span-2 md:row-span-2' : ( ( 2 === $i || 5 === $i ) ? 'md:col-span-2' : '' );
					$ratio = ( 1 === $i ) ? 'aspect-[3/4] md:aspect-auto md:h-full' : ( ( 2 === $i || 5 === $i ) ? 'aspect-[16/9]' : 'aspect-square' );
					$full  = get_the_post_thumbnail_url( get_the_ID(), 'full' );
					?>
					<a class="tile <?php echo esc_attr( $span . ' ' . $ratio ); ?>"
						href="<?php the_permalink(); ?>"
						data-pdu-lightbox
						data-full="<?php echo esc_url( $full ? $full : pdu_img( 'plague-doctor-first-ave.jpg' ) ); ?>"
						data-caption="<?php echo esc_attr( wp_strip_all_tags( get_the_title() ) ); ?>">
						<?php pdu_featured_image( get_the_ID(), 'pdu-tile' ); ?>
						<span class="tile-cap block">
							<span class="block font-display text-base uppercase tracking-wide text-bone-50"><?php the_title(); ?></span>
							<span class="meta mt-1 block"><?php echo esc_html( get_post_meta( get_the_ID(), 'pdu_year', true ) ); ?></span>
						</span>
					</a>
					<?php
				endwhile;
				wp_reset_postdata();
				?>
			<?php else : ?>
				<?php foreach ( $fallback as $art ) : ?>
					<a class="tile <?php echo esc_attr( $art['span'] . ' ' . $art['ratio'] ); ?>"
						href="<?php echo esc_url( pdu_img( $art['img'] ) ); ?>"
						data-pdu-lightbox
						data-full="<?php echo esc_url( pdu_img( $art['img'] ) ); ?>"
						data-caption="<?php echo esc_attr( $art['title'] . ' — ' . $art['meta'] ); ?>">
						<img src="<?php echo esc_url( pdu_img( $art['img'] ) ); ?>"
								alt="<?php echo esc_attr( $art['alt'] ); ?>"
								loading="lazy" decoding="async" width="1200" height="1200">
						<span class="tile-cap block">
							<span class="block font-display text-base uppercase tracking-wide text-bone-50">
								<?php echo esc_html( $art['title'] ); ?>
							</span>
							<span class="meta mt-1 block"><?php echo esc_html( $art['meta'] ); ?></span>
						</span>
					</a>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	</div>
</section>
