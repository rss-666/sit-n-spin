<?php
/**
 * Video releases.
 *
 * Uses a click-to-load facade so no third-party player scripts or cookies are
 * requested until the visitor actually asks for the video.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$videos_q = new WP_Query(
	array(
		'post_type'      => 'pdu_video',
		'posts_per_page' => 3,
		'no_found_rows'  => true,
	)
);

$fallback = array(
	array(
		'title'    => __( 'Take the Streets Back — Official Video', 'plague-dr-universe' ),
		'meta'     => __( 'Music video · 3:48', 'plague-dr-universe' ),
		'text'     => __( 'Rain-slicked asphalt, a stopped school bus at the Ballard drawbridge and a set of dog tags swinging from a rearview mirror.', 'plague-dr-universe' ),
		'img'      => 'space-needle-square.jpg',
		'alt'      => __( 'Still frame of the Space Needle in rain lit by red and blue emergency lights', 'plague-dr-universe' ),
		'featured' => true,
	),
	array(
		'title'    => __( 'Chapter Two — Animatic', 'plague-dr-universe' ),
		'meta'     => __( 'Animatic · 2:06', 'plague-dr-universe' ),
		'text'     => __( 'The full sequence board for Chapter Two, timed to the score before a single panel was inked.', 'plague-dr-universe' ),
		'img'      => 'storyboard-contact-sheet.jpg',
		'alt'      => __( 'Storyboard contact sheet of sixteen rainy night-time scenes', 'plague-dr-universe' ),
		'featured' => false,
	),
	array(
		'title'    => __( 'Behind the Glass — Painting the Waterfront', 'plague-dr-universe' ),
		'meta'     => __( 'Process film · 8:12', 'plague-dr-universe' ),
		'text'     => __( 'Two hours of layering compressed into eight minutes: how the Great Wheel plate was built from grey block-in to final wash.', 'plague-dr-universe' ),
		'img'      => 'great-wheel-rain.jpg',
		'alt'      => __( 'The Seattle Great Wheel at night in the rain lit red and blue', 'plague-dr-universe' ),
		'featured' => false,
	),
);
?>

<section id="videos" class="section" aria-labelledby="pdu-videos-title">
	<div class="container">

		<?php
		pdu_section_heading(
			array(
				'eyebrow'  => __( 'Moving Image', 'plague-dr-universe' ),
				'title'    => __( 'Video Releases', 'plague-dr-universe' ),
				'lede'     => __( 'Music videos, animatics and process films. Nothing loads from a third-party player until you press play.', 'plague-dr-universe' ),
				'cta_url'  => home_url( '/videos/' ),
				'cta_text' => __( 'All videos', 'plague-dr-universe' ),
				'id'       => 'pdu-videos-title',
			)
		);
		?>

		<div class="grid gap-8 lg:grid-cols-12">
			<?php if ( $videos_q->have_posts() ) : ?>
				<?php
				$i = 0;
				while ( $videos_q->have_posts() ) :
					$videos_q->the_post();
					$i++;
					$url   = (string) get_post_meta( get_the_ID(), 'pdu_video_url', true );
					$dur   = (string) get_post_meta( get_the_ID(), 'pdu_duration', true );
					$span  = ( 1 === $i ) ? 'lg:col-span-7' : 'lg:col-span-5';
					$ratio = ( 1 === $i ) ? 'aspect-video' : 'aspect-[16/10]';
					?>
					<article class="card <?php echo esc_attr( $span ); ?>" data-pdu-reveal>
						<div class="card-media <?php echo esc_attr( $ratio ); ?>">
							<?php pdu_featured_image( get_the_ID(), 'pdu-wide' ); ?>
							<a class="absolute inset-0 grid place-items-center bg-ink-900/45 transition-colors hover:bg-ink-900/20"
								href="<?php echo esc_url( $url ? $url : get_permalink() ); ?>"
								<?php echo $url ? 'target="_blank" rel="noopener noreferrer"' : ''; ?>>
								<span class="grid h-16 w-16 place-items-center rounded-full border-2 border-white/85 bg-blood-600/85 text-white transition-transform hover:scale-110">
									<?php pdu_the_icon( 'play', 24 ); ?>
								</span>
								<span class="screen-reader-text">
									<?php
									/* translators: %s: video title. */
									printf( esc_html__( 'Play %s', 'plague-dr-universe' ), esc_html( get_the_title() ) );
									?>
								</span>
							</a>
							<?php if ( $dur ) : ?>
								<span class="absolute bottom-3 right-3 bg-ink-900/90 px-2 py-1 font-display text-[0.68rem] tracking-brand text-bone-100">
									<?php echo esc_html( $dur ); ?>
								</span>
							<?php endif; ?>
						</div>

						<div class="card-body">
							<h3 class="card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<p class="mt-3 text-sm leading-relaxed text-bone-300"><?php echo esc_html( get_the_excerpt() ); ?></p>
						</div>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
				?>
			<?php else : ?>
				<?php foreach ( $fallback as $video ) : ?>
					<article class="card <?php echo $video['featured'] ? 'lg:col-span-7 lg:row-span-2' : 'lg:col-span-5'; ?>"
							data-pdu-reveal>
						<div class="card-media <?php echo $video['featured'] ? 'aspect-video' : 'aspect-[16/10]'; ?>">
							<img src="<?php echo esc_url( pdu_img( $video['img'] ) ); ?>"
									alt="<?php echo esc_attr( $video['alt'] ); ?>"
									loading="lazy" decoding="async" width="1024" height="576">

							<a class="absolute inset-0 grid place-items-center bg-ink-900/45 transition-colors hover:bg-ink-900/20"
								href="<?php echo esc_url( home_url( '/videos/' ) ); ?>">
								<span class="grid h-16 w-16 place-items-center rounded-full border-2 border-white/85 bg-blood-600/85 text-white transition-transform hover:scale-110">
									<?php pdu_the_icon( 'play', 24 ); ?>
								</span>
								<span class="screen-reader-text">
									<?php
									/* translators: %s: video title. */
									printf( esc_html__( 'Play %s', 'plague-dr-universe' ), esc_html( $video['title'] ) );
									?>
								</span>
							</a>
						</div>

						<div class="card-body">
							<p class="meta"><?php echo esc_html( $video['meta'] ); ?></p>
							<h3 class="card-title mt-2"><?php echo esc_html( $video['title'] ); ?></h3>
							<p class="mt-3 text-sm leading-relaxed text-bone-300"><?php echo esc_html( $video['text'] ); ?></p>
						</div>
					</article>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	</div>
</section>
