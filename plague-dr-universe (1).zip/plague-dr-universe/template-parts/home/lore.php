<?php
/**
 * Lore teaser — links through to The Universe hub.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;
?>

<section class="section relative overflow-hidden" aria-labelledby="pdu-lore-title">
	<div class="container">
		<div class="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">

			<div class="relative order-2 lg:order-1">
				<div class="relative aspect-[4/5] overflow-hidden border border-ink-400">
					<img src="<?php echo esc_url( pdu_img( 'plague-doctor-first-ave.jpg' ) ); ?>"
							alt="<?php esc_attr_e( 'Full-length portrait of the Plague Doctor with brass goggles, leather coat and a cane, standing outside a brick storefront', 'plague-dr-universe' ); ?>"
							class="h-full w-full object-cover"
							loading="lazy" decoding="async" width="1024" height="1536">
					<div class="absolute inset-0 bg-gradient-to-t from-ink-900/85 via-transparent to-transparent"></div>
				</div>

				<?php // Offset caption plate. ?>
				<div class="absolute -bottom-6 -right-4 max-w-[15rem] border border-ink-300 bg-ink-800 p-5 shadow-plate sm:-right-6">
					<p class="meta text-blood-400"><?php esc_html_e( 'Subject 001', 'plague-dr-universe' ); ?></p>
					<p class="mt-2 font-display text-base uppercase leading-tight text-bone-50">
						<?php esc_html_e( 'The Doctor', 'plague-dr-universe' ); ?>
					</p>
					<p class="mt-2 text-xs leading-relaxed text-bone-400">
						<?php esc_html_e( 'Status: still walking. Last seen on First Avenue, 22:08, in the rain.', 'plague-dr-universe' ); ?>
					</p>
				</div>
			</div>

			<div class="order-1 lg:order-2">
				<p class="eyebrow"><?php esc_html_e( 'The Universe', 'plague-dr-universe' ); ?></p>
				<h2 id="pdu-lore-title" class="section-title">
					<?php esc_html_e( 'One Story, Told Three Ways', 'plague-dr-universe' ); ?>
				</h2>

				<div class="prose-pdu mt-6">
					<p>
						<?php esc_html_e( 'The Plague Dr Universe is not a comic with a soundtrack bolted on. The page, the record and the canvas are written together — a panel exists because a riff needed somewhere to land, a track exists because a scene refused to be silent.', 'plague-dr-universe' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'It is set in a Pacific Northwest that is always two days after something bad. Emergency light on wet brick. A city that keeps its receipts. And walking through it, a figure in a beaked mask who is either the last doctor left or the reason you need one.', 'plague-dr-universe' ); ?>
					</p>
				</div>

				<ul class="mt-8 list-none space-y-4 p-0">
					<?php
					$threads = array(
						array( 'book', __( 'Read it', 'plague-dr-universe' ), __( 'Six chapters and counting, released as they are finished.', 'plague-dr-universe' ) ),
						array( 'disc', __( 'Hear it', 'plague-dr-universe' ), __( 'Two records scored chapter by chapter, not track by track.', 'plague-dr-universe' ) ),
						array( 'palette', __( 'Hang it', 'plague-dr-universe' ), __( 'Every plate in the book exists as a print you can own.', 'plague-dr-universe' ) ),
					);
					foreach ( $threads as $thread ) :
						?>
						<li class="flex gap-4 border-l-2 border-ink-400 pl-5 transition-colors hover:border-blood-500">
							<span class="mt-0.5 shrink-0 text-amber-400"><?php pdu_the_icon( $thread[0], 20 ); ?></span>
							<span>
								<span class="block font-display text-sm uppercase tracking-brand text-bone-50"><?php echo esc_html( $thread[1] ); ?></span>
								<span class="mt-1 block text-sm text-bone-400"><?php echo esc_html( $thread[2] ); ?></span>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>

				<a class="btn btn-primary mt-9" href="<?php echo esc_url( home_url( '/the-universe/' ) ); ?>">
					<?php esc_html_e( 'Enter the Universe', 'plague-dr-universe' ); ?>
					<?php pdu_the_icon( 'arrow', 16 ); ?>
				</a>
			</div>
		</div>
	</div>
</section>
