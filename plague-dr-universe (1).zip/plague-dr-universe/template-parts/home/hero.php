<?php
/**
 * Homepage hero.
 *
 * The background image is loaded eagerly with fetchpriority=high because it is
 * the LCP element. Everything above the fold is server-rendered — no layout
 * shift, no JS required.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$hero_image = get_theme_mod( 'pdu_hero_image', '' );
$hero_image = $hero_image ? $hero_image : pdu_img( 'plague-doctor-first-ave.jpg' );

$eyebrow = get_theme_mod( 'pdu_hero_eyebrow', __( 'Ink · Noise · Rain', 'plague-dr-universe' ) );
$title   = get_theme_mod( 'pdu_hero_title', __( 'Welcome to The Plague Dr Universe', 'plague-dr-universe' ) );
$text    = get_theme_mod( 'pdu_hero_text', __( 'A graphic novel, a soundtrack and a city that will not stop raining. Original artwork, heavy music and serialised story — all from one hand, all in one place.', 'plague-dr-universe' ) );

$cta1_text = get_theme_mod( 'pdu_hero_cta1_text', __( 'Explore Art &amp; Comics', 'plague-dr-universe' ) );
$cta1_url  = get_theme_mod( 'pdu_hero_cta1_url', home_url( '/chapters/' ) );
$cta2_text = get_theme_mod( 'pdu_hero_cta2_text', __( 'Listen to the Soundtracks', 'plague-dr-universe' ) );
$cta2_url  = get_theme_mod( 'pdu_hero_cta2_url', '#soundtracks' );
?>

<section class="hero" aria-labelledby="pdu-hero-title">

	<div class="hero-media">
		<img src="<?php echo esc_url( $hero_image ); ?>"
				alt="<?php esc_attr_e( 'The Plague Doctor in a studded leather coat and beaked mask standing on a rain-darkened Seattle street corner beneath a neon OPEN sign', 'plague-dr-universe' ); ?>"
				width="1024" height="1536"
				fetchpriority="high"
				decoding="async"
				class="object-cover object-[68%_center] md:object-[60%_20%]">
	</div>
	<div class="hero-scrim" aria-hidden="true"></div>
	<div class="hero-siren" aria-hidden="true"></div>

	<div class="container relative z-10 py-32 md:py-40">
		<div class="max-w-3xl">

			<p class="eyebrow animate-rise"><?php echo esc_html( $eyebrow ); ?></p>

			<h1 id="pdu-hero-title" class="text-display-xl text-shadow-hard animate-rise">
				<?php
				// Split the headline so the brand name carries the accent colour.
				$parts = explode( 'Plague Dr', wp_strip_all_tags( $title ) );
				if ( 2 === count( $parts ) ) {
					echo esc_html( $parts[0] );
					echo '<span class="text-blood-500">' . esc_html__( 'Plague Dr', 'plague-dr-universe' ) . '</span>';
					echo esc_html( $parts[1] );
				} else {
					echo wp_kses_post( $title );
				}
				?>
			</h1>

			<p class="lede mt-7 text-xl text-bone-200 text-shadow-hard animate-rise">
				<?php echo wp_kses_post( $text ); ?>
			</p>

			<div class="mt-10 flex flex-col gap-4 sm:flex-row sm:flex-wrap animate-rise">
				<a class="btn btn-primary" href="<?php echo esc_url( $cta1_url ); ?>">
					<?php pdu_the_icon( 'palette', 16 ); ?>
					<?php echo wp_kses_post( $cta1_text ); ?>
				</a>
				<a class="btn btn-secondary" href="<?php echo esc_url( $cta2_url ); ?>">
					<?php pdu_the_icon( 'play', 14 ); ?>
					<?php echo wp_kses_post( $cta2_text ); ?>
				</a>
			</div>

			<?php // Quick stats double as a credibility strip. ?>
			<dl class="mt-14 grid max-w-xl grid-cols-3 gap-6">
				<div class="stat">
					<dt class="stat-label"><?php esc_html_e( 'Chapters', 'plague-dr-universe' ); ?></dt>
					<dd class="m-0"><span class="stat-num">06</span></dd>
				</div>
				<div class="stat">
					<dt class="stat-label"><?php esc_html_e( 'Tracks', 'plague-dr-universe' ); ?></dt>
					<dd class="m-0"><span class="stat-num">18</span></dd>
				</div>
				<div class="stat">
					<dt class="stat-label"><?php esc_html_e( 'Original Works', 'plague-dr-universe' ); ?></dt>
					<dd class="m-0"><span class="stat-num">40+</span></dd>
				</div>
			</dl>
		</div>
	</div>

	<?php // Scroll cue. ?>
	<a href="#pdu-pillars"
		class="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-bone-400 no-underline hover:text-amber-300 md:flex">
		<span class="font-display text-[0.65rem] uppercase tracking-wider2"><?php esc_html_e( 'Descend', 'plague-dr-universe' ); ?></span>
		<svg width="16" height="26" viewBox="0 0 16 26" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true">
			<rect x="1" y="1" width="14" height="24" rx="7"/>
			<path d="M8 7v4" stroke-linecap="round"/>
		</svg>
	</a>
</section>
