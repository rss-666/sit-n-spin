<?php
/**
 * Single post / single custom post type.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="<?php echo esc_attr( pdu_content_offset_class() ); ?>">
	<?php
	while ( have_posts() ) :
		the_post();
		get_template_part( 'template-parts/content/single', get_post_type() );

		if ( comments_open() || get_comments_number() ) {
			echo '<div class="container pb-20">';
			comments_template();
			echo '</div>';
		}
	endwhile;
	?>
</div>

<?php
get_footer();
