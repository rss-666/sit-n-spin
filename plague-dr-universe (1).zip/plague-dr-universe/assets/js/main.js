/**
 * The Plague Dr Universe — front-end behaviour.
 *
 * Vanilla ES2019, no dependencies, deferred. Everything degrades gracefully
 * when JS is unavailable and respects prefers-reduced-motion.
 *
 * Modules:
 *   1. Sticky/solid header
 *   2. Mobile drawer (focus trap, Escape, aria-expanded)
 *   3. Search panel
 *   4. Shared audio player for track lists
 *   5. Scroll reveal
 *   6. Back to top
 *   7. Lightbox for gallery tiles
 *   8. Cart count refresh
 *
 * @package PlagueDrUniverse
 */
(function () {
	'use strict';

	var i18n = (window.pduData && window.pduData.i18n) || {};
	var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/** Shorthand helpers. */
	function $(sel, ctx) { return (ctx || document).querySelector(sel); }
	function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

	/* ---------------------------------------------------------------------
	 * 1. Header — turn solid once the hero scrolls away.
	 * ------------------------------------------------------------------ */
	function initHeader() {
		var header = $('[data-pdu-header]');
		if (!header) { return; }

		var isFront = document.body.classList.contains('pdu-transparent-header');
		if (!isFront) { return; } // Interior pages are always solid.

		var ticking = false;
		function update() {
			header.classList.toggle('site-header--solid', window.scrollY > 40);
			ticking = false;
		}
		window.addEventListener('scroll', function () {
			if (!ticking) { window.requestAnimationFrame(update); ticking = true; }
		}, { passive: true });
		update();
	}

	/* ---------------------------------------------------------------------
	 * 2. Mobile drawer with a proper focus trap.
	 * ------------------------------------------------------------------ */
	function initDrawer() {
		var drawer = $('[data-pdu-drawer]');
		var toggle = $('[data-pdu-drawer-toggle]');
		if (!drawer || !toggle) { return; }

		var closers = $$('[data-pdu-drawer-close]', drawer);
		var lastFocused = null;

		var FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])';

		function open() {
			lastFocused = document.activeElement;
			drawer.classList.add('is-open');
			drawer.setAttribute('aria-hidden', 'false');
			toggle.setAttribute('aria-expanded', 'true');
			document.body.style.overflow = 'hidden';
			var first = drawer.querySelector(FOCUSABLE);
			if (first) { first.focus(); }
			document.addEventListener('keydown', onKeydown);
		}

		function close() {
			drawer.classList.remove('is-open');
			drawer.setAttribute('aria-hidden', 'true');
			toggle.setAttribute('aria-expanded', 'false');
			document.body.style.overflow = '';
			document.removeEventListener('keydown', onKeydown);
			if (lastFocused) { lastFocused.focus(); }
		}

		function onKeydown(e) {
			if (e.key === 'Escape') { close(); return; }
			if (e.key !== 'Tab') { return; }

			var items = $$(FOCUSABLE, drawer).filter(function (el) { return el.offsetParent !== null; });
			if (!items.length) { return; }

			var first = items[0];
			var last = items[items.length - 1];

			if (e.shiftKey && document.activeElement === first) {
				e.preventDefault(); last.focus();
			} else if (!e.shiftKey && document.activeElement === last) {
				e.preventDefault(); first.focus();
			}
		}

		toggle.addEventListener('click', function () {
			if (drawer.classList.contains('is-open')) { close(); } else { open(); }
		});
		closers.forEach(function (btn) { btn.addEventListener('click', close); });

		// Close after following an in-page link.
		$$('a', drawer).forEach(function (a) { a.addEventListener('click', close); });
	}

	/* ---------------------------------------------------------------------
	 * 3. Search panel.
	 * ------------------------------------------------------------------ */
	function initSearch() {
		var toggle = $('[data-pdu-search-toggle]');
		var panel = $('[data-pdu-search-panel]');
		if (!toggle || !panel) { return; }

		toggle.addEventListener('click', function () {
			var open = panel.classList.toggle('hidden') === false;
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			if (open) {
				var field = panel.querySelector('input[type="search"], input[type="text"]');
				if (field) { field.focus(); }
			}
		});

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && !panel.classList.contains('hidden')) {
				panel.classList.add('hidden');
				toggle.setAttribute('aria-expanded', 'false');
				toggle.focus();
			}
		});
	}

	/* ---------------------------------------------------------------------
	 * 4. Audio — one <audio> element shared by every track row.
	 * ------------------------------------------------------------------ */
	function initAudio() {
		var audio = document.getElementById('pdu-audio');
		var rows = $$('[data-pdu-track]');
		var status = $('[data-pdu-status]');
		if (!audio || !rows.length) { return; }

		var current = null;

		function fmt(sec) {
			if (!isFinite(sec) || sec < 0) { return '0:00'; }
			var m = Math.floor(sec / 60);
			var s = Math.floor(sec % 60);
			return m + ':' + (s < 10 ? '0' : '') + s;
		}

		function say(msg) { if (status) { status.textContent = msg; } }

		function reset(row) {
			if (!row) { return; }
			row.classList.remove('is-playing');
			var btn = $('[data-pdu-play]', row);
			if (btn) {
				btn.setAttribute('aria-pressed', 'false');
				$('.pdu-ico-play', btn).classList.remove('hidden');
				$('.pdu-ico-pause', btn).classList.add('hidden');
				var label = $('[data-pdu-btn-label]', btn);
				var title = $('p', row) ? $('p', row).textContent.trim() : '';
				if (label) { label.textContent = (i18n.play || 'Play') + ' ' + title; }
			}
			var eq = $('[data-pdu-eq]', row);
			if (eq) { eq.style.opacity = '0'; }
			var scrub = $('[data-pdu-scrub]', row);
			if (scrub) { scrub.value = 0; }
		}

		function play(row) {
			var src = row.getAttribute('data-src');

			if (current && current !== row) { reset(current); }

			if (current === row && !audio.paused) {
				audio.pause();
				return;
			}

			if (current !== row) {
				// No real file attached yet — announce instead of failing silently.
				if (!src) {
					say('Preview not available for this track yet.');
					return;
				}
				audio.src = src;
				current = row;
			}

			var p = audio.play();
			if (p && typeof p.catch === 'function') {
				p.catch(function () { say('Playback was blocked by the browser.'); });
			}
		}

		rows.forEach(function (row) {
			var btn = $('[data-pdu-play]', row);
			var scrub = $('[data-pdu-scrub]', row);

			if (btn) { btn.addEventListener('click', function () { play(row); }); }

			if (scrub) {
				scrub.addEventListener('input', function () {
					if (current === row && isFinite(audio.duration)) {
						audio.currentTime = (scrub.value / 100) * audio.duration;
					}
				});
			}
		});

		audio.addEventListener('play', function () {
			if (!current) { return; }
			current.classList.add('is-playing');
			var btn = $('[data-pdu-play]', current);
			var title = $('p', current) ? $('p', current).textContent.trim() : '';
			if (btn) {
				btn.setAttribute('aria-pressed', 'true');
				$('.pdu-ico-play', btn).classList.add('hidden');
				$('.pdu-ico-pause', btn).classList.remove('hidden');
				var label = $('[data-pdu-btn-label]', btn);
				if (label) { label.textContent = (i18n.pause || 'Pause') + ' ' + title; }
			}
			var eq = $('[data-pdu-eq]', current);
			if (eq) { eq.style.opacity = '1'; }
			say('Now playing: ' + title);
		});

		audio.addEventListener('pause', function () {
			if (current) {
				var eq = $('[data-pdu-eq]', current);
				if (eq) { eq.style.opacity = '0'; }
				var btn = $('[data-pdu-play]', current);
				if (btn) {
					btn.setAttribute('aria-pressed', 'false');
					$('.pdu-ico-play', btn).classList.remove('hidden');
					$('.pdu-ico-pause', btn).classList.add('hidden');
				}
				current.classList.remove('is-playing');
			}
			say('Paused.');
		});

		audio.addEventListener('timeupdate', function () {
			if (!current || !isFinite(audio.duration)) { return; }
			var scrub = $('[data-pdu-scrub]', current);
			var time = $('[data-pdu-time]', current);
			if (scrub) { scrub.value = (audio.currentTime / audio.duration) * 100; }
			if (time) { time.textContent = fmt(audio.currentTime) + ' / ' + fmt(audio.duration); }
		});

		audio.addEventListener('ended', function () { reset(current); current = null; });
		audio.addEventListener('error', function () { say('That track could not be loaded.'); reset(current); });
	}

	/* ---------------------------------------------------------------------
	 * 5. Scroll reveal.
	 * ------------------------------------------------------------------ */
	function initReveal() {
		var targets = $$('[data-pdu-reveal]');
		if (!targets.length) { return; }

		if (reduceMotion || !('IntersectionObserver' in window)) {
			targets.forEach(function (el) { el.style.opacity = '1'; });
			return;
		}

		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (!entry.isIntersecting) { return; }
				entry.target.classList.add('animate-rise');
				entry.target.style.opacity = '';
				io.unobserve(entry.target);
			});
		}, { rootMargin: '0px 0px -8% 0px', threshold: 0.06 });

		targets.forEach(function (el) { el.style.opacity = '0'; io.observe(el); });
	}

	/* ---------------------------------------------------------------------
	 * 6. Back to top.
	 * ------------------------------------------------------------------ */
	function initTop() {
		var btn = $('[data-pdu-top]');
		if (!btn) { return; }
		btn.addEventListener('click', function () {
			window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
			var skip = $('#main-content');
			if (skip) { skip.focus({ preventScroll: true }); }
		});
	}

	/* ---------------------------------------------------------------------
	 * 7. Lightbox for gallery tiles.
	 * ------------------------------------------------------------------ */
	function initLightbox() {
		var tiles = $$('[data-pdu-lightbox]');
		if (!tiles.length) { return; }

		var box = document.createElement('div');
		box.className = 'fixed inset-0 z-[200] hidden items-center justify-center bg-ink-900/97 p-4 backdrop-blur';
		box.setAttribute('role', 'dialog');
		box.setAttribute('aria-modal', 'true');
		box.setAttribute('aria-label', 'Artwork viewer');
		box.innerHTML =
			'<button type="button" class="absolute right-4 top-4 grid h-12 w-12 place-items-center border border-ink-300 text-bone-100 hover:border-blood-500" data-close>' +
			'<span class="screen-reader-text">Close</span>' +
			'<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>' +
			'</button>' +
			'<figure class="m-0 max-h-[88vh] max-w-5xl">' +
			'<img alt="" class="mx-auto max-h-[78vh] w-auto object-contain" />' +
			'<figcaption class="mt-4 text-center font-display text-xs uppercase tracking-brand text-bone-300"></figcaption>' +
			'</figure>';
		document.body.appendChild(box);

		var img = $('img', box);
		var cap = $('figcaption', box);
		var closeBtn = $('[data-close]', box);
		var opener = null;

		function open(src, alt, caption) {
			img.src = src;
			img.alt = alt || '';
			cap.textContent = caption || '';
			box.classList.remove('hidden');
			box.classList.add('flex');
			document.body.style.overflow = 'hidden';
			closeBtn.focus();
		}

		function close() {
			box.classList.add('hidden');
			box.classList.remove('flex');
			img.src = '';
			document.body.style.overflow = '';
			if (opener) { opener.focus(); }
		}

		tiles.forEach(function (tile) {
			tile.addEventListener('click', function (e) {
				e.preventDefault();
				opener = tile;
				var full = tile.getAttribute('data-full') || tile.getAttribute('href');
				var inner = tile.querySelector('img');
				open(full, inner ? inner.alt : '', tile.getAttribute('data-caption'));
			});
		});

		closeBtn.addEventListener('click', close);
		box.addEventListener('click', function (e) { if (e.target === box) { close(); } });
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && !box.classList.contains('hidden')) { close(); }
			// Keep focus inside the dialog.
			if (e.key === 'Tab' && !box.classList.contains('hidden')) { e.preventDefault(); closeBtn.focus(); }
		});
	}

	/* ---------------------------------------------------------------------
	 * 8. Cart count refresh after AJAX add-to-cart.
	 * ------------------------------------------------------------------ */
	function initCart() {
		var badge = $('[data-pdu-cart-count]');
		if (!badge || !window.pduData) { return; }

		document.body.addEventListener('added_to_cart', function () {
			fetch(window.pduData.ajaxUrl + '?action=pdu_cart_count', { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (res && res.success) {
						badge.childNodes[0].nodeValue = res.data.count;
						badge.classList.toggle('hidden', res.data.count < 1);
					}
				})
				.catch(function () { /* Non-critical. */ });
		});
	}

	/* ------------------------------------------------------------------ */
	function boot() {
		initHeader();
		initDrawer();
		initSearch();
		initAudio();
		initReveal();
		initTop();
		initLightbox();
		initCart();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
