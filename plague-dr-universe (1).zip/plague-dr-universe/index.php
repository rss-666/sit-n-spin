<?php
/**
 * Main fallback template — blog index and any query without a more specific template.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="<?php echo esc_attr( pdu_content_offset_class() ); ?>">
	<?php get_template_part( 'template-parts/components/page-header' ); ?>

	<div class="container section-tight">
		<div class="grid gap-14 <?php echo is_active_sidebar( 'sidebar-1' ) ? 'lg:grid-cols-12' : ''; ?>">

			<div class="<?php echo is_active_sidebar( 'sidebar-1' ) ? 'lg:col-span-8' : ''; ?>">
				<?php if ( have_posts() ) : ?>
					<div class="grid gap-8 sm:grid-cols-2">
						<?php
						while ( have_posts() ) :
							the_post();
							get_template_part( 'template-parts/content/card', get_post_type() );
						endwhile;
						?>
					</div>

					<?php pdu_pagination(); ?>
				<?php else : ?>
					<?php get_template_part( 'template-parts/content/none' ); ?>
				<?php endif; ?>
			</div>

			<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
				<aside class="lg:col-span-4" aria-label="<?php esc_attr_e( 'Sidebar', 'plague-dr-universe' ); ?>">
					<?php dynamic_sidebar( 'sidebar-1' ); ?>
				</aside>
			<?php endif; ?>
		</div>
	</div>
</div>

<?php
get_footer();
