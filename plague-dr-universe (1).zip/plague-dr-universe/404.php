<?php
/**
 * 404 — not found.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<section class="relative flex min-h-[80svh] items-center overflow-hidden">
	<img src="<?php echo esc_url( pdu_img( 'rain-street-noir.jpg' ) ); ?>"
			alt=""
			class="absolute inset-0 h-full w-full object-cover opacity-35"
			decoding="async" width="1024" height="1024">
	<div class="absolute inset-0 bg-gradient-to-r from-ink-900 via-ink-900/92 to-ink-900/60" aria-hidden="true"></div>

	<div class="container relative py-24">
		<div class="max-w-2xl">
			<p class="eyebrow"><?php esc_html_e( 'Error 404', 'plague-dr-universe' ); ?></p>

			<h1 class="text-display-lg">
				<?php esc_html_e( 'This street does not exist', 'plague-dr-universe' ); ?>
			</h1>

			<p class="lede mt-6">
				<?php esc_html_e( 'The page you were looking for has been moved, retired, or was never here to begin with. The rain has not stopped either way.', 'plague-dr-universe' ); ?>
			</p>

			<div class="mt-8 max-w-md">
				<?php get_search_form(); ?>
			</div>

			<div class="mt-8 flex flex-wrap gap-4">
				<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php esc_html_e( 'Back to the homepage', 'plague-dr-universe' ); ?>
				</a>
				<a class="btn btn-ghost" href="<?php echo esc_url( home_url( '/chapters/' ) ); ?>">
					<?php esc_html_e( 'Read the graphic novel', 'plague-dr-universe' ); ?>
				</a>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();
