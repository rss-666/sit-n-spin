<?php
/**
 * Template Name: The Universe (Lore Hub)
 * Template Post Type: page
 *
 * Immersive narrative lore page detailing the crossover between the artwork,
 * the musical compositions and the graphic novel storyline.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<?php // ---------- Cinematic hero ---------- ?>
<section class="relative flex min-h-[70svh] items-center overflow-hidden" aria-labelledby="pdu-universe-title">
	<img src="<?php echo esc_url( has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'pdu-hero' ) : pdu_img( 'rain-street-noir.jpg' ) ); ?>"
			alt=""
			class="absolute inset-0 h-full w-full object-cover"
			fetchpriority="high" decoding="async" width="1024" height="1024">
	<div class="absolute inset-0 bg-gradient-to-r from-ink-900 via-ink-900/88 to-ink-900/45" aria-hidden="true"></div>
	<div class="hero-siren" aria-hidden="true"></div>

	<div class="container relative py-28 md:py-36">
		<div class="max-w-3xl">
			<?php pdu_breadcrumbs(); ?>
			<p class="eyebrow"><?php esc_html_e( 'The Lore', 'plague-dr-universe' ); ?></p>
			<h1 id="pdu-universe-title" class="text-display-xl text-shadow-hard">
				<?php esc_html_e( 'The', 'plague-dr-universe' ); ?>
				<span class="text-blood-500"><?php esc_html_e( 'Universe', 'plague-dr-universe' ); ?></span>
			</h1>
			<p class="lede mt-6 text-xl text-shadow-hard">
				<?php esc_html_e( 'Three mediums, one continuity. Here is how the ink, the noise and the story feed each other — and why none of them work alone.', 'plague-dr-universe' ); ?>
			</p>
		</div>
	</div>
</section>

<?php // ---------- Origin ---------- ?>
<section class="section" aria-labelledby="pdu-origin">
	<div class="container">
		<div class="grid gap-14 lg:grid-cols-12 lg:gap-20">
			<div class="lg:col-span-7">
				<p class="eyebrow"><?php esc_html_e( 'Origin', 'plague-dr-universe' ); ?></p>
				<h2 id="pdu-origin" class="section-title"><?php esc_html_e( 'It Started With a Sound', 'plague-dr-universe' ); ?></h2>

				<div class="prose-pdu mt-6">
					<p>
						<?php esc_html_e( 'The Plague Dr Universe began as a single recording made on a fire escape at three in the morning: rain on a metal railing, a siren four blocks out, and nothing else. That two minutes of tape became the opening of the first record — and the first panel of the first chapter was drawn to match it, frame for frame.', 'plague-dr-universe' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Everything since has been built the same way. The story is not illustrated after the fact and the music is not scored to finished pages. They are made in the same room, in the same week, arguing with each other until both are right.', 'plague-dr-universe' ); ?>
					</p>

					<h3><?php esc_html_e( 'The setting', 'plague-dr-universe' ); ?></h3>
					<p>
						<?php esc_html_e( 'A Pacific Northwest city that is permanently two days after something bad. Emergency light on wet brick. Storefronts that reopened too quickly. Bus shelters where people still stand a little further apart than they used to. It is recognisably Seattle — First Avenue, the Needle, the waterfront, the drawbridges — rendered in the register of a place that keeps its receipts.', 'plague-dr-universe' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'The city is not a backdrop. In the books it behaves like a character with a grudge: streets that repeat, reflections that arrive a half-second late, a wheel on the waterfront that keeps turning long after the last rider got off.', 'plague-dr-universe' ); ?>
					</p>

					<h3><?php esc_html_e( 'The Doctor', 'plague-dr-universe' ); ?></h3>
					<p>
						<?php esc_html_e( 'Waxed leather, brass buckles, a beak stitched from a single piece of hide, and a cane he does not appear to need. Nobody in the story agrees on what he is. The official position is that he is a man in a costume. The working position, held by everyone who has actually met him, is that he arrives shortly before the worst part and stays until it is over.', 'plague-dr-universe' ); ?>
					</p>
					<blockquote>
						<?php esc_html_e( 'He is not the plague. He is what the plague sends when it wants a second opinion.', 'plague-dr-universe' ); ?>
					</blockquote>
					<p>
						<?php esc_html_e( 'He does not speak in the first three chapters. When he finally does, in Chapter Four, it is one sentence, and readers have been arguing about it since.', 'plague-dr-universe' ); ?>
					</p>
				</div>
			</div>

			<aside class="lg:col-span-5">
				<div class="sticky top-28 space-y-6">
					<figure class="m-0 overflow-hidden border border-ink-400">
						<img src="<?php echo esc_url( pdu_img( 'plague-doctor-first-ave.jpg' ) ); ?>"
								alt="<?php esc_attr_e( 'The Plague Doctor in a beaked leather mask, brass goggles and a long studded coat, standing on First Avenue', 'plague-dr-universe' ); ?>"
								class="w-full object-cover" loading="lazy" decoding="async" width="1024" height="1536">
						<figcaption class="border-t border-ink-400 bg-ink-800 p-4 meta">
							<?php esc_html_e( 'Reference plate — First Avenue, 22:08', 'plague-dr-universe' ); ?>
						</figcaption>
					</figure>

					<div class="border border-ink-400 bg-ink-800 p-6">
						<h3 class="text-base"><?php esc_html_e( 'Canon at a glance', 'plague-dr-universe' ); ?></h3>
						<dl class="mt-4 space-y-3 text-sm">
							<?php
							$pdu_canon = array(
								__( 'Setting', 'plague-dr-universe' )   => __( 'Seattle, present day, permanently raining', 'plague-dr-universe' ),
								__( 'Chapters', 'plague-dr-universe' )  => __( 'Six released, ongoing', 'plague-dr-universe' ),
								__( 'Records', 'plague-dr-universe' )   => __( 'Two — Emerald Rot, The Plague Dr Suite', 'plague-dr-universe' ),
								__( 'Genre', 'plague-dr-universe' )     => __( 'Comic noir / dark fantasy', 'plague-dr-universe' ),
								__( 'Rating', 'plague-dr-universe' )    => __( 'Mature — atmospheric dread, not gore', 'plague-dr-universe' ),
							);
							foreach ( $pdu_canon as $k => $v ) :
								?>
								<div class="flex justify-between gap-4 border-b border-ink-500 pb-3">
									<dt class="meta shrink-0"><?php echo esc_html( $k ); ?></dt>
									<dd class="m-0 text-right text-bone-200"><?php echo esc_html( $v ); ?></dd>
								</div>
							<?php endforeach; ?>
						</dl>
					</div>
				</div>
			</aside>
		</div>
	</div>
</section>

<?php // ---------- The crossover ---------- ?>
<section class="section border-y border-ink-400 bg-ink-800/50" aria-labelledby="pdu-crossover">
	<div class="container">
		<?php
		pdu_section_heading(
			array(
				'eyebrow' => __( 'The Crossover', 'plague-dr-universe' ),
				'title'   => __( 'How the Three Threads Braid', 'plague-dr-universe' ),
				'lede'    => __( 'Each medium carries information the others cannot. Read only the book and you get the plot. Hear only the record and you get the feeling. Take all three and you get the truth.', 'plague-dr-universe' ),
				'id'      => 'pdu-crossover',
				'align'   => 'center',
			)
		);
		?>

		<div class="grid gap-8 md:grid-cols-3">
			<?php
			$pdu_threads = array(
				array(
					'icon'  => 'book',
					'kick'  => __( 'Thread One', 'plague-dr-universe' ),
					'title' => __( 'The Page', 'plague-dr-universe' ),
					'body'  => __( 'The graphic novel carries the plot and the dialogue. It is deliberately sparse — long silent sequences, heavy blacks, and page turns timed to land on an image rather than a line. What the page will not tell you is what anyone is feeling.', 'plague-dr-universe' ),
					'link'  => home_url( '/chapters/' ),
					'cta'   => __( 'Read the chapters', 'plague-dr-universe' ),
					'img'   => 'space-needle-square.jpg',
					'alt'   => __( 'The Space Needle in rain lit red and blue', 'plague-dr-universe' ),
				),
				array(
					'icon'  => 'disc',
					'kick'  => __( 'Thread Two', 'plague-dr-universe' ),
					'title' => __( 'The Record', 'plague-dr-universe' ),
					'body'  => __( 'The soundtrack carries the interior life. Every chapter has a corresponding track, and the lyrics are the closest thing the books have to narration. Where a character should be monologuing, there is a riff instead.', 'plague-dr-universe' ),
					'link'  => home_url( '/soundtracks/' ),
					'cta'   => __( 'Hear the records', 'plague-dr-universe' ),
					'img'   => 'great-wheel-rain.jpg',
					'alt'   => __( 'The Great Wheel at night in heavy rain', 'plague-dr-universe' ),
				),
				array(
					'icon'  => 'palette',
					'kick'  => __( 'Thread Three', 'plague-dr-universe' ),
					'title' => __( 'The Plates', 'plague-dr-universe' ),
					'body'  => __( 'The standalone artwork carries the world. City plates, character studies and objects that never appear in the story but explain it anyway. Several plates contain details that will not pay off in the books for another two chapters.', 'plague-dr-universe' ),
					'link'  => home_url( '/artwork/' ),
					'cta'   => __( 'See the plates', 'plague-dr-universe' ),
					'img'   => 'rain-street-noir.jpg',
					'alt'   => __( 'Empty rain-slicked street at night with red and blue reflections', 'plague-dr-universe' ),
				),
			);

			foreach ( $pdu_threads as $pdu_thread ) :
				?>
				<article class="card flex flex-col" data-pdu-reveal>
					<div class="card-media aspect-[16/10]">
						<img src="<?php echo esc_url( pdu_img( $pdu_thread['img'] ) ); ?>"
								alt="<?php echo esc_attr( $pdu_thread['alt'] ); ?>"
								loading="lazy" decoding="async" width="1024" height="640">
						<span class="absolute left-4 top-4 grid h-11 w-11 place-items-center border border-amber-500/60 bg-ink-900/85 text-amber-400">
							<?php pdu_the_icon( $pdu_thread['icon'], 20 ); ?>
						</span>
					</div>

					<div class="card-body flex flex-1 flex-col">
						<p class="meta text-blood-400"><?php echo esc_html( $pdu_thread['kick'] ); ?></p>
						<h3 class="card-title mt-2"><?php echo esc_html( $pdu_thread['title'] ); ?></h3>
						<p class="mt-3 flex-1 text-sm leading-relaxed text-bone-300"><?php echo esc_html( $pdu_thread['body'] ); ?></p>
						<a class="stretched-link mt-5 inline-flex items-center gap-2 font-display text-xs uppercase tracking-brand text-amber-400 no-underline"
							href="<?php echo esc_url( $pdu_thread['link'] ); ?>">
							<?php echo esc_html( $pdu_thread['cta'] ); ?>
							<?php pdu_the_icon( 'arrow', 14 ); ?>
						</a>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php // ---------- Timeline ---------- ?>
<section class="section" aria-labelledby="pdu-timeline">
	<div class="container">
		<?php
		pdu_section_heading(
			array(
				'eyebrow' => __( 'Continuity', 'plague-dr-universe' ),
				'title'   => __( 'The Order It Happened In', 'plague-dr-universe' ),
				'lede'    => __( 'If you are starting from zero, this is the intended sequence. Each chapter pairs with the track beside it.', 'plague-dr-universe' ),
				'id'      => 'pdu-timeline',
			)
		);
		?>

		<ol class="relative m-0 list-none space-y-6 border-l-2 border-ink-400 p-0 pl-8 md:pl-12">
			<?php
			$pdu_timeline = array(
				array( '01', __( 'The Silence Between Sirens', 'plague-dr-universe' ), __( 'Sirens in the Distance', 'plague-dr-universe' ), __( 'The Doctor walks the block two days after. Establishes the city, the rain, and the fact that nobody will look directly at him.', 'plague-dr-universe' ) ),
				array( '02', __( 'Needle Through the Rain', 'plague-dr-universe' ), __( 'Take the Streets Back', 'plague-dr-universe' ), __( 'The story goes vertical. First appearance of the patient who should not be walking, and the first time the Doctor is clearly seen by someone else.', 'plague-dr-universe' ) ),
				array( '03', __( 'The Great Wheel Turns Anyway', 'plague-dr-universe' ), __( 'No Answers in the Rain', 'plague-dr-universe' ), __( 'The quietest chapter. Eleven of thirty pages have no dialogue at all. The waterfront sequence that most readers cite as the moment it clicked.', 'plague-dr-universe' ) ),
				array( '04', __( 'Ballard, Bridge Up', 'plague-dr-universe' ), __( 'Ballard Drawbridge', 'plague-dr-universe' ), __( 'Stopped traffic, a raised bridge, and the one line of dialogue the Doctor speaks in the entire first volume.', 'plague-dr-universe' ) ),
				array( '05', __( 'Beak &amp; Bone', 'plague-dr-universe' ), __( 'Beak &amp; Bone', 'plague-dr-universe' ), __( 'The origin chapter, told entirely in flashback plates with no panel borders. Where the mask came from, and what is under it.', 'plague-dr-universe' ) ),
				array( '06', __( 'The Quiet Runs Too Deep', 'plague-dr-universe' ), __( 'Quiet Runs Too Deep', 'plague-dr-universe' ), __( 'Volume One closes. The city gets one clear morning. Nobody trusts it.', 'plague-dr-universe' ) ),
			);

			foreach ( $pdu_timeline as $pdu_row ) :
				?>
				<li class="relative">
					<span class="absolute -left-[2.6rem] top-1 grid h-9 w-9 place-items-center border border-blood-600 bg-ink-900 font-display text-xs text-blood-400 md:-left-[3.85rem]">
						<?php echo esc_html( $pdu_row[0] ); ?>
					</span>

					<div class="border border-ink-400 bg-ink-800 p-6 transition-colors hover:border-blood-600">
						<div class="flex flex-wrap items-baseline justify-between gap-3">
							<h3 class="m-0 text-lg"><?php echo wp_kses_post( $pdu_row[1] ); ?></h3>
							<p class="meta m-0 flex items-center gap-2 text-amber-400">
								<?php pdu_the_icon( 'disc', 14 ); ?>
								<?php echo wp_kses_post( $pdu_row[2] ); ?>
							</p>
						</div>
						<p class="mt-3 text-sm leading-relaxed text-bone-300"><?php echo esc_html( $pdu_row[3] ); ?></p>
					</div>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>

<?php // ---------- Editor content ---------- ?>
<?php
while ( have_posts() ) :
	the_post();
	$pdu_body = trim( get_the_content() );
	if ( $pdu_body ) :
		?>
		<section class="section-tight border-t border-ink-400">
			<div class="container">
				<div class="mx-auto max-w-3xl prose-pdu"><?php the_content(); ?></div>
			</div>
		</section>
		<?php
	endif;
endwhile;
?>

<?php // ---------- CTA ---------- ?>
<section class="section-tight border-t border-ink-400 bg-ink-800/50">
	<div class="container text-center">
		<h2 class="text-display-md"><?php esc_html_e( 'Start at Chapter One', 'plague-dr-universe' ); ?></h2>
		<p class="lede mx-auto mt-4"><?php esc_html_e( 'Read it with the record playing. That is how it was built.', 'plague-dr-universe' ); ?></p>
		<div class="mt-8 flex flex-wrap justify-center gap-4">
			<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/chapters/' ) ); ?>">
				<?php pdu_the_icon( 'book', 16 ); ?>
				<?php esc_html_e( 'Read the graphic novel', 'plague-dr-universe' ); ?>
			</a>
			<a class="btn btn-secondary" href="<?php echo esc_url( home_url( '/media/' ) ); ?>">
				<?php pdu_the_icon( 'play', 14 ); ?>
				<?php esc_html_e( 'Play the soundtrack', 'plague-dr-universe' ); ?>
			</a>
		</div>
	</div>
</section>

<?php
get_footer();
