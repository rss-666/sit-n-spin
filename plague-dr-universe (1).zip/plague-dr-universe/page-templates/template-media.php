<?php
/**
 * Template Name: Media / Gallery Hub
 * Template Post Type: page
 *
 * Dedicated audio player sections, embedded video showcases and the high-res
 * visual art / comic illustration portfolio grid.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="<?php echo esc_attr( pdu_content_offset_class() ); ?>">

	<?php
	get_template_part(
		'template-parts/components/page-header',
		null,
		array(
			'title' => __( 'Media', 'plague-dr-universe' ),
			'lede'  => __( 'Everything with a play button or a frame around it. Stream the records, watch the releases, and browse the full-resolution art portfolio.', 'plague-dr-universe' ),
			'image' => has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'pdu-hero' ) : pdu_img( 'great-wheel-rain.jpg' ),
		)
	);
	?>

	<?php // ---------- Jump nav ---------- ?>
	<nav class="sticky top-[4.5rem] z-30 border-b border-ink-400 bg-ink-900/95 backdrop-blur-md"
			aria-label="<?php esc_attr_e( 'Media sections', 'plague-dr-universe' ); ?>">
		<div class="container">
			<ul class="no-scrollbar -mx-1 flex list-none gap-1 overflow-x-auto p-0 py-3">
				<?php
				$pdu_jump = array(
					'#audio'     => array( 'disc', __( 'Soundtracks', 'plague-dr-universe' ) ),
					'#video'     => array( 'video', __( 'Video', 'plague-dr-universe' ) ),
					'#portfolio' => array( 'palette', __( 'Art Portfolio', 'plague-dr-universe' ) ),
					'#comics'    => array( 'book', __( 'Comic Panels', 'plague-dr-universe' ) ),
				);
				foreach ( $pdu_jump as $pdu_href => $pdu_item ) :
					?>
					<li>
						<a class="inline-flex shrink-0 items-center gap-2 border border-ink-400 px-4 py-2.5 font-display text-xs uppercase tracking-brand text-bone-200 no-underline transition-colors hover:border-blood-500 hover:text-white"
							href="<?php echo esc_attr( $pdu_href ); ?>">
							<?php pdu_the_icon( $pdu_item[0], 15 ); ?>
							<?php echo esc_html( $pdu_item[1] ); ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</nav>

	<?php // ================= AUDIO ================= ?>
	<section id="audio" class="section" aria-labelledby="pdu-media-audio">
		<div class="container">
			<?php
			pdu_section_heading(
				array(
					'eyebrow'  => __( 'Listen', 'plague-dr-universe' ),
					'title'    => __( 'The Soundtracks', 'plague-dr-universe' ),
					'lede'     => __( 'Two records, written chapter by chapter. Previews stream here; full lossless downloads come with every album purchase.', 'plague-dr-universe' ),
					'cta_url'  => pdu_shop_url( 'music-albums' ),
					'cta_text' => __( 'Buy the albums', 'plague-dr-universe' ),
					'id'       => 'pdu-media-audio',
				)
			);
			?>

			<?php
			$pdu_tracks_q = new WP_Query(
				array(
					'post_type'      => 'pdu_track',
					'posts_per_page' => 20,
					'no_found_rows'  => true,
				)
			);

			$pdu_albums = array();

			if ( $pdu_tracks_q->have_posts() ) {
				while ( $pdu_tracks_q->have_posts() ) {
					$pdu_tracks_q->the_post();
					$pdu_album = (string) get_post_meta( get_the_ID(), 'pdu_album', true );
					$pdu_album = $pdu_album ? $pdu_album : __( 'Singles', 'plague-dr-universe' );

					$pdu_albums[ $pdu_album ][] = array(
						'title'  => get_the_title(),
						'album'  => $pdu_album,
						'length' => (string) get_post_meta( get_the_ID(), 'pdu_duration', true ),
						'src'    => (string) get_post_meta( get_the_ID(), 'pdu_audio_url', true ),
						'tag'    => '',
					);
				}
				wp_reset_postdata();
			} else {
				$pdu_albums = array(
					__( 'Emerald Rot', 'plague-dr-universe' )        => array(
						array( 'title' => __( 'Sirens in the Distance', 'plague-dr-universe' ), 'album' => __( 'Side A', 'plague-dr-universe' ), 'length' => '2:14', 'src' => '', 'tag' => __( 'Ambient', 'plague-dr-universe' ) ),
						array( 'title' => __( 'Take the Streets Back', 'plague-dr-universe' ), 'album' => __( 'Side A', 'plague-dr-universe' ), 'length' => '3:48', 'src' => '', 'tag' => __( 'Heavy', 'plague-dr-universe' ) ),
						array( 'title' => __( 'No Answers in the Rain', 'plague-dr-universe' ), 'album' => __( 'Side B', 'plague-dr-universe' ), 'length' => '5:02', 'src' => '', 'tag' => __( 'Piano / Doom', 'plague-dr-universe' ) ),
						array( 'title' => __( 'Ballard Drawbridge', 'plague-dr-universe' ), 'album' => __( 'Side B', 'plague-dr-universe' ), 'length' => '4:31', 'src' => '', 'tag' => __( 'Industrial', 'plague-dr-universe' ) ),
					),
					__( 'The Plague Dr Suite', 'plague-dr-universe' ) => array(
						array( 'title' => __( 'Beak &amp; Bone', 'plague-dr-universe' ), 'album' => __( 'Suite I', 'plague-dr-universe' ), 'length' => '6:19', 'src' => '', 'tag' => __( 'Doom', 'plague-dr-universe' ) ),
						array( 'title' => __( 'Quiet Runs Too Deep', 'plague-dr-universe' ), 'album' => __( 'Suite II', 'plague-dr-universe' ), 'length' => '4:07', 'src' => '', 'tag' => __( 'Ambient', 'plague-dr-universe' ) ),
						array( 'title' => __( 'Shadows Stretch', 'plague-dr-universe' ), 'album' => __( 'Suite III', 'plague-dr-universe' ), 'length' => '7:44', 'src' => '', 'tag' => __( 'Drone', 'plague-dr-universe' ) ),
					),
				);
			}

			$pdu_covers = array( 'great-wheel-rain.jpg', 'space-needle-square.jpg', 'rain-street-noir.jpg' );
			$pdu_ai     = 0;
			$pdu_index  = 0;
			?>

			<div class="space-y-10">
				<?php foreach ( $pdu_albums as $pdu_album_name => $pdu_album_tracks ) : ?>
					<div class="grid gap-8 lg:grid-cols-12">
						<?php // Album art. ?>
						<div class="lg:col-span-4">
							<div class="sticky top-40 overflow-hidden border border-ink-400">
								<img src="<?php echo esc_url( pdu_img( $pdu_covers[ $pdu_ai % count( $pdu_covers ) ] ) ); ?>"
										alt="<?php echo esc_attr( sprintf( /* translators: %s: album name. */ __( 'Album artwork for %s', 'plague-dr-universe' ), wp_strip_all_tags( $pdu_album_name ) ) ); ?>"
										class="aspect-square w-full object-cover"
										loading="lazy" decoding="async" width="800" height="800">
								<div class="border-t border-ink-400 bg-ink-800 p-5">
									<h3 class="m-0 text-lg"><?php echo wp_kses_post( $pdu_album_name ); ?></h3>
									<p class="meta mt-2">
										<?php
										printf(
											/* translators: %d: number of tracks. */
											esc_html( _n( '%d track', '%d tracks', count( $pdu_album_tracks ), 'plague-dr-universe' ) ),
											count( $pdu_album_tracks )
										);
										?>
									</p>
									<a class="btn btn-secondary btn-sm mt-4 w-full" href="<?php echo esc_url( pdu_shop_url( 'music-albums' ) ); ?>">
										<?php pdu_the_icon( 'cart', 14 ); ?>
										<?php esc_html_e( 'Buy this record', 'plague-dr-universe' ); ?>
									</a>
								</div>
							</div>
						</div>

						<?php // Track list. ?>
						<div class="lg:col-span-8">
							<ul class="list-none space-y-3 p-0">
								<?php
								foreach ( $pdu_album_tracks as $pdu_track ) {
									$pdu_track['index'] = $pdu_index++;
									pdu_audio_track( $pdu_track );
								}
								?>
							</ul>
						</div>
					</div>
					<?php ++$pdu_ai; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<?php // ================= VIDEO ================= ?>
	<section id="video" class="section border-y border-ink-400 bg-ink-800/50" aria-labelledby="pdu-media-video">
		<div class="container">
			<?php
			pdu_section_heading(
				array(
					'eyebrow' => __( 'Watch', 'plague-dr-universe' ),
					'title'   => __( 'Video Releases', 'plague-dr-universe' ),
					'lede'    => __( 'Music videos, animatics and process films. Third-party players only load once you press play — no tracking cookies before then.', 'plague-dr-universe' ),
					'id'      => 'pdu-media-video',
				)
			);
			?>

			<?php
			$pdu_videos_q = new WP_Query(
				array(
					'post_type'      => 'pdu_video',
					'posts_per_page' => 6,
					'no_found_rows'  => true,
				)
			);
			?>

			<div class="grid gap-8 md:grid-cols-2">
				<?php if ( $pdu_videos_q->have_posts() ) : ?>
					<?php
					while ( $pdu_videos_q->have_posts() ) :
						$pdu_videos_q->the_post();
						?>
						<article class="card" data-pdu-reveal>
							<div class="card-media aspect-video">
								<?php pdu_featured_image( get_the_ID(), 'pdu-wide' ); ?>
								<a class="absolute inset-0 grid place-items-center bg-ink-900/45 transition-colors hover:bg-ink-900/20" href="<?php the_permalink(); ?>">
									<span class="grid h-16 w-16 place-items-center rounded-full border-2 border-white/85 bg-blood-600/85 text-white transition-transform hover:scale-110">
										<?php pdu_the_icon( 'play', 24 ); ?>
									</span>
									<span class="screen-reader-text"><?php the_title(); ?></span>
								</a>
							</div>
							<div class="card-body">
								<h3 class="card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<p class="mt-3 text-sm text-bone-300"><?php echo esc_html( get_the_excerpt() ); ?></p>
							</div>
						</article>
						<?php
					endwhile;
					wp_reset_postdata();
					?>
				<?php else : ?>
					<?php
					$pdu_vid_fallback = array(
						array( __( 'Take the Streets Back — Official Video', 'plague-dr-universe' ), '3:48', 'space-needle-square.jpg', __( 'Rain-slicked asphalt, a stopped school bus at the drawbridge, and dog tags swinging from a rearview mirror.', 'plague-dr-universe' ), __( 'Still of the Space Needle in rain lit red and blue', 'plague-dr-universe' ) ),
						array( __( 'Chapter Two — Animatic', 'plague-dr-universe' ), '2:06', 'storyboard-contact-sheet.jpg', __( 'The full sequence board for Chapter Two, cut against the finished score to find the page turns.', 'plague-dr-universe' ), __( 'Storyboard contact sheet of rainy night scenes', 'plague-dr-universe' ) ),
						array( __( 'Behind the Glass — Painting the Waterfront', 'plague-dr-universe' ), '8:12', 'great-wheel-rain.jpg', __( 'Two hours of layering compressed into eight minutes, from grey block-in to final wash.', 'plague-dr-universe' ), __( 'The Great Wheel at night in the rain', 'plague-dr-universe' ) ),
						array( __( 'Sirens — Visualiser', 'plague-dr-universe' ), '2:14', 'rain-street-noir.jpg', __( 'A single locked-off shot of an empty intersection for the length of the opening track.', 'plague-dr-universe' ), __( 'Empty rain-slicked intersection at night', 'plague-dr-universe' ) ),
					);

					foreach ( $pdu_vid_fallback as $pdu_v ) :
						?>
						<article class="card" data-pdu-reveal>
							<div class="card-media aspect-video">
								<img src="<?php echo esc_url( pdu_img( $pdu_v[2] ) ); ?>"
										alt="<?php echo esc_attr( $pdu_v[4] ); ?>"
										loading="lazy" decoding="async" width="1024" height="576">
								<a class="absolute inset-0 grid place-items-center bg-ink-900/45 transition-colors hover:bg-ink-900/20"
									href="<?php echo esc_url( home_url( '/videos/' ) ); ?>">
									<span class="grid h-16 w-16 place-items-center rounded-full border-2 border-white/85 bg-blood-600/85 text-white transition-transform hover:scale-110">
										<?php pdu_the_icon( 'play', 24 ); ?>
									</span>
									<span class="screen-reader-text">
										<?php
										/* translators: %s: video title. */
										printf( esc_html__( 'Play %s', 'plague-dr-universe' ), esc_html( $pdu_v[0] ) );
										?>
									</span>
								</a>
								<span class="absolute bottom-3 right-3 bg-ink-900/90 px-2 py-1 font-display text-[0.68rem] tracking-brand text-bone-100">
									<?php echo esc_html( $pdu_v[1] ); ?>
								</span>
							</div>
							<div class="card-body">
								<h3 class="card-title"><?php echo esc_html( $pdu_v[0] ); ?></h3>
								<p class="mt-3 text-sm leading-relaxed text-bone-300"><?php echo esc_html( $pdu_v[3] ); ?></p>
							</div>
						</article>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<?php // ================= PORTFOLIO ================= ?>
	<section id="portfolio" class="section" aria-labelledby="pdu-media-art">
		<div class="container">
			<?php
			pdu_section_heading(
				array(
					'eyebrow'  => __( 'Look', 'plague-dr-universe' ),
					'title'    => __( 'Visual Art Portfolio', 'plague-dr-universe' ),
					'lede'     => __( 'High-resolution plates and studies. Select any piece to open it full-size — every one is available as an archival print.', 'plague-dr-universe' ),
					'cta_url'  => pdu_shop_url( 'original-artwork' ),
					'cta_text' => __( 'Buy prints', 'plague-dr-universe' ),
					'id'       => 'pdu-media-art',
				)
			);
			?>

			<?php
			$pdu_art_q = new WP_Query(
				array(
					'post_type'      => 'pdu_artwork',
					'posts_per_page' => 12,
					'no_found_rows'  => true,
				)
			);
			?>

			<div class="columns-1 gap-4 sm:columns-2 lg:columns-3 [&>*]:mb-4 [&>*]:break-inside-avoid">
				<?php if ( $pdu_art_q->have_posts() ) : ?>
					<?php
					while ( $pdu_art_q->have_posts() ) :
						$pdu_art_q->the_post();
						$pdu_full = get_the_post_thumbnail_url( get_the_ID(), 'full' );
						?>
						<a class="tile block"
							href="<?php the_permalink(); ?>"
							data-pdu-lightbox
							data-full="<?php echo esc_url( $pdu_full ? $pdu_full : pdu_img( 'plague-doctor-first-ave.jpg' ) ); ?>"
							data-caption="<?php echo esc_attr( wp_strip_all_tags( get_the_title() ) ); ?>">
							<?php pdu_featured_image( get_the_ID(), 'large' ); ?>
							<span class="tile-cap block">
								<span class="block font-display text-base uppercase text-bone-50"><?php the_title(); ?></span>
								<span class="meta mt-1 block"><?php echo esc_html( get_post_meta( get_the_ID(), 'pdu_dimensions', true ) ); ?></span>
							</span>
						</a>
						<?php
					endwhile;
					wp_reset_postdata();
					?>
				<?php else : ?>
					<?php
					$pdu_art_fallback = array(
						array( 'plague-doctor-first-ave.jpg', __( 'First Avenue, 22:08', 'plague-dr-universe' ), __( 'Digital plate · 24×36 in', 'plague-dr-universe' ), __( 'The Plague Doctor in leather coat and beaked mask outside a brick storefront on First Avenue', 'plague-dr-universe' ) ),
						array( 'space-needle-rain.jpg', __( 'Needle, Red Shift', 'plague-dr-universe' ), __( 'City plate · 30×16 in', 'plague-dr-universe' ), __( 'The Space Needle in heavy rain lit red and blue from street level', 'plague-dr-universe' ) ),
						array( 'great-wheel-rain.jpg', __( 'The Wheel Keeps Turning', 'plague-dr-universe' ), __( 'City plate · 30×16 in', 'plague-dr-universe' ), __( 'The Great Wheel at night on the waterfront in heavy rain', 'plague-dr-universe' ) ),
						array( 'rain-street-noir.jpg', __( 'Downtown, No Witnesses', 'plague-dr-universe' ), __( 'Background study · 24×24 in', 'plague-dr-universe' ), __( 'An empty rain-slicked downtown street at night with red and blue reflections', 'plague-dr-universe' ) ),
						array( 'space-needle-square.jpg', __( 'Needle, Square Crop', 'plague-dr-universe' ), __( 'Study · 20×20 in', 'plague-dr-universe' ), __( 'Square-format study of the Space Needle in rain', 'plague-dr-universe' ) ),
						array( 'storyboard-contact-sheet.jpg', __( 'Sequence Board — Chapter Two', 'plague-dr-universe' ), __( 'Contact sheet · 24×24 in', 'plague-dr-universe' ), __( 'Sixteen-panel storyboard contact sheet of rainy night-time city scenes', 'plague-dr-universe' ) ),
					);

					foreach ( $pdu_art_fallback as $pdu_a ) :
						?>
						<a class="tile block"
							href="<?php echo esc_url( pdu_img( $pdu_a[0] ) ); ?>"
							data-pdu-lightbox
							data-full="<?php echo esc_url( pdu_img( $pdu_a[0] ) ); ?>"
							data-caption="<?php echo esc_attr( $pdu_a[1] . ' — ' . $pdu_a[2] ); ?>">
							<img src="<?php echo esc_url( pdu_img( $pdu_a[0] ) ); ?>"
									alt="<?php echo esc_attr( $pdu_a[3] ); ?>"
									loading="lazy" decoding="async" width="1024" height="1024">
							<span class="tile-cap block">
								<span class="block font-display text-base uppercase text-bone-50"><?php echo esc_html( $pdu_a[1] ); ?></span>
								<span class="meta mt-1 block"><?php echo esc_html( $pdu_a[2] ); ?></span>
							</span>
						</a>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<?php // ================= COMIC PANELS ================= ?>
	<section id="comics" class="section border-t border-ink-400 bg-ink-800/50" aria-labelledby="pdu-media-comics">
		<div class="container">
			<?php
			pdu_section_heading(
				array(
					'eyebrow'  => __( 'Read', 'plague-dr-universe' ),
					'title'    => __( 'Comic Illustration', 'plague-dr-universe' ),
					'lede'     => __( 'Sequence boards, inked panels and layout studies from inside the books.', 'plague-dr-universe' ),
					'cta_url'  => home_url( '/chapters/' ),
					'cta_text' => __( 'Read the chapters', 'plague-dr-universe' ),
					'id'       => 'pdu-media-comics',
				)
			);
			?>

			<a class="tile block aspect-[16/9]"
				href="<?php echo esc_url( pdu_img( 'storyboard-grid-full.jpg' ) ); ?>"
				data-pdu-lightbox
				data-full="<?php echo esc_url( pdu_img( 'storyboard-grid-full.jpg' ) ); ?>"
				data-caption="<?php esc_attr_e( 'Full sequence board — Chapter Two', 'plague-dr-universe' ); ?>">
				<img src="<?php echo esc_url( pdu_img( 'storyboard-contact-sheet.jpg' ) ); ?>"
						alt="<?php esc_attr_e( 'Full sixteen-panel storyboard sequence for Chapter Two showing rainy night-time city scenes', 'plague-dr-universe' ); ?>"
						loading="lazy" decoding="async" width="1024" height="576">
				<span class="tile-cap block">
					<span class="block font-display text-lg uppercase text-bone-50">
						<?php esc_html_e( 'Full sequence board — Chapter Two', 'plague-dr-universe' ); ?>
					</span>
					<span class="meta mt-1 block"><?php esc_html_e( 'Select to view at full resolution', 'plague-dr-universe' ); ?></span>
				</span>
			</a>
		</div>
	</section>

	<?php
	while ( have_posts() ) :
		the_post();
		if ( trim( get_the_content() ) ) :
			?>
			<section class="section-tight border-t border-ink-400">
				<div class="container">
					<div class="mx-auto max-w-3xl prose-pdu"><?php the_content(); ?></div>
				</div>
			</section>
			<?php
		endif;
	endwhile;
	?>
</div>

<?php
get_footer();
