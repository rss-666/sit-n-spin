<?php
/**
 * Template Name: Contact / Community
 * Template Post Type: page
 *
 * Contact form, social links and newsletter signup for release drops.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();

$pdu_email    = get_theme_mod( 'pdu_email', 'contact@theplaguedr.com' );
$pdu_press    = get_theme_mod( 'pdu_press', 'press@theplaguedr.com' );
$pdu_location = get_theme_mod( 'pdu_location', __( 'Seattle, Washington', 'plague-dr-universe' ) );
?>

<div class="<?php echo esc_attr( pdu_content_offset_class() ); ?>">

	<?php
	get_template_part(
		'template-parts/components/page-header',
		null,
		array(
			'title' => __( 'Contact &amp; Community', 'plague-dr-universe' ),
			'lede'  => __( 'Commissions, licensing, press, or just to say the Chapter Three waterfront sequence got you. Everything here reaches the studio directly.', 'plague-dr-universe' ),
			'image' => has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'pdu-hero' ) : pdu_img( 'space-needle-rain.jpg' ),
		)
	);
	?>

	<section class="section" aria-labelledby="pdu-contact-form-title">
		<div class="container">
			<div class="grid gap-12 lg:grid-cols-12 lg:gap-16">

				<?php // ---------- Form ---------- ?>
				<div class="lg:col-span-7">
					<?php pdu_form_notice( 'sent' ); ?>

					<h2 id="pdu-contact-form-title" class="text-display-md">
						<?php esc_html_e( 'Send a Message', 'plague-dr-universe' ); ?>
					</h2>
					<p class="lede mt-4">
						<?php esc_html_e( 'Replies usually land within two business days. Include as much detail as you can — especially for commissions and licensing.', 'plague-dr-universe' ); ?>
					</p>

					<form class="mt-9 space-y-6"
							action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
							method="post">
						<input type="hidden" name="action" value="pdu_contact">
						<?php wp_nonce_field( 'pdu_contact', 'pdu_contact_nonce' ); ?>

						<div class="grid gap-6 sm:grid-cols-2">
							<p class="m-0">
								<label for="pdu-name" class="mb-2 block font-display text-xs uppercase tracking-brand text-bone-300">
									<?php esc_html_e( 'Your name', 'plague-dr-universe' ); ?>
									<span class="text-blood-400" aria-hidden="true">*</span>
								</label>
								<input type="text" id="pdu-name" name="pdu_name" required autocomplete="name">
							</p>

							<p class="m-0">
								<label for="pdu-email" class="mb-2 block font-display text-xs uppercase tracking-brand text-bone-300">
									<?php esc_html_e( 'Email address', 'plague-dr-universe' ); ?>
									<span class="text-blood-400" aria-hidden="true">*</span>
								</label>
								<input type="email" id="pdu-email" name="pdu_email" required autocomplete="email">
							</p>
						</div>

						<p class="m-0">
							<label for="pdu-subject" class="mb-2 block font-display text-xs uppercase tracking-brand text-bone-300">
								<?php esc_html_e( 'What is this about?', 'plague-dr-universe' ); ?>
							</label>
							<select id="pdu-subject" name="pdu_subject">
								<option value="General enquiry"><?php esc_html_e( 'General enquiry', 'plague-dr-universe' ); ?></option>
								<option value="Commission"><?php esc_html_e( 'Commission an original piece', 'plague-dr-universe' ); ?></option>
								<option value="Licensing"><?php esc_html_e( 'Licensing / sync rights', 'plague-dr-universe' ); ?></option>
								<option value="Press"><?php esc_html_e( 'Press &amp; interviews', 'plague-dr-universe' ); ?></option>
								<option value="Order support"><?php esc_html_e( 'Order or shipping support', 'plague-dr-universe' ); ?></option>
								<option value="Collaboration"><?php esc_html_e( 'Collaboration', 'plague-dr-universe' ); ?></option>
							</select>
						</p>

						<p class="m-0">
							<label for="pdu-message" class="mb-2 block font-display text-xs uppercase tracking-brand text-bone-300">
								<?php esc_html_e( 'Message', 'plague-dr-universe' ); ?>
								<span class="text-blood-400" aria-hidden="true">*</span>
							</label>
							<textarea id="pdu-message" name="pdu_message" required></textarea>
						</p>

						<?php // Honeypot. ?>
						<p class="hidden" aria-hidden="true">
							<label for="pdu-hp-contact"><?php esc_html_e( 'Leave this field empty', 'plague-dr-universe' ); ?></label>
							<input type="text" id="pdu-hp-contact" name="pdu_hp" tabindex="-1" autocomplete="off">
						</p>

						<p class="m-0 text-xs leading-relaxed text-bone-400">
							<?php
							printf(
								/* translators: %s: privacy policy link. */
								esc_html__( 'We use your message only to answer you. See the %s for details.', 'plague-dr-universe' ),
								'<a class="text-amber-300 underline" href="' . esc_url( home_url( '/privacy-policy/' ) ) . '">' . esc_html__( 'Privacy Policy', 'plague-dr-universe' ) . '</a>'
							);
							?>
						</p>

						<button type="submit" class="btn btn-primary">
							<?php pdu_the_icon( 'mail', 16 ); ?>
							<?php esc_html_e( 'Send message', 'plague-dr-universe' ); ?>
						</button>
					</form>
				</div>

				<?php // ---------- Sidebar ---------- ?>
				<aside class="space-y-6 lg:col-span-5">

					<?php // Direct contact. ?>
					<div class="border border-ink-400 bg-ink-800 p-6 md:p-8">
						<h2 class="text-xl"><?php esc_html_e( 'Direct Lines', 'plague-dr-universe' ); ?></h2>
						<ul class="mt-5 list-none space-y-4 p-0">
							<li class="flex gap-3">
								<span class="mt-0.5 shrink-0 text-amber-400"><?php pdu_the_icon( 'mail', 18 ); ?></span>
								<span>
									<span class="meta block"><?php esc_html_e( 'General', 'plague-dr-universe' ); ?></span>
									<a class="text-bone-100 no-underline hover:text-amber-300" href="mailto:<?php echo esc_attr( $pdu_email ); ?>">
										<?php echo esc_html( $pdu_email ); ?>
									</a>
								</span>
							</li>
							<li class="flex gap-3">
								<span class="mt-0.5 shrink-0 text-amber-400"><?php pdu_the_icon( 'shield', 18 ); ?></span>
								<span>
									<span class="meta block"><?php esc_html_e( 'Press &amp; licensing', 'plague-dr-universe' ); ?></span>
									<a class="text-bone-100 no-underline hover:text-amber-300" href="mailto:<?php echo esc_attr( $pdu_press ); ?>">
										<?php echo esc_html( $pdu_press ); ?>
									</a>
								</span>
							</li>
							<li class="flex gap-3">
								<span class="mt-0.5 shrink-0 text-amber-400"><?php pdu_the_icon( 'pin', 18 ); ?></span>
								<span>
									<span class="meta block"><?php esc_html_e( 'Studio', 'plague-dr-universe' ); ?></span>
									<span class="text-bone-100"><?php echo esc_html( $pdu_location ); ?></span>
								</span>
							</li>
							<li class="flex gap-3">
								<span class="mt-0.5 shrink-0 text-amber-400"><?php pdu_the_icon( 'clock', 18 ); ?></span>
								<span>
									<span class="meta block"><?php esc_html_e( 'Response time', 'plague-dr-universe' ); ?></span>
									<span class="text-bone-100"><?php esc_html_e( 'Within 2 business days', 'plague-dr-universe' ); ?></span>
								</span>
							</li>
						</ul>
					</div>

					<?php // Newsletter. ?>
					<div class="relative overflow-hidden border border-ink-400 bg-ink-800 p-6 md:p-8">
						<img src="<?php echo esc_url( pdu_img( 'rain-street-noir.jpg' ) ); ?>" alt=""
								class="absolute inset-0 h-full w-full object-cover opacity-15"
								loading="lazy" decoding="async" width="1024" height="1024">
						<div class="relative">
							<p class="eyebrow"><?php esc_html_e( 'The Dispatch', 'plague-dr-universe' ); ?></p>
							<h2 class="text-xl"><?php esc_html_e( 'Release drops, first', 'plague-dr-universe' ); ?></h2>
							<p class="mt-3 text-sm leading-relaxed text-bone-300">
								<?php esc_html_e( 'New chapters, unreleased tracks, print runs and early access to limited merch. Sent only when there is something worth sending.', 'plague-dr-universe' ); ?>
							</p>
							<div class="mt-6">
								<?php pdu_form_notice( 'subscribed' ); ?>
								<?php pdu_newsletter_form( 'block' ); ?>
							</div>
						</div>
					</div>

					<?php // Social. ?>
					<div class="border border-ink-400 bg-ink-800 p-6 md:p-8">
						<h2 class="text-xl"><?php esc_html_e( 'Find the Universe', 'plague-dr-universe' ); ?></h2>
						<p class="mt-3 text-sm leading-relaxed text-bone-300">
							<?php esc_html_e( 'Process shots, work in progress and the occasional argument about panel gutters.', 'plague-dr-universe' ); ?>
						</p>
						<div class="mt-5">
							<?php pdu_social_links(); ?>
						</div>
						<p class="meta mt-5">
							<?php esc_html_e( 'Add your social URLs in Customizer → Plague Dr Universe → Social Links.', 'plague-dr-universe' ); ?>
						</p>
					</div>

					<?php // FAQ. ?>
					<div class="border border-ink-400 bg-ink-800 p-6 md:p-8">
						<h2 class="text-xl"><?php esc_html_e( 'Quick Answers', 'plague-dr-universe' ); ?></h2>
						<div class="mt-4 space-y-2">
							<?php
							$pdu_faqs = array(
								array(
									__( 'Do you take commissions?', 'plague-dr-universe' ),
									__( 'Yes, in limited batches. Send a brief with the size, medium and deadline you have in mind and we will tell you honestly whether it fits the queue.', 'plague-dr-universe' ),
								),
								array(
									__( 'Can I use your music in my video?', 'plague-dr-universe' ),
									__( 'Buying a track is a listening licence, not a sync licence. Email the press and licensing address with details of the project — we are independent and generally reasonable.', 'plague-dr-universe' ),
								),
								array(
									__( 'Where is my order?', 'plague-dr-universe' ),
									__( 'Physical orders dispatch in 1–3 business days with tracking. Digital orders arrive instantly. If something has gone quiet, send the order number.', 'plague-dr-universe' ),
								),
								array(
									__( 'Can I post fan art?', 'plague-dr-universe' ),
									__( 'Please do. Credit The Plague Dr Universe, do not present it as official, and keep it non-commercial. We repost the good ones.', 'plague-dr-universe' ),
								),
							);

							foreach ( $pdu_faqs as $pdu_faq ) :
								?>
								<details class="group border border-ink-500 bg-ink-900/60">
									<summary class="cursor-pointer list-none px-4 py-3 font-display text-sm uppercase tracking-wide text-bone-100 transition-colors hover:text-amber-300">
										<span class="flex items-center justify-between gap-3">
											<?php echo esc_html( $pdu_faq[0] ); ?>
											<span class="shrink-0 text-blood-400 transition-transform group-open:rotate-45" aria-hidden="true">+</span>
										</span>
									</summary>
									<p class="border-t border-ink-500 px-4 py-3 text-sm leading-relaxed text-bone-300">
										<?php echo esc_html( $pdu_faq[1] ); ?>
									</p>
								</details>
							<?php endforeach; ?>
						</div>
					</div>
				</aside>
			</div>

			<?php
			while ( have_posts() ) :
				the_post();
				if ( trim( get_the_content() ) ) :
					?>
					<div class="mx-auto mt-16 max-w-3xl prose-pdu border-t border-ink-400 pt-12">
						<?php the_content(); ?>
					</div>
					<?php
				endif;
			endwhile;
			?>
		</div>
	</section>
</div>

<?php
get_footer();
