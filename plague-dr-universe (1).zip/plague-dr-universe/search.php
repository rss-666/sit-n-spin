<?php
/**
 * Search results.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="<?php echo esc_attr( pdu_content_offset_class() ); ?>">
	<?php
	get_template_part(
		'template-parts/components/page-header',
		null,
		array(
			/* translators: %s: search query. */
			'title' => sprintf( __( 'Search: %s', 'plague-dr-universe' ), esc_html( get_search_query() ) ),
			'lede'  => sprintf(
				/* translators: %d: number of results. */
				_n( '%d result found across chapters, tracks, artwork and the store.', '%d results found across chapters, tracks, artwork and the store.', (int) $GLOBALS['wp_query']->found_posts, 'plague-dr-universe' ),
				(int) $GLOBALS['wp_query']->found_posts
			),
		)
	);
	?>

	<div class="container section-tight">
		<?php if ( have_posts() ) : ?>
			<div class="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content/card', get_post_type() );
				endwhile;
				?>
			</div>

			<?php pdu_pagination(); ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content/none' ); ?>
		<?php endif; ?>
	</div>
</div>

<?php
get_footer();
