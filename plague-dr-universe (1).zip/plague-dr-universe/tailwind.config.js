/**
 * Tailwind configuration — The Plague Dr Universe
 *
 * Design language: dark, gritty, cinematic. Charred blacks, blood red and
 * muted amber accents, bone-white type. Contrast ratios in the palette below
 * are chosen so body text and accents clear WCAG 2.1 AA on the dark surfaces.
 *
 * @package PlagueDrUniverse
 */

/** @type {import('tailwindcss').Config} */
module.exports = {
	content: [
		'./**/*.php',
		'./assets/js/**/*.js',
		'./patterns/**/*.php',
		'!./node_modules/**',
		'!./vendor/**',
	],
	darkMode: 'class',
	theme: {
		container: {
			center: true,
			padding: { DEFAULT: '1.25rem', lg: '2rem' },
			screens: { '2xl': '1320px' },
		},
		extend: {
			colors: {
				// Surfaces — charred blacks through to smoke.
				ink: {
					900: '#050507',
					800: '#0a0a0e',
					700: '#101015',
					600: '#16161d',
					500: '#1e1e27',
					400: '#282833',
					300: '#343442',
				},
				// Blood red — primary accent.
				blood: {
					700: '#6d0a12',
					600: '#8f0f1a',
					500: '#b3121b',
					400: '#d32232',
					300: '#e84453',
				},
				// Muted amber — secondary accent / lamplight.
				amber: {
					600: '#a9761b',
					500: '#c8912a',
					400: '#e0a93a',
					300: '#efc169',
				},
				// Emergency blue — pulled from the source photography.
				siren: {
					600: '#1150a8',
					500: '#1f6fd0',
					400: '#3f92ea',
				},
				bone: {
					50: '#faf8f4',
					100: '#f1ede4',
					200: '#ddd7cb',
					300: '#bab3a6',
					400: '#8d877c',
				},
			},
			fontFamily: {
				display: ['Oswald', 'Bebas Neue', 'Impact', 'Haettenschweiler', 'sans-serif'],
				body: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
				mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
			},
			fontSize: {
				'display-xl': ['clamp(2.75rem, 8vw, 6.5rem)', { lineHeight: '0.92', letterSpacing: '0.01em' }],
				'display-lg': ['clamp(2.25rem, 5.5vw, 4.25rem)', { lineHeight: '0.95', letterSpacing: '0.01em' }],
				'display-md': ['clamp(1.75rem, 3.5vw, 2.75rem)', { lineHeight: '1.05' }],
			},
			letterSpacing: { brand: '0.22em', wider2: '0.32em' },
			opacity: { 2: '.02', 3: '.03', 15: '.15', 92: '.92', 97: '.97', 98: '.98' },
			boxShadow: {
				'glow-blood': '0 0 0 1px rgba(179,18,27,.45), 0 18px 50px -12px rgba(179,18,27,.55)',
				'glow-amber': '0 0 0 1px rgba(200,145,42,.4), 0 18px 50px -12px rgba(200,145,42,.45)',
				plate: '0 24px 70px -24px rgba(0,0,0,.9)',
			},
			backgroundImage: {
				'grain': "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='3'/%3E%3C/filter%3E%3Crect width='160' height='160' filter='url(%23n)' opacity='.32'/%3E%3C/svg%3E\")",
				'fog-top': 'linear-gradient(180deg, rgba(5,5,7,.94) 0%, rgba(5,5,7,.55) 45%, rgba(5,5,7,0) 100%)',
				'fog-bottom': 'linear-gradient(0deg, #050507 4%, rgba(5,5,7,.82) 38%, rgba(5,5,7,0) 100%)',
			},
			keyframes: {
				'siren-pulse': {
					'0%,100%': { opacity: '.20' },
					'50%': { opacity: '.55' },
				},
				'rise': {
					from: { opacity: '0', transform: 'translateY(18px)' },
					to: { opacity: '1', transform: 'none' },
				},
				'eq-bar': {
					'0%,100%': { transform: 'scaleY(.28)' },
					'50%': { transform: 'scaleY(1)' },
				},
			},
			animation: {
				'siren-pulse': 'siren-pulse 5s ease-in-out infinite',
				'rise': 'rise .7s cubic-bezier(.2,.7,.3,1) both',
				'eq-bar': 'eq-bar 1.1s ease-in-out infinite',
			},
			typography: null,
		},
	},
	corePlugins: { preflight: true },
	plugins: [],
};
