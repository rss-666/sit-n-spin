<?php
/**
 * The Plague Dr Universe — theme bootstrap.
 *
 * Loads theme setup, asset pipeline, template helpers, custom post types,
 * WooCommerce integration, SEO/schema output and accessibility utilities.
 *
 * @package PlagueDrUniverse
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Theme version. Falls back to filemtime in dev so caches bust automatically.
 */
if ( ! defined( 'PDU_VERSION' ) ) {
	define( 'PDU_VERSION', '1.0.0' );
}
define( 'PDU_DIR', trailingslashit( get_template_directory() ) );
define( 'PDU_URI', trailingslashit( get_template_directory_uri() ) );

/**
 * Cache-busting version string based on file modification time.
 *
 * @param string $relative_path Path relative to the theme root.
 * @return string Version string.
 */
function pdu_asset_version( $relative_path ) {
	$file = PDU_DIR . ltrim( $relative_path, '/' );
	if ( file_exists( $file ) ) {
		return PDU_VERSION . '.' . filemtime( $file );
	}
	return PDU_VERSION;
}

/* -------------------------------------------------------------------------
 * 1. Theme setup
 * ---------------------------------------------------------------------- */

/**
 * Register theme supports, menus and image sizes.
 *
 * @return void
 */
function pdu_theme_setup() {
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/editor.css' );

	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);

	add_theme_support(
		'custom-logo',
		array(
			'height'               => 96,
			'width'                => 320,
			'flex-height'          => true,
			'flex-width'           => true,
			'unlink-homepage-logo' => true,
		)
	);

	add_theme_support( 'post-formats', array( 'gallery', 'image', 'video', 'audio', 'quote' ) );

	// Locked-down dark editor palette mirroring tailwind.config.js.
	add_theme_support(
		'editor-color-palette',
		array(
			array(
				'name'  => __( 'Void Black', 'plague-dr-universe' ),
				'slug'  => 'void-black',
				'color' => '#050507',
			),
			array(
				'name'  => __( 'Charred Coal', 'plague-dr-universe' ),
				'slug'  => 'charred-coal',
				'color' => '#101015',
			),
			array(
				'name'  => __( 'Ash Grey', 'plague-dr-universe' ),
				'slug'  => 'ash-grey',
				'color' => '#282833',
			),
			array(
				'name'  => __( 'Blood Red', 'plague-dr-universe' ),
				'slug'  => 'blood-red',
				'color' => '#b3121b',
			),
			array(
				'name'  => __( 'Muted Amber', 'plague-dr-universe' ),
				'slug'  => 'muted-amber',
				'color' => '#c8912a',
			),
			array(
				'name'  => __( 'Siren Blue', 'plague-dr-universe' ),
				'slug'  => 'siren-blue',
				'color' => '#1f6fd0',
			),
			array(
				'name'  => __( 'Bone White', 'plague-dr-universe' ),
				'slug'  => 'bone-white',
				'color' => '#f1ede4',
			),
		)
	);
	add_theme_support( 'disable-custom-colors' );
	add_theme_support( 'editor-font-sizes', array(
		array(
			'name' => __( 'Small', 'plague-dr-universe' ),
			'slug' => 'small',
			'size' => 14,
		),
		array(
			'name' => __( 'Normal', 'plague-dr-universe' ),
			'slug' => 'normal',
			'size' => 17,
		),
		array(
			'name' => __( 'Large', 'plague-dr-universe' ),
			'slug' => 'large',
			'size' => 24,
		),
		array(
			'name' => __( 'Display', 'plague-dr-universe' ),
			'slug' => 'display',
			'size' => 48,
		),
	) );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'plague-dr-universe' ),
			'footer'  => __( 'Footer Menu', 'plague-dr-universe' ),
			'legal'   => __( 'Legal Menu', 'plague-dr-universe' ),
			'social'  => __( 'Social Links Menu', 'plague-dr-universe' ),
		)
	);

	// Purpose-built crops so the browser never downloads more than it paints.
	add_image_size( 'pdu-hero', 1920, 1080, true );
	add_image_size( 'pdu-card', 800, 600, true );
	add_image_size( 'pdu-tile', 900, 900, true );
	add_image_size( 'pdu-panel', 1200, 1600, true );
	add_image_size( 'pdu-wide', 1600, 700, true );

	// Content width for embeds.
	if ( ! isset( $GLOBALS['content_width'] ) ) {
		$GLOBALS['content_width'] = 1320;
	}
}
add_action( 'after_setup_theme', 'pdu_theme_setup' );

/**
 * Load translations on `init`.
 *
 * WordPress 6.7+ warns when a textdomain is loaded before `init`, so this is
 * deliberately kept out of `after_setup_theme`.
 *
 * @return void
 */
function pdu_load_textdomain() {
	load_theme_textdomain( 'plague-dr-universe', PDU_DIR . 'languages' );
}
add_action( 'init', 'pdu_load_textdomain' );

/**
 * Human-readable labels for the custom image sizes in the media UI.
 *
 * @param array $sizes Existing sizes.
 * @return array
 */
function pdu_custom_image_size_names( $sizes ) {
	return array_merge(
		$sizes,
		array(
			'pdu-card'  => __( 'PDU Card (800×600)', 'plague-dr-universe' ),
			'pdu-tile'  => __( 'PDU Tile (900×900)', 'plague-dr-universe' ),
			'pdu-panel' => __( 'PDU Panel (1200×1600)', 'plague-dr-universe' ),
			'pdu-wide'  => __( 'PDU Wide (1600×700)', 'plague-dr-universe' ),
		)
	);
}
add_filter( 'image_size_names_choose', 'pdu_custom_image_size_names' );

/* -------------------------------------------------------------------------
 * 2. Assets
 * ---------------------------------------------------------------------- */

/**
 * Enqueue front-end styles and scripts.
 *
 * Strategy: one compiled + purged CSS file, one deferred JS file, self-hosted
 * fonts preloaded. No jQuery dependency on the front end.
 *
 * @return void
 */
function pdu_enqueue_assets() {
	// Compiled Tailwind build. style.css remains the theme header only.
	wp_enqueue_style(
		'pdu-main',
		PDU_URI . 'assets/css/main.css',
		array(),
		pdu_asset_version( 'assets/css/main.css' )
	);

	// Keep the WP-required style.css in the dependency chain for child themes.
	wp_style_add_data( 'pdu-main', 'path', PDU_DIR . 'assets/css/main.css' );

	wp_enqueue_script(
		'pdu-main',
		PDU_URI . 'assets/js/main.js',
		array(),
		pdu_asset_version( 'assets/js/main.js' ),
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);

	wp_localize_script(
		'pdu-main',
		'pduData',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'pdu_nonce' ),
			'i18n'    => array(
				'play'      => __( 'Play', 'plague-dr-universe' ),
				'pause'     => __( 'Pause', 'plague-dr-universe' ),
				'menuOpen'  => __( 'Open menu', 'plague-dr-universe' ),
				'menuClose' => __( 'Close menu', 'plague-dr-universe' ),
			),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Dequeue Gutenberg front-end bloat when the page has no blocks that need it.
	if ( ! is_singular() || ! has_blocks() ) {
		wp_dequeue_style( 'wp-block-library-theme' );
	}
}
add_action( 'wp_enqueue_scripts', 'pdu_enqueue_assets' );

/**
 * Preload critical self-hosted fonts and add resource hints.
 *
 * @return void
 */
function pdu_preload_fonts() {
	$fonts = array( 'oswald-latin-700-normal.woff2', 'inter-latin-400-normal.woff2' );
	foreach ( $fonts as $font ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( PDU_URI . 'assets/fonts/' . $font )
		);
	}
}
add_action( 'wp_head', 'pdu_preload_fonts', 1 );

/**
 * Editor styles inside the block editor.
 *
 * @return void
 */
function pdu_editor_assets() {
	wp_enqueue_style(
		'pdu-editor',
		PDU_URI . 'assets/css/editor.css',
		array(),
		pdu_asset_version( 'assets/css/editor.css' )
	);
}
add_action( 'enqueue_block_editor_assets', 'pdu_editor_assets' );

/* -------------------------------------------------------------------------
 * 3. Performance & cleanup
 * ---------------------------------------------------------------------- */

/**
 * Trim head bloat that leaks version info or adds needless requests.
 *
 * @return void
 */
function pdu_clean_head() {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
	remove_action( 'template_redirect', 'rest_output_link_header', 11 );
}
add_action( 'init', 'pdu_clean_head' );

/**
 * Remove the emoji DNS prefetch hint.
 *
 * @param array  $urls          Resource URLs.
 * @param string $relation_type Relation type.
 * @return array
 */
function pdu_remove_emoji_prefetch( $urls, $relation_type ) {
	if ( 'dns-prefetch' === $relation_type ) {
		$urls = array_filter(
			$urls,
			static function ( $url ) {
				return false === strpos( (string) $url, 's.w.org' );
			}
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'pdu_remove_emoji_prefetch', 10, 2 );

/**
 * Lazy-load and async-decode images that WordPress hasn't already handled,
 * and make the first hero image eager so LCP is not delayed.
 *
 * @param string $content Post content.
 * @return string
 */
function pdu_image_loading_attrs( $content ) {
	if ( is_admin() || empty( $content ) ) {
		return $content;
	}
	if ( false === strpos( $content, '<img' ) ) {
		return $content;
	}
	$content = preg_replace( '/<img((?![^>]*\bdecoding=)[^>]*)>/i', '<img$1 decoding="async">', $content );
	return $content;
}
add_filter( 'the_content', 'pdu_image_loading_attrs', 20 );

/**
 * Default responsive `sizes` so browsers pick sane candidates.
 *
 * @param string $sizes Sizes attribute.
 * @return string
 */
function pdu_default_image_sizes_attr( $sizes ) {
	return '(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw';
}
add_filter( 'wp_calculate_image_sizes', 'pdu_default_image_sizes_attr', 10, 1 );

/**
 * Disable the oEmbed discovery + wp-embed script (rarely needed, costs bytes).
 *
 * @return void
 */
function pdu_disable_embeds() {
	if ( ! is_admin() ) {
		wp_deregister_script( 'wp-embed' );
	}
}
add_action( 'wp_footer', 'pdu_disable_embeds' );

/**
 * Give oEmbed iframes lazy loading and a title for a11y.
 *
 * @param string $html The embed markup.
 * @return string
 */
function pdu_lazy_oembed( $html ) {
	if ( false === strpos( $html, 'loading=' ) ) {
		$html = str_replace( '<iframe ', '<iframe loading="lazy" ', $html );
	}
	return $html;
}
add_filter( 'embed_oembed_html', 'pdu_lazy_oembed' );
add_filter( 'video_embed_html', 'pdu_lazy_oembed' );

/* -------------------------------------------------------------------------
 * 4. Widgets
 * ---------------------------------------------------------------------- */

/**
 * Register footer and sidebar widget areas.
 *
 * @return void
 */
function pdu_widgets_init() {
	$common = array(
		'before_widget' => '<section id="%1$s" class="widget %2$s mb-10">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="footer-heading">',
		'after_title'   => '</h2>',
	);

	register_sidebar(
		array_merge(
			$common,
			array(
				'name'        => __( 'Primary Sidebar', 'plague-dr-universe' ),
				'id'          => 'sidebar-1',
				'description' => __( 'Appears on the blog and archive pages.', 'plague-dr-universe' ),
			)
		)
	);

	for ( $i = 1; $i <= 3; $i++ ) {
		register_sidebar(
			array_merge(
				$common,
				array(
					/* translators: %d: footer column number. */
					'name'        => sprintf( __( 'Footer Column %d', 'plague-dr-universe' ), $i ),
					'id'          => 'footer-' . $i,
					'description' => __( 'Footer widget column.', 'plague-dr-universe' ),
				)
			)
		);
	}
}
add_action( 'widgets_init', 'pdu_widgets_init' );

/* -------------------------------------------------------------------------
 * 5. Modular includes
 * ---------------------------------------------------------------------- */

require_once PDU_DIR . 'inc/template-tags.php';
require_once PDU_DIR . 'inc/template-functions.php';
require_once PDU_DIR . 'inc/post-types.php';
require_once PDU_DIR . 'inc/enquiries.php';
require_once PDU_DIR . 'inc/customizer.php';
require_once PDU_DIR . 'inc/seo-schema.php';
require_once PDU_DIR . 'inc/nav-walker.php';
require_once PDU_DIR . 'inc/blocks.php';
require_once PDU_DIR . 'inc/demo-content.php';

if ( class_exists( 'WooCommerce' ) ) {
	require_once PDU_DIR . 'inc/woocommerce.php';
}
