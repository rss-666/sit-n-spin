<?php
/**
 * Site footer.
 *
 * Closes the main landmark, then renders the newsletter call-out, the four
 * footer columns, social row, legal menu and the back-to-top control.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;
?>
	</main><!-- #main-content -->

	<?php
	// Hide the newsletter block on the contact page and inside the checkout flow.
	$pdu_hide_newsletter = is_page_template( 'page-templates/template-contact.php' );
	if ( ! $pdu_hide_newsletter && function_exists( 'is_cart' ) ) {
		$pdu_hide_newsletter = is_cart() || is_checkout() || is_account_page();
	}
	?>
	<?php if ( ! $pdu_hide_newsletter ) : ?>
		<?php // ---------- Newsletter call-out ---------- ?>
		<section class="relative overflow-hidden border-y border-ink-400 bg-ink-800"
				aria-labelledby="pdu-newsletter-heading">
			<img src="<?php echo esc_url( pdu_img( 'rain-street-noir.jpg' ) ); ?>"
					alt=""
					class="absolute inset-0 h-full w-full object-cover opacity-20"
					loading="lazy"
					decoding="async"
					width="1024" height="1024">
			<div class="absolute inset-0 bg-gradient-to-r from-ink-900 via-ink-900/85 to-ink-900/40"></div>

			<div class="container relative py-16 md:py-20">
				<div class="grid gap-10 lg:grid-cols-2 lg:items-center">
					<div>
						<p class="eyebrow"><?php esc_html_e( 'The Dispatch', 'plague-dr-universe' ); ?></p>
						<h2 id="pdu-newsletter-heading" class="text-display-md">
							<?php esc_html_e( 'Get the drops before the crows do', 'plague-dr-universe' ); ?>
						</h2>
						<p class="lede mt-4">
							<?php esc_html_e( 'New chapters, unreleased tracks, print runs and early access to limited merch — sent when there is something worth sending. Nothing else.', 'plague-dr-universe' ); ?>
						</p>
					</div>

					<div class="border border-ink-300 bg-ink-900/85 p-6 backdrop-blur-sm md:p-8">
						<?php pdu_newsletter_form( 'block' ); ?>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<footer id="colophon" class="site-footer bg-ink-900" role="contentinfo">

		<?php // ---------- Marquee ---------- ?>
		<div class="marquee" aria-hidden="true">
			<?php for ( $pdu_m = 0; $pdu_m < 2; $pdu_m++ ) : ?>
				<div class="marquee-track">
					<?php
					$pdu_words = array(
						__( 'Graphic Novels', 'plague-dr-universe' ),
						__( 'Original Artwork', 'plague-dr-universe' ),
						__( 'Metal &amp; Ambient Soundtracks', 'plague-dr-universe' ),
						__( 'Video Releases', 'plague-dr-universe' ),
						__( 'Limited Prints', 'plague-dr-universe' ),
						__( 'Apparel', 'plague-dr-universe' ),
					);
					foreach ( $pdu_words as $pdu_word ) {
						echo '<span>' . esc_html( $pdu_word ) . '</span><span class="text-blood-500">&#10022;</span>';
					}
					?>
				</div>
			<?php endfor; ?>
		</div>

		<div class="container py-16 md:py-20">
			<div class="grid gap-12 md:grid-cols-2 lg:grid-cols-12">

				<?php // ---------- Brand column ---------- ?>
				<div class="lg:col-span-4">
					<a class="brand-mark inline-flex items-center gap-2.5" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
						<span class="text-blood-500" aria-hidden="true"><?php pdu_the_icon( 'skull', 32 ); ?></span>
						<span class="text-xl"><?php bloginfo( 'name' ); ?></span>
					</a>

					<p class="mt-5 max-w-sm text-sm leading-relaxed text-bone-300">
						<?php
						$pdu_desc = get_bloginfo( 'description' );
						echo esc_html(
							$pdu_desc
								? $pdu_desc
								: __( 'An independent multimedia universe of ink, noise and rain — graphic novels, original artwork, and heavy soundtracks out of the Pacific Northwest.', 'plague-dr-universe' )
						);
						?>
					</p>

					<div class="mt-7">
						<?php pdu_social_links(); ?>
					</div>

					<p class="meta mt-7 flex items-center gap-2">
						<?php pdu_the_icon( 'pin', 14 ); ?>
						<?php echo esc_html( get_theme_mod( 'pdu_location', __( 'Seattle, Washington', 'plague-dr-universe' ) ) ); ?>
					</p>
				</div>

				<?php // ---------- Explore ---------- ?>
				<nav class="lg:col-span-2" aria-labelledby="pdu-foot-explore">
					<h2 id="pdu-foot-explore" class="footer-heading"><?php esc_html_e( 'Explore', 'plague-dr-universe' ); ?></h2>
					<?php
					if ( has_nav_menu( 'footer' ) ) {
						wp_nav_menu(
							array(
								'theme_location' => 'footer',
								'container'      => false,
								'menu_class'     => 'footer-list list-none m-0 p-0',
								'depth'          => 1,
							)
						);
					} else {
						$pdu_explore = array(
							home_url( '/the-universe/' ) => __( 'The Universe', 'plague-dr-universe' ),
							home_url( '/chapters/' )     => __( 'Graphic Novel', 'plague-dr-universe' ),
							home_url( '/artwork/' )      => __( 'Artwork', 'plague-dr-universe' ),
							home_url( '/soundtracks/' )  => __( 'Soundtracks', 'plague-dr-universe' ),
							home_url( '/videos/' )       => __( 'Videos', 'plague-dr-universe' ),
						);
						echo '<ul class="footer-list list-none m-0 p-0">';
						foreach ( $pdu_explore as $pdu_url => $pdu_label ) {
							printf( '<li><a href="%s">%s</a></li>', esc_url( $pdu_url ), esc_html( $pdu_label ) );
						}
						echo '</ul>';
					}
					?>
				</nav>

				<?php // ---------- Store ---------- ?>
				<nav class="lg:col-span-2" aria-labelledby="pdu-foot-store">
					<h2 id="pdu-foot-store" class="footer-heading"><?php esc_html_e( 'Store', 'plague-dr-universe' ); ?></h2>
					<ul class="footer-list list-none m-0 p-0">
						<li><a href="<?php echo esc_url( pdu_shop_url() ); ?>"><?php esc_html_e( 'All Products', 'plague-dr-universe' ); ?></a></li>
						<li><a href="<?php echo esc_url( pdu_shop_url( 'graphic-novels' ) ); ?>"><?php esc_html_e( 'Graphic Novels', 'plague-dr-universe' ); ?></a></li>
						<li><a href="<?php echo esc_url( pdu_shop_url( 'original-artwork' ) ); ?>"><?php esc_html_e( 'Original Artwork', 'plague-dr-universe' ); ?></a></li>
						<li><a href="<?php echo esc_url( pdu_shop_url( 'music-albums' ) ); ?>"><?php esc_html_e( 'Music &amp; Albums', 'plague-dr-universe' ); ?></a></li>
						<li><a href="<?php echo esc_url( pdu_shop_url( 'apparel-merch' ) ); ?>"><?php esc_html_e( 'Apparel &amp; Merch', 'plague-dr-universe' ); ?></a></li>
						<?php if ( class_exists( 'WooCommerce' ) ) : ?>
							<li><a href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'Cart', 'plague-dr-universe' ); ?></a></li>
							<li><a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"><?php esc_html_e( 'My Account', 'plague-dr-universe' ); ?></a></li>
						<?php endif; ?>
					</ul>
				</nav>

				<?php // ---------- Support / legal ---------- ?>
				<nav class="lg:col-span-2" aria-labelledby="pdu-foot-support">
					<h2 id="pdu-foot-support" class="footer-heading"><?php esc_html_e( 'Support', 'plague-dr-universe' ); ?></h2>
					<?php
					if ( has_nav_menu( 'legal' ) ) {
						wp_nav_menu(
							array(
								'theme_location' => 'legal',
								'container'      => false,
								'menu_class'     => 'footer-list list-none m-0 p-0',
								'depth'          => 1,
							)
						);
					} else {
						$pdu_legal = array(
							home_url( '/contact/' )          => __( 'Contact', 'plague-dr-universe' ),
							home_url( '/shipping-refunds/' ) => __( 'Shipping &amp; Refunds', 'plague-dr-universe' ),
							home_url( '/terms-conditions/' ) => __( 'Terms &amp; Conditions', 'plague-dr-universe' ),
							home_url( '/privacy-policy/' )   => __( 'Privacy Policy', 'plague-dr-universe' ),
						);
						echo '<ul class="footer-list list-none m-0 p-0">';
						foreach ( $pdu_legal as $pdu_url => $pdu_label ) {
							printf( '<li><a href="%s">%s</a></li>', esc_url( $pdu_url ), esc_html( $pdu_label ) );
						}
						echo '</ul>';
					}
					?>
				</nav>

				<?php // ---------- Widgets / contact ---------- ?>
				<div class="lg:col-span-2">
					<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
						<?php dynamic_sidebar( 'footer-1' ); ?>
					<?php else : ?>
						<h2 class="footer-heading"><?php esc_html_e( 'Direct Line', 'plague-dr-universe' ); ?></h2>
						<ul class="footer-list list-none m-0 p-0">
							<li>
								<a href="mailto:<?php echo esc_attr( get_theme_mod( 'pdu_email', 'contact@theplaguedr.com' ) ); ?>">
									<?php echo esc_html( get_theme_mod( 'pdu_email', 'contact@theplaguedr.com' ) ); ?>
								</a>
							</li>
							<li class="pt-2 text-sm text-bone-400">
								<?php esc_html_e( 'Licensing, press and commission enquiries welcome.', 'plague-dr-universe' ); ?>
							</li>
						</ul>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<?php // ---------- Sub-footer ---------- ?>
		<div class="border-t border-ink-400">
			<div class="container flex flex-col items-center justify-between gap-4 py-6 md:flex-row">
				<p class="meta text-center md:text-left">
					&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?>
					<?php bloginfo( 'name' ); ?>.
					<?php esc_html_e( 'All artwork, music and story content is original and protected.', 'plague-dr-universe' ); ?>
				</p>

				<div class="flex items-center gap-5">
					<p class="meta"><?php esc_html_e( 'Built in the rain', 'plague-dr-universe' ); ?></p>
					<button type="button" class="btn btn-ghost btn-sm" data-pdu-top>
						<?php esc_html_e( 'Back to top', 'plague-dr-universe' ); ?>
						<span aria-hidden="true">&uarr;</span>
					</button>
				</div>
			</div>
		</div>
	</footer>
</div><!-- #page -->

<?php wp_footer(); ?>

<?php // Single shared audio element — one decoder for every track row on the page. ?>
<audio id="pdu-audio" preload="none" class="hidden"></audio>
<p class="screen-reader-text" role="status" aria-live="polite" data-pdu-status></p>

</body>
</html>
