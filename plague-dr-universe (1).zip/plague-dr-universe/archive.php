<?php
/**
 * Archive template for categories, tags, taxonomies and custom post types.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();

$pdu_pt   = get_post_type();
$pdu_grid = ( 'pdu_artwork' === $pdu_pt )
	? 'grid gap-4 sm:grid-cols-2 lg:grid-cols-3'
	: 'grid gap-8 sm:grid-cols-2 lg:grid-cols-3';
?>

<div class="<?php echo esc_attr( pdu_content_offset_class() ); ?>">
	<?php get_template_part( 'template-parts/components/page-header' ); ?>

	<div class="container section-tight">
		<?php if ( have_posts() ) : ?>
			<div class="<?php echo esc_attr( $pdu_grid ); ?>">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content/card', get_post_type() );
				endwhile;
				?>
			</div>

			<?php pdu_pagination(); ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content/none' ); ?>
		<?php endif; ?>
	</div>
</div>

<?php
get_footer();
