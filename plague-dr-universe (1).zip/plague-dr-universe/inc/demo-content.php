<?php
/**
 * One-click demo content installer.
 *
 * Creates every page the brief calls for — with the real, fully written copy —
 * plus WooCommerce product categories, sample multimedia entries and the menus.
 * Runs from Appearance → Import Demo Content, and is idempotent.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the admin page.
 *
 * @return void
 */
function pdu_demo_menu() {
	add_theme_page(
		__( 'Import Demo Content', 'plague-dr-universe' ),
		__( 'Import Demo Content', 'plague-dr-universe' ),
		'edit_theme_options',
		'pdu-demo',
		'pdu_demo_page'
	);
}
add_action( 'admin_menu', 'pdu_demo_menu' );

/**
 * Render the importer screen.
 *
 * @return void
 */
function pdu_demo_page() {
	$done = get_option( 'pdu_demo_imported' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'The Plague Dr Universe — Setup', 'plague-dr-universe' ); ?></h1>

		<?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only flag. ?>
		<?php if ( isset( $_GET['imported'] ) ) : ?>
			<div class="notice notice-success is-dismissible">
				<p><?php esc_html_e( 'Demo content installed. Visit the site to see it.', 'plague-dr-universe' ); ?></p>
			</div>
		<?php endif; ?>

		<p style="max-width:60em">
			<?php esc_html_e( 'This creates every page the theme expects — Home, The Universe, Media, Contact, Privacy Policy, Terms & Conditions and Shipping & Refunds — with the full written copy already in place. It also builds the primary and legal menus, sets the homepage, and adds sample chapters, tracks, videos and artwork.', 'plague-dr-universe' ); ?>
		</p>

		<p style="max-width:60em">
			<?php esc_html_e( 'If WooCommerce is active it will also create the four store categories: Graphic Novels, Original Artwork, Music & Albums, and Apparel & Merch.', 'plague-dr-universe' ); ?>
		</p>

		<?php if ( $done ) : ?>
			<p><strong><?php esc_html_e( 'Demo content has already been imported.', 'plague-dr-universe' ); ?></strong>
			<?php esc_html_e( 'Running it again will skip anything that already exists.', 'plague-dr-universe' ); ?></p>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="pdu_import_demo">
			<?php wp_nonce_field( 'pdu_import_demo', 'pdu_demo_nonce' ); ?>
			<p>
				<button type="submit" class="button button-primary button-hero">
					<?php esc_html_e( 'Import demo content', 'plague-dr-universe' ); ?>
				</button>
			</p>
		</form>
	</div>
	<?php
}

/**
 * Create a page if one with that slug does not already exist.
 *
 * @param string $slug     Page slug.
 * @param string $title    Page title.
 * @param string $content  Block/HTML content.
 * @param string $template Optional page template file.
 * @param string $excerpt  Optional excerpt.
 * @return int Page ID.
 */
function pdu_maybe_create_page( $slug, $title, $content, $template = '', $excerpt = '' ) {
	$existing = get_page_by_path( $slug, OBJECT, 'page' );

	if ( $existing ) {
		// WordPress ships a draft "Privacy Policy" page. Publish it and drop
		// our copy in, rather than creating a duplicate at privacy-policy-2.
		if ( 'publish' !== $existing->post_status ) {
			$update = array(
				'ID'          => $existing->ID,
				'post_status' => 'publish',
			);
			if ( $content && ! trim( (string) $existing->post_content ) ) {
				$update['post_content'] = $content;
			}
			if ( $excerpt ) {
				$update['post_excerpt'] = $excerpt;
			}
			wp_update_post( $update );

			if ( $template ) {
				update_post_meta( $existing->ID, '_wp_page_template', $template );
			}
		}

		return (int) $existing->ID;
	}

	$id = wp_insert_post(
		array(
			'post_title'   => $title,
			'post_name'    => $slug,
			'post_content' => $content,
			'post_excerpt' => $excerpt,
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_author'  => get_current_user_id(),
		)
	);

	if ( $id && ! is_wp_error( $id ) && $template ) {
		update_post_meta( $id, '_wp_page_template', $template );
	}

	return (int) $id;
}

/**
 * Run the import.
 *
 * @return void
 */
function pdu_import_demo() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do that.', 'plague-dr-universe' ) );
	}

	$nonce = isset( $_POST['pdu_demo_nonce'] ) ? sanitize_key( wp_unslash( $_POST['pdu_demo_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'pdu_import_demo' ) ) {
		wp_die( esc_html__( 'Security check failed.', 'plague-dr-universe' ) );
	}

	require_once PDU_DIR . 'inc/demo-copy.php';

	/* ---------------------------------------------------------------
	 * 1. Pages
	 * ------------------------------------------------------------ */
	$home_id = pdu_maybe_create_page( 'home', __( 'Home', 'plague-dr-universe' ), '', '', '' );

	$universe_id = pdu_maybe_create_page(
		'the-universe',
		__( 'The Universe', 'plague-dr-universe' ),
		'',
		'page-templates/template-universe.php',
		__( 'The lore, the crossover, and how the ink, the noise and the story feed each other.', 'plague-dr-universe' )
	);

	$media_id = pdu_maybe_create_page(
		'media',
		__( 'Media', 'plague-dr-universe' ),
		'',
		'page-templates/template-media.php',
		__( 'Stream the soundtracks, watch the video releases and browse the full art portfolio.', 'plague-dr-universe' )
	);

	$contact_id = pdu_maybe_create_page(
		'contact',
		__( 'Contact', 'plague-dr-universe' ),
		'',
		'page-templates/template-contact.php',
		__( 'Commissions, licensing, press and community. Reach the studio directly.', 'plague-dr-universe' )
	);

	pdu_maybe_create_page( 'privacy-policy', __( 'Privacy Policy', 'plague-dr-universe' ), pdu_copy_privacy(), '', __( 'How we collect, use and protect your data.', 'plague-dr-universe' ) );
	pdu_maybe_create_page( 'terms-conditions', __( 'Terms &amp; Conditions', 'plague-dr-universe' ), pdu_copy_terms(), '', __( 'The rules for using this site and licensing our digital and physical work.', 'plague-dr-universe' ) );
	pdu_maybe_create_page( 'shipping-refunds', __( 'Shipping &amp; Refund Policy', 'plague-dr-universe' ), pdu_copy_shipping(), '', __( 'Dispatch times, delivery costs, returns and digital order policy.', 'plague-dr-universe' ) );

	$blog_id = pdu_maybe_create_page( 'dispatches', __( 'Dispatches', 'plague-dr-universe' ), '', '', '' );

	// Homepage + blog page.
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home_id );
	update_option( 'page_for_posts', $blog_id );

	// Point WordPress' privacy tools at the right page.
	$privacy = get_page_by_path( 'privacy-policy' );
	if ( $privacy ) {
		update_option( 'wp_page_for_privacy_policy', $privacy->ID );
	}

	/* ---------------------------------------------------------------
	 * 2. Multimedia samples
	 * ------------------------------------------------------------ */
	pdu_import_samples();

	/* ---------------------------------------------------------------
	 * 3. WooCommerce categories
	 * ------------------------------------------------------------ */
	if ( taxonomy_exists( 'product_cat' ) ) {
		$cats = array(
			'graphic-novels'   => array( __( 'Graphic Novels', 'plague-dr-universe' ), __( 'Print volumes, signed editions and DRM-free digital downloads of the serialised story.', 'plague-dr-universe' ) ),
			'original-artwork' => array( __( 'Original Artwork', 'plague-dr-universe' ), __( 'One-of-one originals and numbered archival giclée prints of the plates and panels.', 'plague-dr-universe' ) ),
			'music-albums'     => array( __( 'Music &amp; Albums', 'plague-dr-universe' ), __( 'Vinyl, CD and lossless downloads of the metal and ambient soundtrack catalogue.', 'plague-dr-universe' ) ),
			'apparel-merch'    => array( __( 'Apparel &amp; Merch', 'plague-dr-universe' ), __( 'Heavyweight tees, hoodies, patches and enamel pins printed on ethical blanks.', 'plague-dr-universe' ) ),
		);

		foreach ( $cats as $slug => $data ) {
			if ( ! term_exists( $slug, 'product_cat' ) ) {
				wp_insert_term(
					$data[0],
					'product_cat',
					array( 'slug' => $slug, 'description' => $data[1] )
				);
			}
		}
	}

	/* ---------------------------------------------------------------
	 * 4. Menus
	 * ------------------------------------------------------------ */
	pdu_build_menus( $universe_id, $media_id, $contact_id, $blog_id );

	// Keep visitor data off Gravatar's servers, as the privacy policy states.
	update_option( 'avatar_default', 'pdu_mask' );

	update_option( 'pdu_demo_imported', time() );
	flush_rewrite_rules();

	wp_safe_redirect( admin_url( 'themes.php?page=pdu-demo&imported=1' ) );
	exit;
}
add_action( 'admin_post_pdu_import_demo', 'pdu_import_demo' );

/**
 * Create the primary and legal menus.
 *
 * @param int $universe_id The Universe page ID.
 * @param int $media_id    Media page ID.
 * @param int $contact_id  Contact page ID.
 * @param int $blog_id     Dispatches page ID.
 * @return void
 */
function pdu_build_menus( $universe_id, $media_id, $contact_id, $blog_id ) {
	// --- Primary -------------------------------------------------------
	$primary = wp_get_nav_menu_object( 'Primary' );
	if ( ! $primary ) {
		$menu_id = wp_create_nav_menu( 'Primary' );

		if ( ! is_wp_error( $menu_id ) ) {
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'  => __( 'Home', 'plague-dr-universe' ),
				'menu-item-url'    => home_url( '/' ),
				'menu-item-status' => 'publish',
			) );
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'     => __( 'The Universe', 'plague-dr-universe' ),
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $universe_id,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			) );
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'  => __( 'Graphic Novel', 'plague-dr-universe' ),
				'menu-item-url'    => home_url( '/chapters/' ),
				'menu-item-status' => 'publish',
			) );
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'     => __( 'Media', 'plague-dr-universe' ),
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $media_id,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			) );
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'  => __( 'Store', 'plague-dr-universe' ),
				'menu-item-url'    => pdu_shop_url(),
				'menu-item-status' => 'publish',
			) );
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'     => __( 'Contact', 'plague-dr-universe' ),
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $contact_id,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			) );

			$locations            = get_theme_mod( 'nav_menu_locations', array() );
			$locations['primary'] = $menu_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	}

	// --- Legal ---------------------------------------------------------
	$legal = wp_get_nav_menu_object( 'Legal' );
	if ( ! $legal ) {
		$legal_id = wp_create_nav_menu( 'Legal' );
		if ( ! is_wp_error( $legal_id ) ) {
			$pages = array(
				'contact'          => __( 'Contact', 'plague-dr-universe' ),
				'shipping-refunds' => __( 'Shipping &amp; Refunds', 'plague-dr-universe' ),
				'terms-conditions' => __( 'Terms &amp; Conditions', 'plague-dr-universe' ),
				'privacy-policy'   => __( 'Privacy Policy', 'plague-dr-universe' ),
			);
			foreach ( $pages as $slug => $title ) {
				$page = get_page_by_path( $slug );
				if ( $page ) {
					wp_update_nav_menu_item( $legal_id, 0, array(
						'menu-item-title'     => $title,
						'menu-item-object'    => 'page',
						'menu-item-object-id' => $page->ID,
						'menu-item-type'      => 'post_type',
						'menu-item-status'    => 'publish',
					) );
				}
			}
			$locations          = get_theme_mod( 'nav_menu_locations', array() );
			$locations['legal'] = $legal_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	}
}

/**
 * Insert sample chapters, tracks, videos and artwork.
 *
 * @return void
 */
function pdu_import_samples() {
	$samples = array(
		'pdu_chapter' => array(
			array(
				'title'   => __( 'The Silence Between Sirens', 'plague-dr-universe' ),
				'excerpt' => __( 'Two days after the block went quiet, the Doctor walks First Avenue counting the windows that stayed dark.', 'plague-dr-universe' ),
				'content' => __( 'Chapter One opens on the aftermath. No spectacle, no explanation — just a man in a beaked mask walking a street that has already been swept, photographed and reopened, looking for the thing everybody else agreed not to see.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_chapter_number' => '01', 'pdu_page_count' => '28' ),
			),
			array(
				'title'   => __( 'Needle Through the Rain', 'plague-dr-universe' ),
				'excerpt' => __( 'Red and blue wash the Needle from the ground up. A patient who should not be walking climbs anyway.', 'plague-dr-universe' ),
				'content' => __( 'Chapter Two takes the story vertical. Every panel in this chapter was drawn from the same reference plate — the tower shot through a wall of rain — and rotated until the city stopped looking like a city.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_chapter_number' => '02', 'pdu_page_count' => '32' ),
			),
			array(
				'title'   => __( 'The Great Wheel Turns Anyway', 'plague-dr-universe' ),
				'excerpt' => __( 'On the waterfront the wheel keeps spinning through the downpour, carrying something that is no longer paying for the ride.', 'plague-dr-universe' ),
				'content' => __( 'Chapter Three is the quietest chapter in the book and the one readers write about most. Eleven of its thirty pages have no dialogue at all.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_chapter_number' => '03', 'pdu_page_count' => '30' ),
			),
		),
		'pdu_track'   => array(
			array(
				'title'   => __( 'Take the Streets Back', 'plague-dr-universe' ),
				'excerpt' => __( 'The anthem. Eighty-five BPM, bass-heavy chorus, layered vocals.', 'plague-dr-universe' ),
				'content' => __( 'Written in one sitting after a very bad week in the city. The chorus is the thesis of the whole record: holding onto peace while the world turns cold.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_album' => __( 'Emerald Rot — Side A', 'plague-dr-universe' ), 'pdu_duration' => '3:48' ),
			),
			array(
				'title'   => __( 'Sirens in the Distance', 'plague-dr-universe' ),
				'excerpt' => __( 'Slow piano loop, distant rainfall, quiet bassline. The opening statement.', 'plague-dr-universe' ),
				'content' => __( 'A two-minute overture built from a single field recording made on a fire escape at three in the morning.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_album' => __( 'Emerald Rot — Side A', 'plague-dr-universe' ), 'pdu_duration' => '2:14' ),
			),
			array(
				'title'   => __( 'No Answers in the Rain', 'plague-dr-universe' ),
				'excerpt' => __( 'The bridge, stripped to piano and a raw vocal.', 'plague-dr-universe' ),
				'content' => __( 'The beat drops out entirely for ninety seconds. Recorded in one take with the window open, which is why you can hear traffic under the second verse.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_album' => __( 'Emerald Rot — Side B', 'plague-dr-universe' ), 'pdu_duration' => '5:02' ),
			),
		),
		'pdu_video'   => array(
			array(
				'title'   => __( 'Take the Streets Back — Official Video', 'plague-dr-universe' ),
				'excerpt' => __( 'Rain-slicked asphalt, a stopped school bus, and dog tags swinging from a rearview mirror.', 'plague-dr-universe' ),
				'content' => __( 'Shot and composited entirely from stills and generated plates. No sensationalism, no explicit imagery — the whole video is about the space around an event rather than the event itself.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_duration' => '3:48' ),
			),
			array(
				'title'   => __( 'Chapter Two — Animatic', 'plague-dr-universe' ),
				'excerpt' => __( 'The full sequence board for Chapter Two, timed to the score.', 'plague-dr-universe' ),
				'content' => __( 'Before a single panel was inked, the whole chapter was cut as an animatic against the finished track to find the page turns.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_duration' => '2:06' ),
			),
		),
		'pdu_artwork' => array(
			array(
				'title'   => __( 'First Avenue, 22:08', 'plague-dr-universe' ),
				'excerpt' => __( 'The definitive portrait of the Doctor, used as the cover plate for Volume One.', 'plague-dr-universe' ),
				'content' => __( 'Brass buckles, waxed leather, and a beak stitched from a single piece of hide. Available as a numbered archival print.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_year' => '2025', 'pdu_dimensions' => __( 'Digital plate · 24×36 in print', 'plague-dr-universe' ) ),
			),
			array(
				'title'   => __( 'Needle, Red Shift', 'plague-dr-universe' ),
				'excerpt' => __( 'The tower seen from street level through a wall of rain.', 'plague-dr-universe' ),
				'content' => __( 'One of six city plates that anchor the second act. The reflections were painted as a separate layer and flipped.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_year' => '2025', 'pdu_dimensions' => __( 'City plate · 30×16 in print', 'plague-dr-universe' ) ),
			),
			array(
				'title'   => __( 'The Wheel Keeps Turning', 'plague-dr-universe' ),
				'excerpt' => __( 'The waterfront at its loneliest.', 'plague-dr-universe' ),
				'content' => __( 'Red and blue on black water. The only plate in the book that contains no human figure at all.', 'plague-dr-universe' ),
				'meta'    => array( 'pdu_year' => '2025', 'pdu_dimensions' => __( 'City plate · 30×16 in print', 'plague-dr-universe' ) ),
			),
		),
	);

	foreach ( $samples as $post_type => $items ) {
		foreach ( $items as $item ) {
			if ( get_page_by_title( $item['title'], OBJECT, $post_type ) ) {
				continue;
			}

			$id = wp_insert_post(
				array(
					'post_type'    => $post_type,
					'post_title'   => $item['title'],
					'post_excerpt' => $item['excerpt'],
					'post_content' => $item['content'],
					'post_status'  => 'publish',
					'post_author'  => get_current_user_id(),
				)
			);

			if ( $id && ! is_wp_error( $id ) ) {
				foreach ( $item['meta'] as $key => $value ) {
					update_post_meta( $id, $key, $value );
				}
			}
		}
	}
}
