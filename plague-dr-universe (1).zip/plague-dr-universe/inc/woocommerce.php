<?php
/**
 * WooCommerce integration.
 *
 * Only loaded when WooCommerce is active (see functions.php). Unhooks the
 * default wrappers and re-hooks our own so shop pages inherit the dark shell,
 * then tightens up a few defaults for a small, art-led catalogue.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Declare theme support and feature compatibility.
 *
 * @return void
 */
function pdu_woocommerce_support() {
	add_theme_support(
		'woocommerce',
		array(
			'thumbnail_image_width' => 800,
			'single_image_width'    => 1400,
			'product_grid'          => array(
				'default_rows'    => 3,
				'min_rows'        => 1,
				'default_columns' => 4,
				'min_columns'     => 2,
				'max_columns'     => 5,
			),
		)
	);

	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}
add_action( 'after_setup_theme', 'pdu_woocommerce_support' );

/* -------------------------------------------------------------------------
 * Layout wrappers
 * ---------------------------------------------------------------------- */

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );

/**
 * Open the shop wrapper, including the dark page-header band.
 *
 * @return void
 */
function pdu_woo_wrapper_start() {
	echo '<div class="' . esc_attr( pdu_content_offset_class() ) . '">';

	// Archive pages get the standard header band; single products handle their own.
	if ( ! is_product() ) {
		$title = woocommerce_page_title( false );
		$lede  = '';

		if ( is_shop() ) {
			$lede = __( 'Physical and digital goods straight from the studio. Packed by hand, shipped worldwide from Seattle.', 'plague-dr-universe' );
		} elseif ( is_product_category() || is_product_tag() ) {
			$term = get_queried_object();
			$lede = ( $term && ! empty( $term->description ) ) ? wp_strip_all_tags( $term->description ) : '';
		} elseif ( is_cart() ) {
			$lede = __( 'Review what you are taking home before you check out.', 'plague-dr-universe' );
		} elseif ( is_checkout() ) {
			$lede = __( 'Secure checkout. Your card details never touch our server.', 'plague-dr-universe' );
		} elseif ( is_account_page() ) {
			$lede = __( 'Orders, downloads, addresses and account details.', 'plague-dr-universe' );
		}

		get_template_part(
			'template-parts/components/page-header',
			null,
			array(
				'title' => $title,
				'lede'  => $lede,
			)
		);
	}

	echo '<div class="container section-tight"><div class="woocommerce-shell">';
}
add_action( 'woocommerce_before_main_content', 'pdu_woo_wrapper_start', 10 );

/**
 * Close the shop wrapper.
 *
 * @return void
 */
function pdu_woo_wrapper_end() {
	echo '</div></div></div>';
}
add_action( 'woocommerce_after_main_content', 'pdu_woo_wrapper_end', 10 );

// The theme provides its own breadcrumb, so drop WooCommerce's duplicate.
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );

// No sidebar on shop pages — the catalogue is small and image-led.
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

/* -------------------------------------------------------------------------
 * Catalogue tuning
 * ---------------------------------------------------------------------- */

/**
 * Products per page.
 *
 * @return int
 */
function pdu_products_per_page() {
	return 12;
}
add_filter( 'loop_shop_per_page', 'pdu_products_per_page', 20 );

/**
 * Columns in the product loop.
 *
 * @return int
 */
function pdu_loop_columns() {
	return 4;
}
add_filter( 'loop_shop_columns', 'pdu_loop_columns', 20 );

/**
 * Related products count.
 *
 * @param array $args Args.
 * @return array
 */
function pdu_related_products_args( $args ) {
	$args['posts_per_page'] = 4;
	$args['columns']        = 4;
	return $args;
}
add_filter( 'woocommerce_output_related_products_args', 'pdu_related_products_args', 20 );

/**
 * Add-to-cart button label per product type.
 *
 * @param string     $text    Default text.
 * @param WC_Product $product Product.
 * @return string
 */
function pdu_add_to_cart_text( $text, $product = null ) {
	if ( ! $product instanceof WC_Product ) {
		return $text;
	}
	if ( $product->is_type( 'variable' ) ) {
		return __( 'Choose options', 'plague-dr-universe' );
	}
	if ( $product->is_downloadable() || $product->is_virtual() ) {
		return __( 'Get the download', 'plague-dr-universe' );
	}
	if ( ! $product->is_in_stock() ) {
		return __( 'Sold out', 'plague-dr-universe' );
	}
	return __( 'Add to cart', 'plague-dr-universe' );
}
add_filter( 'woocommerce_product_add_to_cart_text', 'pdu_add_to_cart_text', 10, 2 );
add_filter( 'woocommerce_product_single_add_to_cart_text', 'pdu_add_to_cart_text', 10, 2 );

/**
 * Sale flash badge markup.
 *
 * @return string
 */
function pdu_sale_flash() {
	return '<span class="onsale">' . esc_html__( 'On sale', 'plague-dr-universe' ) . '</span>';
}
add_filter( 'woocommerce_sale_flash', 'pdu_sale_flash', 10, 1 );

/**
 * Continue-shopping URL points at the shop rather than the last product.
 *
 * @return string
 */
function pdu_continue_shopping_url() {
	return wc_get_page_permalink( 'shop' );
}
add_filter( 'woocommerce_continue_shopping_redirect', 'pdu_continue_shopping_url' );

/**
 * Trust badges under the single-product add-to-cart form.
 *
 * @return void
 */
function pdu_product_trust_badges() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}

	$items = array();

	if ( $product->is_downloadable() ) {
		$items[] = array( 'download', __( 'Instant DRM-free download', 'plague-dr-universe' ) );
		$items[] = array( 'shield', __( 'Lossless FLAC, WAV and 320k MP3', 'plague-dr-universe' ) );
	} else {
		$items[] = array( 'truck', __( 'Tracked worldwide shipping', 'plague-dr-universe' ) );
		$items[] = array( 'shield', __( '30-day returns on unused items', 'plague-dr-universe' ) );
	}
	$items[] = array( 'skull', __( 'Packed by hand in Seattle', 'plague-dr-universe' ) );

	echo '<ul class="mt-8 list-none space-y-3 border-t border-ink-400 p-0 pt-6">';
	foreach ( $items as $item ) {
		printf(
			'<li class="flex items-center gap-3 text-sm text-bone-300"><span class="text-amber-400">%s</span>%s</li>',
			pdu_icon( $item[0], 18 ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted SVG.
			esc_html( $item[1] )
		);
	}
	echo '</ul>';
}
add_action( 'woocommerce_after_add_to_cart_form', 'pdu_product_trust_badges', 15 );

/**
 * Show the shop category rail above the product loop on the main shop page.
 *
 * @return void
 */
function pdu_shop_category_rail() {
	if ( ! is_shop() || is_search() ) {
		return;
	}

	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'parent'     => 0,
			'number'     => 8,
		)
	);

	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return;
	}

	$icons = array(
		'graphic-novels'   => 'book',
		'original-artwork' => 'palette',
		'music-albums'     => 'disc',
		'apparel-merch'    => 'shirt',
	);

	echo '<ul class="mb-12 grid list-none gap-3 p-0 sm:grid-cols-2 lg:grid-cols-4">';
	foreach ( $terms as $term ) {
		$icon = $icons[ $term->slug ] ?? 'skull';
		printf(
			'<li class="relative border border-ink-400 bg-ink-800 p-5 transition-colors hover:border-blood-500">
				<span class="inline-grid h-10 w-10 place-items-center border border-amber-500/50 text-amber-400">%1$s</span>
				<h2 class="mt-4 text-base"><a class="stretched-link no-underline" href="%2$s">%3$s</a></h2>
				<p class="meta mt-2">%4$s</p>
			</li>',
			pdu_icon( $icon, 18 ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted SVG.
			esc_url( get_term_link( $term ) ),
			esc_html( $term->name ),
			esc_html(
				sprintf(
					/* translators: %d: product count. */
					_n( '%d item', '%d items', $term->count, 'plague-dr-universe' ),
					$term->count
				)
			)
		);
	}
	echo '</ul>';
}
add_action( 'woocommerce_before_shop_loop', 'pdu_shop_category_rail', 5 );

/**
 * Cart count fragment so the header badge refreshes on AJAX add-to-cart.
 *
 * @param array $fragments Existing fragments.
 * @return array
 */
function pdu_cart_fragment( $fragments ) {
	$count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;

	ob_start();
	printf(
		'<span class="absolute -right-0.5 -top-0.5 grid h-5 min-w-[1.25rem] place-items-center rounded-full bg-blood-600 px-1 font-display text-[0.65rem] leading-none text-white %1$s" data-pdu-cart-count>%2$s<span class="screen-reader-text">%3$s</span></span>',
		esc_attr( $count ? '' : 'hidden' ),
		esc_html( (string) $count ),
		esc_html__( 'items in cart', 'plague-dr-universe' )
	);
	$fragments['[data-pdu-cart-count]'] = ob_get_clean();

	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'pdu_cart_fragment' );

/**
 * Empty-cart message with a route back into the catalogue.
 *
 * @return void
 */
function pdu_empty_cart_message() {
	echo '<div class="border border-ink-400 bg-ink-800 p-10 text-center">';
	echo '<h2 class="text-2xl">' . esc_html__( 'Your cart is empty', 'plague-dr-universe' ) . '</h2>';
	echo '<p class="lede mx-auto mt-4 max-w-lg">' . esc_html__( 'Nothing in here yet. The graphic novels, prints and records are all waiting.', 'plague-dr-universe' ) . '</p>';
	echo '<a class="btn btn-primary mt-8" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">' . esc_html__( 'Browse the store', 'plague-dr-universe' ) . '</a>';
	echo '</div>';
}
remove_action( 'woocommerce_cart_is_empty', 'wc_empty_cart_message', 10 );
add_action( 'woocommerce_cart_is_empty', 'pdu_empty_cart_message', 10 );

/**
 * Remove the default WooCommerce stylesheets — the theme styles everything.
 *
 * The layout sheet is kept because it handles the product gallery grid.
 *
 * @param array $styles Enqueued WooCommerce styles.
 * @return array
 */
function pdu_dequeue_woo_styles( $styles ) {
	unset( $styles['woocommerce-general'] );
	unset( $styles['woocommerce-smallscreen'] );
	return $styles;
}
add_filter( 'woocommerce_enqueue_styles', 'pdu_dequeue_woo_styles' );

/**
 * Move the product description out of the tab stack on downloadable items so
 * the licensing terms are impossible to miss.
 *
 * @param array $tabs Tabs.
 * @return array
 */
function pdu_product_tabs( $tabs ) {
	global $product;

	if ( $product instanceof WC_Product && $product->is_downloadable() ) {
		$tabs['pdu_licence'] = array(
			'title'    => __( 'Licence', 'plague-dr-universe' ),
			'priority' => 25,
			'callback' => 'pdu_licence_tab_content',
		);
	}

	return $tabs;
}
add_filter( 'woocommerce_product_tabs', 'pdu_product_tabs' );

/**
 * Licence tab body.
 *
 * @return void
 */
function pdu_licence_tab_content() {
	echo '<h2>' . esc_html__( 'What you may do with this file', 'plague-dr-universe' ) . '</h2>';
	echo '<p>' . esc_html__( 'This purchase grants a non-exclusive, non-transferable, worldwide, perpetual licence for personal, non-commercial use. You may download it to devices you own, keep personal backups, and print a single copy for yourself.', 'plague-dr-universe' ) . '</p>';
	echo '<p>' . esc_html__( 'You may not redistribute, resell or share the file, use it commercially or in client work, mint it as an NFT, or use it to train any machine-learning model.', 'plague-dr-universe' ) . '</p>';
	printf(
		'<p><a href="%s">%s</a></p>',
		esc_url( home_url( '/terms-conditions/' ) ),
		esc_html__( 'Read the full licensing terms', 'plague-dr-universe' )
	);
}
