<?php
/**
 * Block editor integration, comment rendering and small view helpers.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Render a single comment.
 *
 * @param WP_Comment $comment Comment object.
 * @param array      $args    Args.
 * @param int        $depth   Depth.
 * @return void
 */
function pdu_comment_callback( $comment, $args, $depth ) {
	?>
	<li <?php comment_class( 'border border-ink-400 bg-ink-800 p-5' ); ?> id="comment-<?php comment_ID(); ?>">
		<article class="flex gap-4">
			<div class="shrink-0">
				<?php echo get_avatar( $comment, 48, '', '', array( 'class' => 'border border-ink-300' ) ); ?>
			</div>

			<div class="min-w-0 flex-1">
				<header class="flex flex-wrap items-baseline gap-x-3 gap-y-1">
					<span class="font-display text-sm uppercase tracking-brand text-bone-50">
						<?php comment_author_link(); ?>
					</span>
					<time class="meta" datetime="<?php comment_time( 'c' ); ?>">
						<?php comment_date(); ?>
					</time>
					<?php if ( ! $comment->comment_approved ) : ?>
						<span class="badge"><?php esc_html_e( 'Awaiting moderation', 'plague-dr-universe' ); ?></span>
					<?php endif; ?>
				</header>

				<div class="prose-pdu mt-3 text-sm">
					<?php comment_text(); ?>
				</div>

				<footer class="mt-4 flex gap-4">
					<?php
					comment_reply_link(
						array_merge(
							$args,
							array(
								'depth'      => $depth,
								'max_depth'  => $args['max_depth'],
								'reply_text' => esc_html__( 'Reply', 'plague-dr-universe' ),
								'before'     => '<span class="meta text-amber-400">',
								'after'      => '</span>',
							)
						)
					);
					edit_comment_link( esc_html__( 'Edit', 'plague-dr-universe' ), '<span class="meta">', '</span>' );
					?>
				</footer>
			</div>
		</article>
	<?php
	// WordPress closes the </li> for us.
}

/**
 * Register block patterns and a pattern category.
 *
 * @return void
 */
function pdu_register_patterns() {
	if ( ! function_exists( 'register_block_pattern_category' ) ) {
		return;
	}

	register_block_pattern_category(
		'plague-dr',
		array( 'label' => __( 'Plague Dr Universe', 'plague-dr-universe' ) )
	);

	register_block_pattern(
		'plague-dr-universe/cta-band',
		array(
			'title'      => __( 'Call to action band', 'plague-dr-universe' ),
			'categories' => array( 'plague-dr' ),
			'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"backgroundColor":"charred-coal","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-charred-coal-background-color has-background" style="padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
<!-- wp:heading {"textAlign":"center","textColor":"bone-white"} -->
<h2 class="wp-block-heading has-text-align-center has-bone-white-color has-text-color">Take something home</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","textColor":"ash-grey"} -->
<p class="has-text-align-center">Prints, records and volumes — packed by hand, shipped worldwide.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button {"backgroundColor":"blood-red"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-blood-red-background-color has-background wp-element-button">Enter the store</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->',
		)
	);

	register_block_pattern(
		'plague-dr-universe/lore-quote',
		array(
			'title'      => __( 'Lore pull quote', 'plague-dr-universe' ),
			'categories' => array( 'plague-dr' ),
			'content'    => '<!-- wp:quote {"className":"is-style-large"} -->
<blockquote class="wp-block-quote is-style-large"><!-- wp:paragraph -->
<p>Shadows stretch across the street, and the quiet runs too deep.</p>
<!-- /wp:paragraph --><cite>Take the Streets Back — Verse I</cite></blockquote>
<!-- /wp:quote -->',
		)
	);
}
add_action( 'init', 'pdu_register_patterns' );

/**
 * Remove the default WordPress patterns so the inserter stays on-brand.
 *
 * @return void
 */
function pdu_remove_core_patterns() {
	remove_theme_support( 'core-block-patterns' );
}
add_action( 'after_setup_theme', 'pdu_remove_core_patterns', 20 );
