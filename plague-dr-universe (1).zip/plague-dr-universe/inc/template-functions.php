<?php
/**
 * Functional helpers, body classes, form handlers and small filters.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resolve a shop URL, optionally to a product category, with a safe fallback
 * when WooCommerce is not active yet.
 *
 * @param string $category Optional product category slug.
 * @return string
 */
function pdu_shop_url( $category = '' ) {
	if ( class_exists( 'WooCommerce' ) ) {
		$base = wc_get_page_permalink( 'shop' );
		if ( $category ) {
			$term = get_term_by( 'slug', $category, 'product_cat' );
			if ( $term && ! is_wp_error( $term ) ) {
				return get_term_link( $term );
			}
		}
		if ( $base ) {
			return $base;
		}
	}
	return home_url( $category ? '/shop/?product_cat=' . rawurlencode( $category ) : '/shop/' );
}

/**
 * Extra body classes for layout hooks.
 *
 * @param array $classes Body classes.
 * @return array
 */
function pdu_body_classes( $classes ) {
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}
	if ( is_front_page() ) {
		$classes[] = 'pdu-transparent-header';
	}
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}
	$classes[] = 'pdu-theme';
	return $classes;
}
add_filter( 'body_class', 'pdu_body_classes' );

/**
 * Pad the top of the page for the fixed header on interior pages.
 *
 * The homepage hero sits underneath the transparent header by design.
 *
 * @return string
 */
function pdu_content_offset_class() {
	return is_front_page() ? '' : 'pt-[4.5rem] md:pt-[6.5rem]';
}

/**
 * Strip the "Archives:" / "Category:" prefixes from archive titles — the
 * page-header band already makes the context obvious.
 *
 * @param string $title Archive title.
 * @return string
 */
function pdu_archive_title( $title ) {
	if ( is_post_type_archive() ) {
		$title = post_type_archive_title( '', false );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$title = single_term_title( '', false );
	} elseif ( is_author() ) {
		$title = get_the_author();
	} elseif ( is_year() ) {
		$title = get_the_date( _x( 'Y', 'yearly archives date format', 'plague-dr-universe' ) );
	} elseif ( is_month() ) {
		$title = get_the_date( _x( 'F Y', 'monthly archives date format', 'plague-dr-universe' ) );
	}
	return $title;
}
add_filter( 'get_the_archive_title', 'pdu_archive_title' );

/**
 * More readable excerpt length.
 *
 * @param int $length Default length.
 * @return int
 */
function pdu_excerpt_length( $length ) {
	return 26;
}
add_filter( 'excerpt_length', 'pdu_excerpt_length' );

/**
 * Excerpt ellipsis.
 *
 * @param string $more More string.
 * @return string
 */
function pdu_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'pdu_excerpt_more' );

/**
 * Style the "read more" link inside content.
 *
 * @return string
 */
function pdu_content_more_link() {
	return sprintf(
		'<p><a class="btn btn-secondary btn-sm" href="%s">%s</a></p>',
		esc_url( get_permalink() ),
		esc_html__( 'Continue reading', 'plague-dr-universe' )
	);
}
add_filter( 'the_content_more_link', 'pdu_content_more_link' );

/**
 * Accessible, styled pagination.
 *
 * @return void
 */
function pdu_pagination() {
	$links = paginate_links(
		array(
			'mid_size'  => 1,
			'prev_text' => esc_html__( '&larr; Newer', 'plague-dr-universe' ),
			'next_text' => esc_html__( 'Older &rarr;', 'plague-dr-universe' ),
			'type'      => 'array',
		)
	);

	if ( empty( $links ) ) {
		return;
	}

	echo '<nav class="pagination mt-14 flex flex-wrap items-center justify-center gap-2" aria-label="' . esc_attr__( 'Posts navigation', 'plague-dr-universe' ) . '">';
	foreach ( $links as $link ) {
		echo wp_kses_post( $link );
	}
	echo '</nav>';
}

/**
 * Handle the newsletter signup submission.
 *
 * Stores subscribers as a private CPT-free option list and emails the admin.
 * Designed to be replaced by Mailchimp/ConvertKit later without template edits.
 *
 * @return void
 */
function pdu_handle_newsletter() {
	$nonce = isset( $_POST['pdu_newsletter_nonce'] ) ? sanitize_key( wp_unslash( $_POST['pdu_newsletter_nonce'] ) ) : '';

	if ( ! wp_verify_nonce( $nonce, 'pdu_newsletter' ) ) {
		wp_safe_redirect( add_query_arg( 'subscribed', 'error', wp_get_referer() ? wp_get_referer() : home_url( '/' ) ) );
		exit;
	}

	// Honeypot tripped — pretend success, drop the submission.
	if ( ! empty( $_POST['pdu_hp'] ) ) {
		wp_safe_redirect( add_query_arg( 'subscribed', '1', wp_get_referer() ? wp_get_referer() : home_url( '/' ) ) );
		exit;
	}

	$email = isset( $_POST['pdu_email'] ) ? sanitize_email( wp_unslash( $_POST['pdu_email'] ) ) : '';

	if ( ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'subscribed', 'invalid', wp_get_referer() ? wp_get_referer() : home_url( '/' ) ) );
		exit;
	}

	// Throttle abuse, but answer as if it worked so bots learn nothing.
	if ( ! pdu_rate_ok( 'news', 8 ) ) {
		wp_safe_redirect( add_query_arg( 'subscribed', '1', wp_get_referer() ? wp_get_referer() : home_url( '/' ) ) );
		exit;
	}

	$mailed = wp_mail(
		get_theme_mod( 'pdu_email', get_option( 'admin_email' ) ),
		/* translators: %s: site name. */
		sprintf( __( '[%s] New Dispatch subscriber', 'plague-dr-universe' ), get_bloginfo( 'name' ) ),
		sprintf(
			/* translators: %s: subscriber email. */
			__( 'New subscriber: %s', 'plague-dr-universe' ),
			$email
		)
	);

	// Always persist. Email delivery is best-effort; the record is not.
	pdu_store_subscriber( $email, $mailed );

	wp_safe_redirect( add_query_arg( 'subscribed', '1', wp_get_referer() ? wp_get_referer() : home_url( '/' ) ) );
	exit;
}
add_action( 'admin_post_nopriv_pdu_newsletter', 'pdu_handle_newsletter' );
add_action( 'admin_post_pdu_newsletter', 'pdu_handle_newsletter' );

/**
 * Handle the contact form submission.
 *
 * @return void
 */
function pdu_handle_contact() {
	$nonce    = isset( $_POST['pdu_contact_nonce'] ) ? sanitize_key( wp_unslash( $_POST['pdu_contact_nonce'] ) ) : '';
	$referer  = wp_get_referer() ? wp_get_referer() : home_url( '/contact/' );

	if ( ! wp_verify_nonce( $nonce, 'pdu_contact' ) ) {
		wp_safe_redirect( add_query_arg( 'sent', 'error', $referer ) );
		exit;
	}

	if ( ! empty( $_POST['pdu_hp'] ) ) {
		wp_safe_redirect( add_query_arg( 'sent', '1', $referer ) );
		exit;
	}

	$name    = isset( $_POST['pdu_name'] ) ? sanitize_text_field( wp_unslash( $_POST['pdu_name'] ) ) : '';
	$email   = isset( $_POST['pdu_email'] ) ? sanitize_email( wp_unslash( $_POST['pdu_email'] ) ) : '';
	$subject = isset( $_POST['pdu_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['pdu_subject'] ) ) : '';
	$message = isset( $_POST['pdu_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['pdu_message'] ) ) : '';

	if ( ! $name || ! is_email( $email ) || ! $message ) {
		wp_safe_redirect( add_query_arg( 'sent', 'invalid', $referer ) );
		exit;
	}

	if ( ! pdu_rate_ok( 'contact', 6 ) ) {
		wp_safe_redirect( add_query_arg( 'sent', '1', $referer ) );
		exit;
	}

	$to = get_theme_mod( 'pdu_email', get_option( 'admin_email' ) );

	$sent = wp_mail(
		$to,
		sprintf(
			/* translators: 1: site name, 2: chosen subject. */
			__( '[%1$s] %2$s', 'plague-dr-universe' ),
			get_bloginfo( 'name' ),
			$subject ? $subject : __( 'Website enquiry', 'plague-dr-universe' )
		),
		sprintf(
			/* translators: 1: name, 2: email, 3: subject, 4: message body. */
			__( "Name: %1\$s\nEmail: %2\$s\nSubject: %3\$s\n\n%4\$s", 'plague-dr-universe' ),
			$name,
			$email,
			$subject,
			$message
		),
		array( 'Reply-To: ' . $name . ' <' . $email . '>' )
	);

	// Save the enquiry regardless of mail success, then report success as long
	// as we captured it somewhere — a stored message is not a lost message.
	$stored = pdu_store_enquiry(
		array(
			'name'    => $name,
			'email'   => $email,
			'subject' => $subject,
			'message' => $message,
			'mailed'  => $sent,
		)
	);

	wp_safe_redirect( add_query_arg( 'sent', ( $sent || $stored ) ? '1' : 'error', $referer ) );
	exit;
}
add_action( 'admin_post_nopriv_pdu_contact', 'pdu_handle_contact' );
add_action( 'admin_post_pdu_contact', 'pdu_handle_contact' );

/**
 * Print a status notice after a form redirect.
 *
 * @param string $param Query arg to inspect ('sent' or 'subscribed').
 * @return void
 */
function pdu_form_notice( $param = 'sent' ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only display flag.
	$state = isset( $_GET[ $param ] ) ? sanitize_key( wp_unslash( $_GET[ $param ] ) ) : '';
	if ( ! $state ) {
		return;
	}

	$messages = array(
		'1'       => 'sent' === $param
			? __( 'Message received. The Doctor reads everything — expect a reply within a few days.', 'plague-dr-universe' )
			: __( 'You are on the list. Watch your inbox for the next drop.', 'plague-dr-universe' ),
		'invalid' => __( 'Please check the highlighted fields and try again.', 'plague-dr-universe' ),
		'error'   => __( 'Something went wrong sending that. Please email us directly.', 'plague-dr-universe' ),
	);

	$text = $messages[ $state ] ?? $messages['error'];
	$ok   = ( '1' === $state );

	printf(
		'<div class="notice-pdu mb-8 %1$s" role="status"><p class="m-0">%2$s</p></div>',
		esc_attr( $ok ? 'border-amber-500' : 'border-blood-500' ),
		esc_html( $text )
	);
}

/**
 * Make search results skip attachments.
 *
 * @param WP_Query $query Query.
 * @return void
 */
function pdu_search_filter( $query ) {
	if ( ! is_admin() && $query->is_main_query() && $query->is_search() ) {
		$query->set( 'post_status', 'publish' );
	}
}
add_action( 'pre_get_posts', 'pdu_search_filter' );

/**
 * Add `rel="noopener"` and an off-screen hint to external links in content.
 *
 * @param string $content Content.
 * @return string
 */
function pdu_external_links( $content ) {
	if ( is_admin() || is_feed() || empty( $content ) ) {
		return $content;
	}
	return preg_replace(
		'/<a (?![^>]*\brel=)([^>]*target=["\']_blank["\'][^>]*)>/i',
		'<a rel="noopener noreferrer" $1>',
		$content
	);
}
add_filter( 'the_content', 'pdu_external_links', 25 );

/**
 * Register a lightweight cart-count fragment refresh endpoint.
 *
 * @return void
 */
function pdu_cart_count_fragment() {
	if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
		wp_send_json_error();
	}
	wp_send_json_success( array( 'count' => WC()->cart->get_cart_contents_count() ) );
}
add_action( 'wp_ajax_pdu_cart_count', 'pdu_cart_count_fragment' );
add_action( 'wp_ajax_nopriv_pdu_cart_count', 'pdu_cart_count_fragment' );

/**
 * Offer a self-hosted default avatar.
 *
 * Gravatar sends every commenter's hashed email — and their visitors' IP
 * addresses — to a third party on page load. The privacy policy promises no
 * third-party tracking, so the theme ships a local default instead.
 *
 * @param array $avatars Default avatar choices.
 * @return array
 */
function pdu_default_avatar( $avatars ) {
	$avatars['pdu_mask'] = __( 'Plague mask (local, no Gravatar request)', 'plague-dr-universe' );
	return $avatars;
}
add_filter( 'avatar_defaults', 'pdu_default_avatar' );

/**
 * Serve the local avatar and skip the Gravatar request entirely.
 *
 * Only bypasses Gravatar when the site has opted into the local default, so
 * existing sites that want Gravatar keep it.
 *
 * @param array $args Avatar arguments.
 * @param mixed $id_or_email User identifier.
 * @return array
 */
function pdu_local_avatar( $args, $id_or_email ) {
	unset( $id_or_email );

	if ( 'pdu_mask' !== get_option( 'avatar_default' ) ) {
		return $args;
	}

	$args['url']          = PDU_URI . 'assets/images/avatar-default.svg';
	$args['found_avatar'] = true;

	return $args;
}
add_filter( 'pre_get_avatar_data', 'pdu_local_avatar', 10, 2 );
