<?php
/**
 * Custom content types for the universe: chapters, tracks, videos, artwork.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the multimedia post types.
 *
 * @return void
 */
function pdu_register_post_types() {
	$types = array(
		'pdu_chapter' => array(
			'singular'  => __( 'Chapter', 'plague-dr-universe' ),
			'plural'    => __( 'Graphic Novel', 'plague-dr-universe' ),
			'slug'      => 'chapters',
			'icon'      => 'dashicons-book-alt',
			'supports'  => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'custom-fields' ),
			'taxonomy'  => array( 'pdu_arc', __( 'Story Arc', 'plague-dr-universe' ), 'arc' ),
		),
		'pdu_track'   => array(
			'singular'  => __( 'Track', 'plague-dr-universe' ),
			'plural'    => __( 'Soundtracks', 'plague-dr-universe' ),
			'slug'      => 'soundtracks',
			'icon'      => 'dashicons-format-audio',
			'supports'  => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
			'taxonomy'  => array( 'pdu_genre', __( 'Genre', 'plague-dr-universe' ), 'genre' ),
		),
		'pdu_video'   => array(
			'singular'  => __( 'Video', 'plague-dr-universe' ),
			'plural'    => __( 'Video Releases', 'plague-dr-universe' ),
			'slug'      => 'videos',
			'icon'      => 'dashicons-video-alt3',
			'supports'  => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
			'taxonomy'  => array( 'pdu_video_type', __( 'Video Type', 'plague-dr-universe' ), 'video-type' ),
		),
		'pdu_artwork' => array(
			'singular'  => __( 'Artwork', 'plague-dr-universe' ),
			'plural'    => __( 'Artwork', 'plague-dr-universe' ),
			'slug'      => 'artwork',
			'icon'      => 'dashicons-art',
			'supports'  => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
			'taxonomy'  => array( 'pdu_medium', __( 'Medium', 'plague-dr-universe' ), 'medium' ),
		),
	);

	foreach ( $types as $key => $cfg ) {
		$labels = array(
			'name'                  => $cfg['plural'],
			'singular_name'         => $cfg['singular'],
			/* translators: %s: singular post type name. */
			'add_new_item'          => sprintf( __( 'Add New %s', 'plague-dr-universe' ), $cfg['singular'] ),
			/* translators: %s: singular post type name. */
			'edit_item'             => sprintf( __( 'Edit %s', 'plague-dr-universe' ), $cfg['singular'] ),
			/* translators: %s: singular post type name. */
			'new_item'              => sprintf( __( 'New %s', 'plague-dr-universe' ), $cfg['singular'] ),
			/* translators: %s: singular post type name. */
			'view_item'             => sprintf( __( 'View %s', 'plague-dr-universe' ), $cfg['singular'] ),
			/* translators: %s: plural post type name. */
			'search_items'          => sprintf( __( 'Search %s', 'plague-dr-universe' ), $cfg['plural'] ),
			/* translators: %s: plural post type name. */
			'not_found'             => sprintf( __( 'No %s found', 'plague-dr-universe' ), strtolower( $cfg['plural'] ) ),
			'all_items'             => $cfg['plural'],
			'featured_image'        => __( 'Cover Image', 'plague-dr-universe' ),
			'set_featured_image'    => __( 'Set cover image', 'plague-dr-universe' ),
			'remove_featured_image' => __( 'Remove cover image', 'plague-dr-universe' ),
		);

		register_post_type(
			$key,
			array(
				'labels'             => $labels,
				'public'             => true,
				'has_archive'        => $cfg['slug'],
				'rewrite'            => array( 'slug' => $cfg['slug'], 'with_front' => false ),
				'menu_icon'          => $cfg['icon'],
				'menu_position'      => 22,
				'supports'           => $cfg['supports'],
				'show_in_rest'       => true,
				'publicly_queryable' => true,
				'hierarchical'       => false,
				'capability_type'    => 'post',
			)
		);

		list( $tax_key, $tax_label, $tax_slug ) = $cfg['taxonomy'];

		register_taxonomy(
			$tax_key,
			$key,
			array(
				'labels'            => array(
					'name'          => $tax_label,
					'singular_name' => $tax_label,
					/* translators: %s: taxonomy label. */
					'search_items'  => sprintf( __( 'Search %s', 'plague-dr-universe' ), $tax_label ),
					/* translators: %s: taxonomy label. */
					'all_items'     => sprintf( __( 'All %s', 'plague-dr-universe' ), $tax_label ),
				),
				'hierarchical'      => true,
				'public'            => true,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => $tax_slug, 'with_front' => false ),
			)
		);
	}
}
add_action( 'init', 'pdu_register_post_types' );

/**
 * Meta fields for the multimedia types, exposed to the REST API and editor.
 *
 * @return void
 */
function pdu_register_meta() {
	$string_meta = array(
		'pdu_track'   => array( 'pdu_audio_url', 'pdu_duration', 'pdu_album', 'pdu_buy_url' ),
		'pdu_video'   => array( 'pdu_video_url', 'pdu_duration', 'pdu_runtime_note' ),
		'pdu_chapter' => array( 'pdu_chapter_number', 'pdu_read_url', 'pdu_page_count' ),
		'pdu_artwork' => array( 'pdu_year', 'pdu_dimensions', 'pdu_print_url' ),
	);

	foreach ( $string_meta as $post_type => $keys ) {
		foreach ( $keys as $key ) {
			register_post_meta(
				$post_type,
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => 'sanitize_text_field',
					'auth_callback'     => static function () {
						return current_user_can( 'edit_posts' );
					},
				)
			);
		}
	}
}
add_action( 'init', 'pdu_register_meta' );

/**
 * Add the multimedia types to the main search results.
 *
 * @param WP_Query $query Query object.
 * @return void
 */
function pdu_include_cpts_in_search( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( $query->is_search() ) {
		$query->set( 'post_type', array( 'post', 'page', 'pdu_chapter', 'pdu_track', 'pdu_video', 'pdu_artwork', 'product' ) );
	}
	// Show a fuller grid on the multimedia archives.
	if ( $query->is_post_type_archive( array( 'pdu_chapter', 'pdu_track', 'pdu_video', 'pdu_artwork' ) ) ) {
		$query->set( 'posts_per_page', 12 );
	}
}
add_action( 'pre_get_posts', 'pdu_include_cpts_in_search' );

/**
 * Simple meta box so the fields are editable without extra plugins.
 *
 * @return void
 */
function pdu_add_meta_boxes() {
	$map = array(
		'pdu_track'   => __( 'Track Details', 'plague-dr-universe' ),
		'pdu_video'   => __( 'Video Details', 'plague-dr-universe' ),
		'pdu_chapter' => __( 'Chapter Details', 'plague-dr-universe' ),
		'pdu_artwork' => __( 'Artwork Details', 'plague-dr-universe' ),
	);
	foreach ( $map as $screen => $title ) {
		add_meta_box( 'pdu-details', $title, 'pdu_render_meta_box', $screen, 'side', 'default' );
	}
}
add_action( 'add_meta_boxes', 'pdu_add_meta_boxes' );

/**
 * Render the details meta box.
 *
 * @param WP_Post $post Current post.
 * @return void
 */
function pdu_render_meta_box( $post ) {
	$fields = array(
		'pdu_track'   => array(
			'pdu_audio_url' => __( 'Audio file URL (mp3/ogg)', 'plague-dr-universe' ),
			'pdu_album'     => __( 'Album / release', 'plague-dr-universe' ),
			'pdu_duration'  => __( 'Duration (e.g. 4:12)', 'plague-dr-universe' ),
			'pdu_buy_url'   => __( 'Buy / stream URL', 'plague-dr-universe' ),
		),
		'pdu_video'   => array(
			'pdu_video_url'    => __( 'Video URL (YouTube/Vimeo/mp4)', 'plague-dr-universe' ),
			'pdu_duration'     => __( 'Duration', 'plague-dr-universe' ),
			'pdu_runtime_note' => __( 'Runtime note', 'plague-dr-universe' ),
		),
		'pdu_chapter' => array(
			'pdu_chapter_number' => __( 'Chapter number', 'plague-dr-universe' ),
			'pdu_page_count'     => __( 'Page count', 'plague-dr-universe' ),
			'pdu_read_url'       => __( 'Read / buy URL', 'plague-dr-universe' ),
		),
		'pdu_artwork' => array(
			'pdu_year'       => __( 'Year', 'plague-dr-universe' ),
			'pdu_dimensions' => __( 'Dimensions / medium', 'plague-dr-universe' ),
			'pdu_print_url'  => __( 'Print shop URL', 'plague-dr-universe' ),
		),
	);

	$type = get_post_type( $post );
	if ( empty( $fields[ $type ] ) ) {
		return;
	}

	wp_nonce_field( 'pdu_save_meta', 'pdu_meta_nonce' );

	foreach ( $fields[ $type ] as $key => $label ) {
		printf(
			'<p><label for="%1$s" style="display:block;font-weight:600;margin-bottom:4px">%2$s</label>
			 <input type="text" id="%1$s" name="%1$s" value="%3$s" class="widefat"></p>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( (string) get_post_meta( $post->ID, $key, true ) )
		);
	}
}

/**
 * Persist meta box values.
 *
 * @param int $post_id Post ID.
 * @return void
 */
function pdu_save_meta( $post_id ) {
	if ( ! isset( $_POST['pdu_meta_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['pdu_meta_nonce'] ) ), 'pdu_save_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$keys = array(
		'pdu_audio_url', 'pdu_album', 'pdu_duration', 'pdu_buy_url',
		'pdu_video_url', 'pdu_runtime_note',
		'pdu_chapter_number', 'pdu_page_count', 'pdu_read_url',
		'pdu_year', 'pdu_dimensions', 'pdu_print_url',
	);

	foreach ( $keys as $key ) {
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$raw   = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
		$value = ( false !== strpos( $key, '_url' ) ) ? esc_url_raw( $raw ) : $raw;

		if ( '' === $value ) {
			delete_post_meta( $post_id, $key );
		} else {
			update_post_meta( $post_id, $key, $value );
		}
	}
}
add_action( 'save_post', 'pdu_save_meta' );
