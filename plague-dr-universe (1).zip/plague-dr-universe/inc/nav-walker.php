<?php
/**
 * Accessible navigation walkers.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Desktop primary menu walker.
 *
 * Adds the `.nav-link` class, marks the current page with aria-current and
 * exposes sub-menus to keyboard users via aria-expanded on the parent link.
 */
class PDU_Walker_Nav_Menu extends Walker_Nav_Menu {

	/**
	 * Start the sub-menu level.
	 *
	 * @param string   $output Output buffer.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Menu args.
	 * @return void
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '<ul class="sub-menu list-none">';
	}

	/**
	 * End the sub-menu level.
	 *
	 * @param string   $output Output buffer.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Menu args.
	 * @return void
	 */
	public function end_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '</ul>';
	}

	/**
	 * Start an element.
	 *
	 * @param string   $output Output buffer.
	 * @param WP_Post  $item   Menu item.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Menu args.
	 * @param int      $id     Item ID.
	 * @return void
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$classes   = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[] = 'menu-item-' . $item->ID;
		$has_kids  = in_array( 'menu-item-has-children', $classes, true );

		if ( 0 === $depth ) {
			$classes[] = 'relative';
		}

		$class_names = implode( ' ', array_map( 'sanitize_html_class', array_filter( $classes ) ) );

		$output .= sprintf( '<li class="%s">', esc_attr( $class_names ) );

		$atts = array(
			'href'   => ! empty( $item->url ) ? $item->url : '#',
			'title'  => ! empty( $item->attr_title ) ? $item->attr_title : '',
			'target' => ! empty( $item->target ) ? $item->target : '',
			'rel'    => ! empty( $item->xfn ) ? $item->xfn : '',
			'class'  => 0 === $depth ? 'nav-link inline-flex items-center gap-1.5' : '',
		);

		if ( in_array( 'current-menu-item', $classes, true ) || in_array( 'current_page_item', $classes, true ) ) {
			$atts['aria-current'] = 'page';
		}

		if ( '_blank' === $atts['target'] && empty( $atts['rel'] ) ) {
			$atts['rel'] = 'noopener noreferrer';
		}

		$attributes = '';
		foreach ( $atts as $key => $value ) {
			if ( '' === $value || false === $value ) {
				continue;
			}
			$attributes .= sprintf( ' %s="%s"', $key, ( 'href' === $key ) ? esc_url( $value ) : esc_attr( $value ) );
		}

		$title = apply_filters( 'the_title', $item->title, $item->ID );

		$chevron = $has_kids && 0 === $depth
			? '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true" focusable="false"><path d="m6 9 6 6 6-6"/></svg>'
			: '';

		$output .= sprintf(
			'<a%1$s>%2$s%3$s</a>',
			$attributes, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
			esc_html( $title ),
			$chevron // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG.
		);
	}

	/**
	 * End an element.
	 *
	 * @param string   $output Output buffer.
	 * @param WP_Post  $item   Menu item.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Menu args.
	 * @return void
	 */
	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= '</li>';
	}
}

/**
 * Fallback menu used before the client builds a real one in Appearance → Menus.
 *
 * Mirrors the required site map so the theme is usable on activation.
 *
 * @param array $args Menu args.
 * @return void
 */
function pdu_fallback_menu( $args = array() ) {
	$is_drawer = ! empty( $args['theme_location'] ) && 'drawer' === $args['theme_location'];
	$link_cls  = $is_drawer ? '' : 'nav-link';

	$items = array(
		home_url( '/' )                 => __( 'Home', 'plague-dr-universe' ),
		home_url( '/the-universe/' )    => __( 'The Universe', 'plague-dr-universe' ),
		home_url( '/chapters/' )        => __( 'Graphic Novel', 'plague-dr-universe' ),
		home_url( '/media/' )           => __( 'Media', 'plague-dr-universe' ),
		home_url( '/shop/' )            => __( 'Store', 'plague-dr-universe' ),
		home_url( '/contact/' )         => __( 'Contact', 'plague-dr-universe' ),
	);

	$ul_class = $args['menu_class'] ?? 'menu-main';
	echo '<ul class="' . esc_attr( $ul_class ) . '">';
	foreach ( $items as $url => $label ) {
		printf(
			'<li class="relative"><a class="%1$s" href="%2$s">%3$s</a></li>',
			esc_attr( $link_cls ),
			esc_url( $url ),
			esc_html( $label )
		);
	}
	echo '</ul>';
}
