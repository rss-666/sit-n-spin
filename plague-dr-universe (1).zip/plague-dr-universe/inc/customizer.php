<?php
/**
 * Customizer settings — everything the client should be able to change
 * without touching code.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register panels, sections and controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer instance.
 * @return void
 */
function pdu_customize_register( $wp_customize ) {

	$wp_customize->get_setting( 'blogname' )->transport        = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	$wp_customize->add_panel(
		'pdu_panel',
		array(
			'title'       => __( 'Plague Dr Universe', 'plague-dr-universe' ),
			'description' => __( 'Theme-wide content, hero copy, social links and contact details.', 'plague-dr-universe' ),
			'priority'    => 20,
		)
	);

	/* ---------------------------------------------------------------
	 * Hero
	 * ------------------------------------------------------------ */
	$wp_customize->add_section(
		'pdu_hero',
		array(
			'title' => __( 'Homepage Hero', 'plague-dr-universe' ),
			'panel' => 'pdu_panel',
		)
	);

	$hero_fields = array(
		'pdu_hero_eyebrow'   => array(
			'label'   => __( 'Eyebrow', 'plague-dr-universe' ),
			'default' => __( 'Ink · Noise · Rain', 'plague-dr-universe' ),
			'type'    => 'text',
		),
		'pdu_hero_title'     => array(
			'label'   => __( 'Headline', 'plague-dr-universe' ),
			'default' => __( 'Welcome to The Plague Dr Universe', 'plague-dr-universe' ),
			'type'    => 'text',
		),
		'pdu_hero_text'      => array(
			'label'   => __( 'Intro paragraph', 'plague-dr-universe' ),
			'default' => __( 'A graphic novel, a soundtrack and a city that will not stop raining. Original artwork, heavy music and serialised story — all from one hand, all in one place.', 'plague-dr-universe' ),
			'type'    => 'textarea',
		),
		'pdu_hero_cta1_text' => array(
			'label'   => __( 'Primary button label', 'plague-dr-universe' ),
			'default' => __( 'Explore Art &amp; Comics', 'plague-dr-universe' ),
			'type'    => 'text',
		),
		'pdu_hero_cta1_url'  => array(
			'label'   => __( 'Primary button URL', 'plague-dr-universe' ),
			'default' => '/chapters/',
			'type'    => 'url',
		),
		'pdu_hero_cta2_text' => array(
			'label'   => __( 'Secondary button label', 'plague-dr-universe' ),
			'default' => __( 'Listen to the Soundtracks', 'plague-dr-universe' ),
			'type'    => 'text',
		),
		'pdu_hero_cta2_url'  => array(
			'label'   => __( 'Secondary button URL', 'plague-dr-universe' ),
			'default' => '#soundtracks',
			'type'    => 'text',
		),
	);

	foreach ( $hero_fields as $id => $cfg ) {
		$wp_customize->add_setting(
			$id,
			array(
				'default'           => $cfg['default'],
				'sanitize_callback' => ( 'url' === $cfg['type'] ) ? 'esc_url_raw' : 'wp_kses_post',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			$id,
			array(
				'label'   => $cfg['label'],
				'section' => 'pdu_hero',
				'type'    => ( 'textarea' === $cfg['type'] ) ? 'textarea' : 'text',
			)
		);
	}

	$wp_customize->add_setting( 'pdu_hero_image', array( 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'pdu_hero_image',
			array(
				'label'       => __( 'Hero background image', 'plague-dr-universe' ),
				'description' => __( 'Defaults to the bundled Plague Doctor photograph.', 'plague-dr-universe' ),
				'section'     => 'pdu_hero',
			)
		)
	);

	/* ---------------------------------------------------------------
	 * Announcement
	 * ------------------------------------------------------------ */
	$wp_customize->add_section(
		'pdu_announce_section',
		array(
			'title' => __( 'Announcement Bar', 'plague-dr-universe' ),
			'panel' => 'pdu_panel',
		)
	);
	$wp_customize->add_setting(
		'pdu_announcement',
		array(
			'default'           => __( 'New chapter + soundtrack drop — free worldwide shipping on orders over $75', 'plague-dr-universe' ),
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'pdu_announcement',
		array(
			'label'       => __( 'Announcement text', 'plague-dr-universe' ),
			'description' => __( 'Leave empty to hide the bar.', 'plague-dr-universe' ),
			'section'     => 'pdu_announce_section',
			'type'        => 'text',
		)
	);

	/* ---------------------------------------------------------------
	 * Social
	 * ------------------------------------------------------------ */
	$wp_customize->add_section(
		'pdu_social',
		array(
			'title' => __( 'Social Links', 'plague-dr-universe' ),
			'panel' => 'pdu_panel',
		)
	);

	$networks = array(
		'instagram' => 'Instagram',
		'youtube'   => 'YouTube',
		'bandcamp'  => 'Bandcamp',
		'spotify'   => 'Spotify',
		'tiktok'    => 'TikTok',
		'x'         => 'X (Twitter)',
	);

	foreach ( $networks as $key => $label ) {
		$wp_customize->add_setting( 'pdu_social_' . $key, array( 'sanitize_callback' => 'esc_url_raw' ) );
		$wp_customize->add_control(
			'pdu_social_' . $key,
			array(
				'label'   => $label,
				'section' => 'pdu_social',
				'type'    => 'url',
			)
		);
	}

	$wp_customize->add_setting( 'pdu_twitter_handle', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control(
		'pdu_twitter_handle',
		array(
			'label'       => __( 'X / Twitter handle', 'plague-dr-universe' ),
			'description' => __( 'Used for Twitter card attribution. Without the @.', 'plague-dr-universe' ),
			'section'     => 'pdu_social',
			'type'        => 'text',
		)
	);

	/* ---------------------------------------------------------------
	 * Contact
	 * ------------------------------------------------------------ */
	$wp_customize->add_section(
		'pdu_contact',
		array(
			'title' => __( 'Contact Details', 'plague-dr-universe' ),
			'panel' => 'pdu_panel',
		)
	);

	$contact_fields = array(
		'pdu_email'    => array( __( 'Contact email', 'plague-dr-universe' ), 'contact@theplaguedr.com', 'sanitize_email' ),
		'pdu_location' => array( __( 'Location', 'plague-dr-universe' ), __( 'Seattle, Washington', 'plague-dr-universe' ), 'sanitize_text_field' ),
		'pdu_press'    => array( __( 'Press / licensing email', 'plague-dr-universe' ), 'press@theplaguedr.com', 'sanitize_email' ),
	);

	foreach ( $contact_fields as $id => $cfg ) {
		$wp_customize->add_setting( $id, array( 'default' => $cfg[1], 'sanitize_callback' => $cfg[2] ) );
		$wp_customize->add_control( $id, array( 'label' => $cfg[0], 'section' => 'pdu_contact', 'type' => 'text' ) );
	}

	/* ---------------------------------------------------------------
	 * Sharing
	 * ------------------------------------------------------------ */
	$wp_customize->add_section(
		'pdu_sharing',
		array(
			'title' => __( 'Social Sharing Image', 'plague-dr-universe' ),
			'panel' => 'pdu_panel',
		)
	);
	$wp_customize->add_setting( 'pdu_share_image', array( 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'pdu_share_image',
			array(
				'label'       => __( 'Default share image', 'plague-dr-universe' ),
				'description' => __( 'Used for Open Graph and Twitter cards. 1200×630 recommended.', 'plague-dr-universe' ),
				'section'     => 'pdu_sharing',
			)
		)
	);
}
add_action( 'customize_register', 'pdu_customize_register' );

/**
 * Live-preview JS for the title/tagline.
 *
 * @return void
 */
function pdu_customize_preview_js() {
	$script = <<<'JS'
( function ( $ ) {
	wp.customize( 'blogname', function ( value ) {
		value.bind( function ( to ) {
			$( '.brand-mark span:last-child, .site-title' ).text( to );
		} );
	} );
	wp.customize( 'blogdescription', function ( value ) {
		value.bind( function ( to ) {
			$( '.site-description' ).text( to );
		} );
	} );
} )( jQuery );
JS;

	wp_add_inline_script( 'customize-preview', $script );
}
add_action( 'customize_preview_init', 'pdu_customize_preview_js' );
