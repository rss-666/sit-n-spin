<?php
/**
 * Enquiry + subscriber storage.
 *
 * Email is unreliable: shared hosts throttle wp_mail(), SPF/DKIM failures bounce
 * silently, and a mistyped notification address loses messages forever. Every
 * contact enquiry and newsletter signup is therefore ALSO written to a private
 * custom post type, so nothing a visitor sends can ever be lost.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the private stores for enquiries and subscribers.
 *
 * Neither is public: no archive, no single view, not queryable on the front end.
 *
 * @return void
 */
function pdu_register_enquiry_types() {
	$shared = array(
		'public'              => false,
		'publicly_queryable'  => false,
		'exclude_from_search' => true,
		'show_in_nav_menus'   => false,
		'show_ui'             => true,
		'show_in_menu'        => 'tools.php',
		'has_archive'         => false,
		'rewrite'             => false,
		'query_var'           => false,
		'capability_type'     => 'post',
		'map_meta_cap'        => true,
		'capabilities'        => array(
			'create_posts' => 'do_not_allow',
		),
		'supports'            => array( 'title', 'editor', 'custom-fields' ),
	);

	register_post_type(
		'pdu_enquiry',
		array_merge(
			$shared,
			array(
				'labels' => array(
					'name'               => __( 'Enquiries', 'plague-dr-universe' ),
					'singular_name'      => __( 'Enquiry', 'plague-dr-universe' ),
					'menu_name'          => __( 'Enquiries', 'plague-dr-universe' ),
					'search_items'       => __( 'Search enquiries', 'plague-dr-universe' ),
					'not_found'          => __( 'No enquiries yet.', 'plague-dr-universe' ),
					'not_found_in_trash' => __( 'No enquiries in the bin.', 'plague-dr-universe' ),
				),
				'menu_icon' => 'dashicons-email-alt',
			)
		)
	);

	register_post_type(
		'pdu_subscriber',
		array_merge(
			$shared,
			array(
				'labels' => array(
					'name'               => __( 'Subscribers', 'plague-dr-universe' ),
					'singular_name'      => __( 'Subscriber', 'plague-dr-universe' ),
					'menu_name'          => __( 'Subscribers', 'plague-dr-universe' ),
					'search_items'       => __( 'Search subscribers', 'plague-dr-universe' ),
					'not_found'          => __( 'No subscribers yet.', 'plague-dr-universe' ),
					'not_found_in_trash' => __( 'No subscribers in the bin.', 'plague-dr-universe' ),
				),
				'menu_icon' => 'dashicons-megaphone',
				'supports'  => array( 'title', 'custom-fields' ),
			)
		)
	);
}
add_action( 'init', 'pdu_register_enquiry_types' );

/**
 * Store a contact enquiry.
 *
 * @param array $data Keys: name, email, subject, message, mailed (bool).
 * @return int New post ID, or 0 on failure.
 */
function pdu_store_enquiry( $data ) {
	$post_id = wp_insert_post(
		array(
			'post_type'    => 'pdu_enquiry',
			'post_status'  => 'private',
			'post_title'   => sprintf(
				/* translators: 1: sender name, 2: subject line. */
				__( '%1$s — %2$s', 'plague-dr-universe' ),
				$data['name'],
				$data['subject'] ? $data['subject'] : __( 'Website enquiry', 'plague-dr-universe' )
			),
			'post_content' => $data['message'],
		),
		true
	);

	if ( is_wp_error( $post_id ) ) {
		return 0;
	}

	update_post_meta( $post_id, 'pdu_from_name', $data['name'] );
	update_post_meta( $post_id, 'pdu_from_email', $data['email'] );
	update_post_meta( $post_id, 'pdu_subject', $data['subject'] );
	update_post_meta( $post_id, 'pdu_mail_sent', ! empty( $data['mailed'] ) ? '1' : '0' );
	update_post_meta( $post_id, 'pdu_ip_hash', pdu_hash_ip() );

	return (int) $post_id;
}

/**
 * Store a newsletter subscriber, ignoring duplicates.
 *
 * @param string $email  Subscriber email.
 * @param bool   $mailed Whether the notification email went out.
 * @return int Post ID (existing or new), or 0 on failure.
 */
function pdu_store_subscriber( $email, $mailed = false ) {
	$existing = get_posts(
		array(
			'post_type'      => 'pdu_subscriber',
			'post_status'    => 'private',
			'title'          => $email,
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);

	if ( $existing ) {
		update_post_meta( $existing[0], 'pdu_last_seen', current_time( 'mysql' ) );
		return (int) $existing[0];
	}

	$post_id = wp_insert_post(
		array(
			'post_type'   => 'pdu_subscriber',
			'post_status' => 'private',
			'post_title'  => $email,
		),
		true
	);

	if ( is_wp_error( $post_id ) ) {
		return 0;
	}

	update_post_meta( $post_id, 'pdu_mail_sent', $mailed ? '1' : '0' );
	update_post_meta( $post_id, 'pdu_ip_hash', pdu_hash_ip() );

	return (int) $post_id;
}

/**
 * One-way hash of the requester IP, for abuse triage without storing the IP.
 *
 * @return string
 */
function pdu_hash_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return $ip ? substr( wp_hash( $ip ), 0, 12 ) : '';
}

/**
 * Simple per-IP throttle so the forms cannot be hammered.
 *
 * @param string $key Bucket name.
 * @param int    $max Allowed submissions per hour.
 * @return bool True when the caller is within the limit.
 */
function pdu_rate_ok( $key, $max = 8 ) {
	$hash = pdu_hash_ip();
	if ( ! $hash ) {
		return true;
	}

	$transient = 'pdu_rl_' . $key . '_' . $hash;
	$hits      = (int) get_transient( $transient );

	if ( $hits >= $max ) {
		return false;
	}

	set_transient( $transient, $hits + 1, HOUR_IN_SECONDS );
	return true;
}

/**
 * Show the sender details on the enquiry edit screen.
 *
 * @return void
 */
function pdu_enquiry_meta_box() {
	add_meta_box(
		'pdu-enquiry-details',
		__( 'Sender', 'plague-dr-universe' ),
		'pdu_render_enquiry_meta',
		array( 'pdu_enquiry', 'pdu_subscriber' ),
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'pdu_enquiry_meta_box' );

/**
 * Render the sender meta box.
 *
 * @param WP_Post $post Current post.
 * @return void
 */
function pdu_render_enquiry_meta( $post ) {
	$email  = get_post_meta( $post->ID, 'pdu_from_email', true );
	$email  = $email ? $email : $post->post_title;
	$name   = get_post_meta( $post->ID, 'pdu_from_name', true );
	$mailed = '1' === get_post_meta( $post->ID, 'pdu_mail_sent', true );

	echo '<p style="margin:0 0 .5em">';
	if ( $name ) {
		echo '<strong>' . esc_html( $name ) . '</strong><br>';
	}
	if ( is_email( $email ) ) {
		printf(
			'<a href="mailto:%1$s">%1$s</a>',
			esc_attr( $email )
		);
	}
	echo '</p>';

	printf(
		'<p style="margin:0"><span class="dashicons dashicons-%1$s" style="color:%2$s"></span> %3$s</p>',
		$mailed ? 'yes-alt' : 'warning',
		$mailed ? '#46b450' : '#dba617',
		$mailed
			? esc_html__( 'Notification email sent.', 'plague-dr-universe' )
			: esc_html__( 'Email failed — this record is the only copy.', 'plague-dr-universe' )
	);
}

/**
 * Useful columns on the enquiry/subscriber list tables.
 *
 * @param array $cols Existing columns.
 * @return array
 */
function pdu_enquiry_columns( $cols ) {
	$date = isset( $cols['date'] ) ? $cols['date'] : '';
	unset( $cols['date'] );

	$cols['pdu_email']  = __( 'Email', 'plague-dr-universe' );
	$cols['pdu_mailed'] = __( 'Notified', 'plague-dr-universe' );
	$cols['date']       = $date ? $date : __( 'Received', 'plague-dr-universe' );

	return $cols;
}
add_filter( 'manage_pdu_enquiry_posts_columns', 'pdu_enquiry_columns' );
add_filter( 'manage_pdu_subscriber_posts_columns', 'pdu_enquiry_columns' );

/**
 * Fill the custom columns.
 *
 * @param string $col     Column key.
 * @param int    $post_id Post ID.
 * @return void
 */
function pdu_enquiry_column_content( $col, $post_id ) {
	if ( 'pdu_email' === $col ) {
		$email = get_post_meta( $post_id, 'pdu_from_email', true );
		$email = $email ? $email : get_the_title( $post_id );
		echo is_email( $email )
			? '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>'
			: '—';
	}

	if ( 'pdu_mailed' === $col ) {
		echo '1' === get_post_meta( $post_id, 'pdu_mail_sent', true )
			? '<span style="color:#46b450">' . esc_html__( 'Sent', 'plague-dr-universe' ) . '</span>'
			: '<span style="color:#dba617">' . esc_html__( 'Stored only', 'plague-dr-universe' ) . '</span>';
	}
}
add_action( 'manage_pdu_enquiry_posts_custom_column', 'pdu_enquiry_column_content', 10, 2 );
add_action( 'manage_pdu_subscriber_posts_custom_column', 'pdu_enquiry_column_content', 10, 2 );

/**
 * Export subscribers as CSV from Tools → Subscribers.
 *
 * @return void
 */
function pdu_export_subscribers() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to export subscribers.', 'plague-dr-universe' ) );
	}

	check_admin_referer( 'pdu_export_subscribers' );

	$subs = get_posts(
		array(
			'post_type'      => 'pdu_subscriber',
			'post_status'    => 'private',
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'ASC',
		)
	);

	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=pdu-subscribers-' . gmdate( 'Y-m-d' ) . '.csv' );

	$out = fopen( 'php://output', 'w' );
	fputcsv( $out, array( 'email', 'subscribed_at' ) );

	foreach ( $subs as $sub ) {
		fputcsv( $out, array( $sub->post_title, $sub->post_date_gmt ) );
	}

	fclose( $out );
	exit;
}
add_action( 'admin_post_pdu_export_subscribers', 'pdu_export_subscribers' );

/**
 * Add the export button above the subscriber list.
 *
 * @param string $which Table position.
 * @return void
 */
function pdu_subscriber_export_button( $which ) {
	global $typenow;

	if ( 'pdu_subscriber' !== $typenow || 'top' !== $which || ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$url = wp_nonce_url(
		admin_url( 'admin-post.php?action=pdu_export_subscribers' ),
		'pdu_export_subscribers'
	);

	printf(
		'<a href="%1$s" class="button" style="margin:0 0 0 8px">%2$s</a>',
		esc_url( $url ),
		esc_html__( 'Export CSV', 'plague-dr-universe' )
	);
}
add_action( 'manage_posts_extra_tablenav', 'pdu_subscriber_export_button' );
