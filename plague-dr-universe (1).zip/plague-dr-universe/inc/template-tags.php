<?php
/**
 * Reusable presentational helpers.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Render an inline SVG icon from a small sprite map.
 *
 * Inline SVG avoids an extra HTTP request and inherits currentColor.
 *
 * @param string $name  Icon key.
 * @param int    $size  Pixel size.
 * @param string $class Extra CSS classes.
 * @return string Escaped-safe SVG markup.
 */
function pdu_icon( $name, $size = 20, $class = '' ) {
	$paths = array(
		'play'      => '<path d="M8 5.14v13.72a1 1 0 0 0 1.52.85l11.14-6.86a1 1 0 0 0 0-1.7L9.52 4.29A1 1 0 0 0 8 5.14Z"/>',
		'pause'     => '<path d="M7 4h4v16H7zM13 4h4v16h-4z"/>',
		'cart'      => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="M3 4h2l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.55L21 8H6"/><circle cx="10" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/>',
		'search'    => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" d="m21 21-4.3-4.3M11 18a7 7 0 1 1 0-14 7 7 0 0 1 0 14Z"/>',
		'menu'      => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" d="M4 7h16M4 12h16M4 17h16"/>',
		'close'     => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" d="M6 6l12 12M18 6L6 18"/>',
		'arrow'     => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="M5 12h14m-6-6 6 6-6 6"/>',
		'user'      => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" d="M20 21a8 8 0 1 0-16 0"/><circle cx="12" cy="8" r="4" fill="none" stroke="currentColor" stroke-width="1.8"/>',
		'mail'      => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="M3 6h18v12H3z"/><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="m3 7 9 6 9-6"/>',
		'book'      => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" d="M4 4h6a3 3 0 0 1 3 3v13a2.5 2.5 0 0 0-2.5-2.5H4Zm16 0h-6a3 3 0 0 0-3 3v13a2.5 2.5 0 0 1 2.5-2.5H20Z"/>',
		'disc'      => '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="2.4" fill="none" stroke="currentColor" stroke-width="1.8"/>',
		'video'     => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" d="M3 6h12v12H3z"/><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" d="m15 10 6-3.5v11L15 14Z"/>',
		'palette'   => '<path fill="none" stroke="currentColor" stroke-width="1.8" d="M12 3a9 9 0 1 0 0 18 2 2 0 0 0 1.7-3 2 2 0 0 1 1.7-3H18a3 3 0 0 0 3-3 9 9 0 0 0-9-9Z"/><circle cx="7.5" cy="11.5" r="1.2"/><circle cx="12" cy="7.5" r="1.2"/><circle cx="16.5" cy="10.5" r="1.2"/>',
		'shirt'     => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" d="M9 3 4 5.5 6 10l2-.8V21h8V9.2l2 .8 2-4.5L15 3a3 3 0 0 1-6 0Z"/>',
		'instagram' => '<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="17.2" cy="6.8" r="1.2"/>',
		'youtube'   => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" d="M22 12s0-3.3-.4-4.9a2.6 2.6 0 0 0-1.8-1.8C18.2 4.9 12 4.9 12 4.9s-6.2 0-7.8.4a2.6 2.6 0 0 0-1.8 1.8C2 8.7 2 12 2 12s0 3.3.4 4.9a2.6 2.6 0 0 0 1.8 1.8c1.6.4 7.8.4 7.8.4s6.2 0 7.8-.4a2.6 2.6 0 0 0 1.8-1.8C22 15.3 22 12 22 12Z"/><path d="M10.2 15.1V8.9l5.2 3.1Z"/>',
		'bandcamp'  => '<path d="M2.5 18.5 9 5.5h12.5l-6.5 13Z"/>',
		'spotify'   => '<circle cx="12" cy="12" r="9.2" fill="none" stroke="currentColor" stroke-width="1.7"/><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" d="M7.4 9.4c3-.8 6.4-.5 9 1M8 12.5c2.4-.7 5.1-.4 7.3.9M8.6 15.5c1.9-.5 4-.3 5.8.7"/>',
		'x'         => '<path d="M3 3h4.3l4.6 6.3L17.4 3H21l-7 8.1L21.4 21H17l-4.9-6.7L6.3 21H3l7.4-8.6Z"/>',
		'tiktok'    => '<path d="M14 3h2.6a5.6 5.6 0 0 0 4.4 4.5v2.7a8.3 8.3 0 0 1-4.4-1.5v6.1A6.2 6.2 0 1 1 10.4 8.6v2.8a3.4 3.4 0 1 0 2.4 3.3Z"/>',
		'shield'    => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" d="M12 3 5 6v6c0 4.2 2.9 7.9 7 9 4.1-1.1 7-4.8 7-9V6Z"/><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="m9 12 2 2 4-4"/>',
		'truck'     => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" d="M3 6h11v10H3zM14 9h4l3 3v4h-7z"/><circle cx="7" cy="18" r="1.6"/><circle cx="17.5" cy="18" r="1.6"/>',
		'download'  => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="M12 3v12m0 0 4-4m-4 4-4-4M4 19h16"/>',
		'skull'     => '<path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" d="M12 2.6c-4.7 0-8 3.3-8 7.7 0 2.7 1.2 4.3 2.6 5.3.5.4.8 1 .8 1.6v1.4c0 1.5 1.2 2.7 2.7 2.7h3.8c1.5 0 2.7-1.2 2.7-2.7v-1.4c0-.6.3-1.2.8-1.6 1.4-1 2.6-2.6 2.6-5.3 0-4.4-3.3-7.7-8-7.7Z"/><circle cx="8.9" cy="11" r="1.9"/><circle cx="15.1" cy="11" r="1.9"/>',
		'clock'     => '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.8"/><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" d="M12 7v5.2l3.4 2"/>',
		'pin'       => '<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" d="M12 21s7-5.8 7-11a7 7 0 1 0-14 0c0 5.2 7 11 7 11Z"/><circle cx="12" cy="10" r="2.6" fill="none" stroke="currentColor" stroke-width="1.8"/>',
	);

	$key = array_key_exists( $name, $paths ) ? $name : 'arrow';

	return sprintf(
		'<svg class="pdu-icon %1$s" width="%2$d" height="%2$d" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false">%3$s</svg>',
		esc_attr( $class ),
		(int) $size,
		$paths[ $key ] // Static, developer-controlled markup.
	);
}

/**
 * Echo an icon.
 *
 * @param string $name  Icon key.
 * @param int    $size  Size.
 * @param string $class Classes.
 * @return void
 */
function pdu_the_icon( $name, $size = 20, $class = '' ) {
	echo pdu_icon( $name, $size, $class ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted static SVG.
}

/**
 * Section heading block with eyebrow, title and optional lede + CTA.
 *
 * @param array $args {
 *     @type string $eyebrow  Small label above the title.
 *     @type string $title    Section title.
 *     @type string $lede     Supporting paragraph.
 *     @type string $cta_url  Optional CTA link.
 *     @type string $cta_text Optional CTA label.
 *     @type string $align    'left' or 'center'.
 *     @type string $id       Optional id for aria-labelledby.
 * }
 * @return void
 */
function pdu_section_heading( $args = array() ) {
	$a = wp_parse_args(
		$args,
		array(
			'eyebrow'  => '',
			'title'    => '',
			'lede'     => '',
			'cta_url'  => '',
			'cta_text' => '',
			'align'    => 'left',
			'id'       => '',
		)
	);

	$center = ( 'center' === $a['align'] );
	?>
	<div class="mb-12 flex flex-col gap-6 md:flex-row md:items-end md:justify-between <?php echo $center ? 'md:flex-col md:items-center text-center' : ''; ?>">
		<div class="<?php echo $center ? 'mx-auto max-w-3xl' : 'max-w-2xl'; ?>">
			<?php if ( $a['eyebrow'] ) : ?>
				<p class="eyebrow <?php echo $center ? 'justify-center' : ''; ?>"><?php echo esc_html( $a['eyebrow'] ); ?></p>
			<?php endif; ?>

			<?php if ( $a['title'] ) : ?>
				<h2 class="section-title" <?php echo $a['id'] ? 'id="' . esc_attr( $a['id'] ) . '"' : ''; ?>>
					<?php echo wp_kses_post( $a['title'] ); ?>
				</h2>
			<?php endif; ?>

			<?php if ( $a['lede'] ) : ?>
				<p class="lede mt-5 <?php echo $center ? 'mx-auto' : ''; ?>"><?php echo wp_kses_post( $a['lede'] ); ?></p>
			<?php endif; ?>
		</div>

		<?php if ( $a['cta_url'] && $a['cta_text'] ) : ?>
			<a class="btn btn-ghost shrink-0" href="<?php echo esc_url( $a['cta_url'] ); ?>">
				<?php echo esc_html( $a['cta_text'] ); ?>
				<?php pdu_the_icon( 'arrow', 16 ); ?>
			</a>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Post meta line (date + categories + reading time).
 *
 * @return void
 */
function pdu_entry_meta() {
	$minutes = pdu_reading_time( get_the_content() );
	?>
	<div class="meta flex flex-wrap items-center gap-x-4 gap-y-2">
		<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>">
			<?php echo esc_html( get_the_date() ); ?>
		</time>
		<span aria-hidden="true">&middot;</span>
		<span>
			<?php
			/* translators: %d: estimated reading time in minutes. */
			printf( esc_html__( '%d min read', 'plague-dr-universe' ), (int) $minutes );
			?>
		</span>
		<?php
		$cats = get_the_category_list( ', ' );
		if ( $cats ) :
			?>
			<span aria-hidden="true">&middot;</span>
			<span class="[&_a]:text-amber-400 [&_a]:no-underline"><?php echo wp_kses_post( $cats ); ?></span>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Estimate reading time in minutes.
 *
 * @param string $content Raw content.
 * @return int
 */
function pdu_reading_time( $content ) {
	$words = str_word_count( wp_strip_all_tags( (string) $content ) );
	return max( 1, (int) ceil( $words / 220 ) );
}

/**
 * Output a responsive featured image with a graceful fallback.
 *
 * @param int    $post_id Post ID.
 * @param string $size    Image size.
 * @param array  $attr    Extra attributes.
 * @return void
 */
function pdu_featured_image( $post_id = 0, $size = 'pdu-card', $attr = array() ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$attr    = wp_parse_args(
		$attr,
		array(
			'loading'  => 'lazy',
			'decoding' => 'async',
			'alt'      => the_title_attribute( array( 'echo' => false, 'post' => $post_id ) ),
		)
	);

	if ( has_post_thumbnail( $post_id ) ) {
		echo get_the_post_thumbnail( $post_id, $size, $attr );
		return;
	}

	// Deterministic fallback from the bundled art so grids never look broken.
	$fallbacks = pdu_fallback_images();
	$img       = $fallbacks[ $post_id % count( $fallbacks ) ];
	printf(
		'<img src="%1$s" alt="" loading="lazy" decoding="async" width="1200" height="900">',
		esc_url( PDU_URI . 'assets/images/' . $img )
	);
}

/**
 * Bundled fallback artwork filenames.
 *
 * @return string[]
 */
function pdu_fallback_images() {
	return array(
		'plague-doctor-first-ave.jpg',
		'space-needle-rain.jpg',
		'great-wheel-rain.jpg',
		'rain-street-noir.jpg',
		'space-needle-square.jpg',
		'storyboard-contact-sheet.jpg',
	);
}

/**
 * Convenience: full URL to a bundled theme image.
 *
 * @param string $file Filename inside assets/images.
 * @return string
 */
function pdu_img( $file ) {
	return PDU_URI . 'assets/images/' . ltrim( $file, '/' );
}

/**
 * Render an accessible, keyboard-operable audio track row.
 *
 * @param array $track {
 *     @type string $title  Track title.
 *     @type string $album  Album / release name.
 *     @type string $length Human duration, e.g. "4:12".
 *     @type string $src    Audio file URL (optional — falls back to a silent demo tone).
 *     @type string $tag    Genre tag.
 *     @type int    $index  Row index.
 * }
 * @return void
 */
function pdu_audio_track( $track ) {
	$t = wp_parse_args(
		$track,
		array(
			'title'  => '',
			'album'  => '',
			'length' => '',
			'src'    => '',
			'tag'    => '',
			'index'  => 0,
		)
	);

	$uid = 'trk-' . sanitize_title( $t['title'] ) . '-' . (int) $t['index'];
	?>
	<li class="track" data-pdu-track data-src="<?php echo esc_url( $t['src'] ); ?>">
		<button type="button"
				class="track-btn"
				data-pdu-play
				aria-pressed="false"
				aria-describedby="<?php echo esc_attr( $uid ); ?>-title">
			<span class="pdu-ico-play"><?php pdu_the_icon( 'play', 16 ); ?></span>
			<span class="pdu-ico-pause hidden"><?php pdu_the_icon( 'pause', 16 ); ?></span>
			<span class="screen-reader-text" data-pdu-btn-label>
				<?php
				/* translators: %s: track title. */
				printf( esc_html__( 'Play %s', 'plague-dr-universe' ), esc_html( $t['title'] ) );
				?>
			</span>
		</button>

		<div class="min-w-0 flex-1">
			<p id="<?php echo esc_attr( $uid ); ?>-title" class="truncate font-display text-base uppercase tracking-wide text-bone-50">
				<?php echo esc_html( $t['title'] ); ?>
			</p>
			<p class="meta mt-1 truncate">
				<?php echo esc_html( $t['album'] ); ?>
				<?php if ( $t['tag'] ) : ?>
					<span aria-hidden="true"> &middot; </span><span class="text-amber-400"><?php echo esc_html( $t['tag'] ); ?></span>
				<?php endif; ?>
			</p>
			<div class="mt-3 flex items-center gap-3">
				<input type="range"
						class="scrub"
						min="0" max="100" value="0" step="0.1"
						data-pdu-scrub
						aria-label="<?php echo esc_attr( sprintf( /* translators: %s: track title. */ __( 'Seek within %s', 'plague-dr-universe' ), $t['title'] ) ); ?>">
				<span class="meta shrink-0 tabular-nums" data-pdu-time><?php echo esc_html( $t['length'] ); ?></span>
			</div>
		</div>

		<div class="eq shrink-0 opacity-0 transition-opacity" data-pdu-eq aria-hidden="true">
			<span></span><span></span><span></span><span></span>
		</div>
	</li>
	<?php
}

/**
 * Breadcrumb trail with schema.org BreadcrumbList markup.
 *
 * @return void
 */
function pdu_breadcrumbs() {
	if ( is_front_page() ) {
		return;
	}

	$items = array( array( 'name' => __( 'Home', 'plague-dr-universe' ), 'url' => home_url( '/' ) ) );

	if ( is_singular( 'post' ) ) {
		$items[] = array(
			'name' => __( 'Dispatches', 'plague-dr-universe' ),
			'url'  => get_permalink( get_option( 'page_for_posts' ) ),
		);
		$items[] = array( 'name' => get_the_title(), 'url' => '' );
	} elseif ( is_singular() ) {
		$pt  = get_post_type_object( get_post_type() );
		$obj = get_queried_object();
		if ( $pt && ! empty( $pt->has_archive ) ) {
			$items[] = array( 'name' => $pt->labels->name, 'url' => get_post_type_archive_link( get_post_type() ) );
		}
		if ( $obj && ! empty( $obj->post_parent ) ) {
			$items[] = array( 'name' => get_the_title( $obj->post_parent ), 'url' => get_permalink( $obj->post_parent ) );
		}
		$items[] = array( 'name' => get_the_title(), 'url' => '' );
	} elseif ( is_post_type_archive() ) {
		$items[] = array( 'name' => post_type_archive_title( '', false ), 'url' => '' );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$items[] = array( 'name' => single_term_title( '', false ), 'url' => '' );
	} elseif ( is_search() ) {
		$items[] = array( 'name' => __( 'Search results', 'plague-dr-universe' ), 'url' => '' );
	} elseif ( is_404() ) {
		$items[] = array( 'name' => __( 'Not found', 'plague-dr-universe' ), 'url' => '' );
	} elseif ( is_archive() ) {
		$items[] = array( 'name' => get_the_archive_title(), 'url' => '' );
	}

	echo '<nav class="woocommerce-breadcrumb" aria-label="' . esc_attr__( 'Breadcrumb', 'plague-dr-universe' ) . '"><ol class="flex flex-wrap items-center gap-2 list-none p-0 m-0">';
	$last = count( $items ) - 1;
	foreach ( $items as $i => $item ) {
		echo '<li class="flex items-center gap-2">';
		if ( $item['url'] && $i !== $last ) {
			printf( '<a href="%s">%s</a>', esc_url( $item['url'] ), esc_html( $item['name'] ) );
			echo '<span aria-hidden="true" class="text-ink-300">/</span>';
		} else {
			printf( '<span aria-current="page" class="text-bone-200">%s</span>', esc_html( wp_strip_all_tags( $item['name'] ) ) );
		}
		echo '</li>';
	}
	echo '</ol></nav>';
}

/**
 * Newsletter signup form. Posts to admin-post.php and degrades without JS.
 *
 * @param string $variant 'block' (boxed) or 'inline'.
 * @return void
 */
function pdu_newsletter_form( $variant = 'block' ) {
	$inline = ( 'inline' === $variant );
	?>
	<form class="<?php echo $inline ? 'flex flex-col gap-3 sm:flex-row' : 'space-y-4'; ?>"
			action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
			method="post">
		<input type="hidden" name="action" value="pdu_newsletter">
		<?php wp_nonce_field( 'pdu_newsletter', 'pdu_newsletter_nonce' ); ?>

		<p class="sr-only-wrap m-0 <?php echo $inline ? 'flex-1' : ''; ?>">
			<label class="screen-reader-text" for="pdu-news-email-<?php echo esc_attr( $variant ); ?>">
				<?php esc_html_e( 'Your email address', 'plague-dr-universe' ); ?>
			</label>
			<input type="email"
					id="pdu-news-email-<?php echo esc_attr( $variant ); ?>"
					name="pdu_email"
					required
					autocomplete="email"
					placeholder="<?php esc_attr_e( 'you@example.com', 'plague-dr-universe' ); ?>">
		</p>

		<?php // Honeypot — hidden from humans and assistive tech. ?>
		<p class="hidden" aria-hidden="true">
			<label for="pdu-hp-<?php echo esc_attr( $variant ); ?>"><?php esc_html_e( 'Leave this field empty', 'plague-dr-universe' ); ?></label>
			<input type="text" id="pdu-hp-<?php echo esc_attr( $variant ); ?>" name="pdu_hp" tabindex="-1" autocomplete="off">
		</p>

		<button type="submit" class="btn btn-primary <?php echo $inline ? '' : 'btn-block'; ?>">
			<?php esc_html_e( 'Join the Dispatch', 'plague-dr-universe' ); ?>
			<?php pdu_the_icon( 'arrow', 16 ); ?>
		</button>

		<?php if ( ! $inline ) : ?>
			<p class="text-xs leading-relaxed text-bone-400">
				<?php esc_html_e( 'Release drops, chapter releases and studio dispatches. No resale of your data, unsubscribe in one click.', 'plague-dr-universe' ); ?>
			</p>
		<?php endif; ?>
	</form>
	<?php
}

/**
 * Social links row, driven by Customizer settings.
 *
 * @return void
 */
function pdu_social_links() {
	$networks = array(
		'instagram' => __( 'Instagram', 'plague-dr-universe' ),
		'youtube'   => __( 'YouTube', 'plague-dr-universe' ),
		'bandcamp'  => __( 'Bandcamp', 'plague-dr-universe' ),
		'spotify'   => __( 'Spotify', 'plague-dr-universe' ),
		'tiktok'    => __( 'TikTok', 'plague-dr-universe' ),
		'x'         => __( 'X', 'plague-dr-universe' ),
	);

	$out = '';
	foreach ( $networks as $key => $label ) {
		$url = get_theme_mod( 'pdu_social_' . $key, '' );
		if ( ! $url ) {
			continue;
		}
		$out .= sprintf(
			'<li><a class="social-btn" href="%1$s" rel="me noopener noreferrer" target="_blank"><span class="screen-reader-text">%2$s</span>%3$s</a></li>',
			esc_url( $url ),
			esc_html( sprintf( /* translators: %s: social network name. */ __( '%s (opens in a new tab)', 'plague-dr-universe' ), $label ) ),
			pdu_icon( $key, 18 )
		);
	}

	if ( ! $out ) {
		return;
	}

	printf(
		'<ul class="flex flex-wrap items-center gap-3 list-none p-0 m-0" aria-label="%s">%s</ul>',
		esc_attr__( 'Social media', 'plague-dr-universe' ),
		$out // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
	);
}
