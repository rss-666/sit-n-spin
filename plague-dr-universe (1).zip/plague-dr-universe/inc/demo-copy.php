<?php
/**
 * Fully drafted legal and compliance copy.
 *
 * IMPORTANT: this is a thorough, production-shaped starting point written for
 * an independent art/music/merch store. It is not legal advice. Have a
 * qualified lawyer review it against your jurisdiction before launch, and
 * replace every [BRACKETED] placeholder.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Privacy Policy copy.
 *
 * @return string
 */
function pdu_copy_privacy() {
	$updated = date_i18n( get_option( 'date_format' ) );

	return '
<h2>Privacy Policy</h2>
<p><em>Last updated: ' . esc_html( $updated ) . '</em></p>

<p>This policy explains what personal information The Plague Dr Universe ("we", "us", "the studio") collects when you visit this website or buy from our store, why we collect it, how long we keep it, and the rights you have over it. We are an independent studio, not an advertising company. We do not sell your data — to anyone, ever.</p>

<h3>1. Who we are</h3>
<p>The data controller for this website is The Plague Dr Universe, operating from Seattle, Washington, United States. For any privacy question or request, contact us at <strong>[privacy@yourdomain.com]</strong>.</p>

<h3>2. What we collect</h3>
<h4>Information you give us</h4>
<ul>
<li><strong>Order information</strong> — name, billing address, shipping address, email address, telephone number (only when a courier requires it), and the contents of your order.</li>
<li><strong>Account information</strong> — if you create an account: your username, email address, hashed password, and your saved addresses and order history.</li>
<li><strong>Newsletter signup</strong> — your email address, and the date and time you subscribed.</li>
<li><strong>Correspondence</strong> — anything you send us through the contact form, including your name, email address and message.</li>
<li><strong>Comments and reviews</strong> — your display name, the content you post, and the email address attached to it.</li>
</ul>

<h4>Information collected automatically</h4>
<ul>
<li><strong>Technical data</strong> — IP address, browser type and version, device type, operating system, and the pages you viewed. This is used for security, fraud prevention and aggregate analytics.</li>
<li><strong>Cookies</strong> — see section 6.</li>
</ul>

<h4>Payment information</h4>
<p><strong>We never see or store your full card details.</strong> Payments are processed directly by our payment providers (for example Stripe and PayPal), who are independently PCI-DSS compliant. We receive only a transaction reference, the payment status, and the last four digits and card brand for support purposes.</p>

<h3>3. Why we use it, and our lawful basis</h3>
<table>
<thead><tr><th>Purpose</th><th>Data used</th><th>Lawful basis</th></tr></thead>
<tbody>
<tr><td>Processing and delivering your order</td><td>Order and account data</td><td>Performance of a contract</td></tr>
<tr><td>Order confirmations and shipping updates</td><td>Email, order data</td><td>Performance of a contract</td></tr>
<tr><td>Customer support</td><td>Correspondence, order data</td><td>Performance of a contract / legitimate interests</td></tr>
<tr><td>Newsletter and release announcements</td><td>Email address</td><td>Consent (opt-in)</td></tr>
<tr><td>Fraud prevention and site security</td><td>Technical data</td><td>Legitimate interests</td></tr>
<tr><td>Tax, accounting and legal records</td><td>Order and billing data</td><td>Legal obligation</td></tr>
<tr><td>Improving the site</td><td>Aggregate, non-identifying analytics</td><td>Legitimate interests</td></tr>
</tbody>
</table>

<h3>4. Who we share it with</h3>
<p>We share the minimum necessary data with the following categories of processor, each bound by contract to protect it:</p>
<ul>
<li><strong>Payment processors</strong> — to take payment and handle refunds and chargebacks.</li>
<li><strong>Shipping carriers and fulfilment partners</strong> — name and delivery address only, so your order can physically arrive.</li>
<li><strong>Email service provider</strong> — to send order notifications and, if you opted in, the newsletter.</li>
<li><strong>Web host and security services</strong> — who necessarily process server logs.</li>
<li><strong>Our accountant and, where legally required, tax authorities.</strong></li>
</ul>
<p>We will also disclose information if compelled by valid legal process. We do not sell, rent or trade personal information, and we do not share it with advertising networks or data brokers.</p>

<h3>5. International transfers</h3>
<p>We operate from the United States. If you order from the EEA, the UK or Switzerland, your information will be transferred to and processed in the US. Where we use processors outside your region, those transfers are covered by Standard Contractual Clauses or an equivalent approved safeguard.</p>

<h3>6. Cookies</h3>
<p>We keep cookies to a minimum and use no third-party advertising or cross-site tracking cookies.</p>
<ul>
<li><strong>Strictly necessary</strong> — session, cart contents, checkout state, login, and security tokens. These cannot be switched off without breaking the store.</li>
<li><strong>Functional</strong> — remembering your preferences, such as dismissing the announcement bar.</li>
<li><strong>Analytics</strong> — if enabled, only in aggregate and privacy-respecting form.</li>
</ul>
<p>Our web fonts are self-hosted, so loading a page here does not tell any font provider that you visited. You can block or delete cookies in your browser settings; strictly necessary cookies are required for checkout to function.</p>

<h3>7. How long we keep it</h3>
<ul>
<li><strong>Order and invoice records</strong> — seven years, to satisfy tax and accounting law.</li>
<li><strong>Account data</strong> — until you ask us to delete the account.</li>
<li><strong>Newsletter subscription</strong> — until you unsubscribe, plus a short suppression record so we do not accidentally re-add you.</li>
<li><strong>Contact form messages</strong> — up to twenty-four months.</li>
<li><strong>Server and security logs</strong> — up to twelve months.</li>
</ul>

<h3>8. Your rights</h3>
<p>Depending on where you live, you have some or all of the following rights: to <strong>access</strong> a copy of your data; to <strong>correct</strong> inaccurate data; to <strong>delete</strong> your data; to <strong>restrict</strong> or <strong>object to</strong> processing; to <strong>data portability</strong>; and to <strong>withdraw consent</strong> at any time. Under the CCPA/CPRA, California residents additionally have the right to know what is collected, the right to delete, the right to correct, and the right to opt out of "sale" or "sharing" — noting that we do neither.</p>
<p>To exercise any right, email <strong>[privacy@yourdomain.com]</strong>. We will respond within thirty days. We will never discriminate against you for exercising these rights. If you are unhappy with our response, you may complain to your local data protection authority.</p>

<h3>9. Security</h3>
<p>The entire site is served over TLS. Passwords are salted and hashed, never stored in plain text. Administrative access is limited, uses strong authentication, and is reviewed regularly. No system is perfectly secure, but if a breach ever affects your rights we will notify you and the relevant regulator without undue delay.</p>

<h3>10. Children</h3>
<p>This site is not directed at children under 16, and we do not knowingly collect their personal information. If you believe a child has given us data, contact us and we will delete it.</p>

<h3>11. Changes to this policy</h3>
<p>If we change this policy materially we will update the date at the top and, where the change affects you meaningfully, tell subscribers by email.</p>

<h3>12. Contact</h3>
<p>Privacy enquiries: <strong>[privacy@yourdomain.com]</strong><br>General enquiries: <strong>[contact@yourdomain.com]</strong><br>Postal: <strong>[Studio postal address]</strong></p>
';
}

/**
 * Terms & Conditions copy, including digital/physical licensing.
 *
 * @return string
 */
function pdu_copy_terms() {
	$updated = date_i18n( get_option( 'date_format' ) );

	return '
<h2>Terms &amp; Conditions</h2>
<p><em>Last updated: ' . esc_html( $updated ) . '</em></p>

<p>These terms govern your use of this website and any purchase you make from it. By browsing the site or placing an order you accept them. Please read section 5 carefully — it sets out exactly what you may and may not do with our artwork, music and story.</p>

<h3>1. Definitions</h3>
<ul>
<li><strong>"We", "us", "the studio"</strong> — The Plague Dr Universe.</li>
<li><strong>"Content"</strong> — all artwork, illustrations, panels, characters, story text, music, lyrics, video, photography, logos and design on this site.</li>
<li><strong>"Digital Goods"</strong> — downloadable files: digital comics, wallpapers, audio files and video downloads.</li>
<li><strong>"Physical Goods"</strong> — printed volumes, prints, records, apparel and other tangible items.</li>
</ul>

<h3>2. Using this website</h3>
<p>You may browse, read and share links freely. You may not: attempt to breach or probe the site\'s security; scrape, mirror or bulk-download the site; use automated systems to place orders; upload malicious code; or use the site for anything unlawful. We may suspend access to anyone who does.</p>

<h3>3. Accounts</h3>
<p>You are responsible for keeping your password confidential and for all activity under your account. Tell us immediately if you suspect unauthorised use. You must give accurate information; we may cancel orders placed with false details. You can close your account at any time by contacting us.</p>

<h3>4. Orders, prices and payment</h3>
<ul>
<li>All prices are listed in <strong>[USD]</strong> and exclude shipping unless stated. Taxes and duties are explained in section 8.</li>
<li>Placing an order is an offer to buy. A contract forms only when we send a dispatch confirmation (physical) or a download link (digital).</li>
<li>We may refuse or cancel an order — for example if an item is out of stock, a price was listed in obvious error, or we suspect fraud. If we cancel after payment, you receive a full refund.</li>
<li>Original artwork is one-of-one. Where two people order the same original, the first completed payment takes it and the other is refunded in full.</li>
<li>Limited editions are strictly limited to the stated run size. Edition numbers are assigned in order of purchase.</li>
</ul>

<h3>5. Intellectual property and licensing</h3>
<p>All Content is original work and remains the exclusive property of The Plague Dr Universe, protected by copyright and, where applicable, trade mark law. Buying a product transfers <strong>ownership of that copy or object only</strong> — never the copyright.</p>

<h4>5.1 Digital Goods — personal licence</h4>
<p>When you buy a Digital Good you receive a <strong>non-exclusive, non-transferable, worldwide, perpetual licence for personal, non-commercial use</strong>. You may:</p>
<ul>
<li>Download, read, listen to and view the file on devices you own.</li>
<li>Keep a reasonable number of personal backup copies.</li>
<li>Print a single copy of a digital comic or wallpaper for your own use.</li>
</ul>
<p>You may <strong>not</strong>:</p>
<ul>
<li>Redistribute, upload, share, resell, sub-license or torrent the file.</li>
<li>Use it in any commercial product, advertisement, service or client work.</li>
<li>Use it as an NFT, blockchain asset, or in any minting or tokenisation scheme.</li>
<li>Use it to train, fine-tune or condition any machine-learning or generative AI model or dataset.</li>
<li>Remove watermarks, credits or metadata, or claim the work as your own.</li>
<li>Create and distribute derivative works, edits or remixes without written permission.</li>
</ul>

<h4>5.2 Music — listening and sync</h4>
<p>Purchasing audio grants a personal listening licence only. It does <strong>not</strong> grant synchronisation rights. Any use of our music in video, film, game, podcast, livestream monetised content, advertisement or public performance requires a separate written sync or performance licence. Enquire at <strong>[licensing@yourdomain.com]</strong> — we are independent and generally reasonable.</p>

<h4>5.3 Physical Goods — prints and originals</h4>
<p>Buying a print or original transfers the physical object. You may display it privately, resell that single physical copy, and gift or bequeath it. You may not reproduce it, photograph it for commercial reproduction, or use the imagery on products. Publicly exhibiting an original for commercial purposes requires our written consent, which we usually give with credit.</p>

<h4>5.4 Fan work</h4>
<p>We actively welcome non-commercial fan art, covers, cosplay and analysis, provided you credit The Plague Dr Universe, do not present it as official, and do not sell it. Selling fan work commercially requires written permission.</p>

<h4>5.5 Reservation</h4>
<p>Any right not expressly granted here is reserved. Licences terminate automatically on material breach.</p>

<h3>6. User-submitted content</h3>
<p>By posting a comment, review or submission you confirm it is yours to post and grant us a non-exclusive, royalty-free licence to display and moderate it on the site. We may remove anything abusive, defamatory, infringing, spam or off-topic, at our discretion.</p>

<h3>7. Digital delivery and availability</h3>
<p>Download links are issued immediately after payment clears and remain valid for <strong>[30] days</strong>, with a reasonable download limit to prevent abuse. If a link expires or fails, contact us and we will reissue it free of charge. You are responsible for having software capable of opening standard PDF, CBZ, MP3, FLAC and MP4 files.</p>

<h3>8. Taxes and customs</h3>
<p>Sales tax is added where legally required. For international orders, <strong>import duties, VAT and customs handling fees are the responsibility of the recipient</strong> and are not included in our prices. We are required to declare the accurate value of shipments and cannot mark orders as gifts.</p>

<h3>9. Returns</h3>
<p>Returns, cancellations and refunds are governed by our <a href="/shipping-refunds/">Shipping &amp; Refund Policy</a>, which forms part of these terms.</p>

<h3>10. Disclaimers</h3>
<p>The site is provided "as is". We do not warrant that it will be uninterrupted or error-free. Colours shown on screen are indicative — printed and dyed goods vary slightly between batches and between monitors, and such variation is not a defect. Our story content is fiction; any resemblance to real persons or events is coincidental or used fictitiously.</p>

<h3>11. Limitation of liability</h3>
<p>To the fullest extent permitted by law, our total liability arising from any order is limited to the amount you paid for that order. We are not liable for indirect or consequential losses, including lost profits or data. <strong>Nothing in these terms limits liability for death or personal injury caused by negligence, for fraud, or for any statutory consumer rights that cannot lawfully be excluded.</strong></p>

<h3>12. Consumer rights</h3>
<p>If you are a consumer, you keep all mandatory rights under the law of your country of residence, including any statutory cooling-off period for distance selling. These terms do not affect those rights.</p>

<h3>13. Changes</h3>
<p>We may update these terms. The version in force at the time you order is the one that applies to that order.</p>

<h3>14. Governing law</h3>
<p>These terms are governed by the laws of the <strong>[State of Washington, United States]</strong>, and the courts there have non-exclusive jurisdiction. Consumers may also bring proceedings in their country of residence.</p>

<h3>15. Contact</h3>
<p>General: <strong>[contact@yourdomain.com]</strong><br>Licensing and press: <strong>[licensing@yourdomain.com]</strong></p>
';
}

/**
 * Shipping & Refund Policy copy.
 *
 * @return string
 */
function pdu_copy_shipping() {
	$updated = date_i18n( get_option( 'date_format' ) );

	return '
<h2>Shipping &amp; Refund Policy</h2>
<p><em>Last updated: ' . esc_html( $updated ) . '</em></p>

<p>Everything is packed by hand in the studio. Here is exactly what to expect, what it costs, and what happens when something goes wrong.</p>

<h3>1. Processing time</h3>
<p>Orders are packed and dispatched within <strong>1–3 business days</strong>. Original artwork and made-to-order apparel take <strong>5–10 business days</strong>, because they are prepared individually. Pre-orders ship on the date shown on the product page. During a major release, add a couple of days — we will always say so on the store banner.</p>

<h3>2. Shipping options and cost</h3>
<table>
<thead><tr><th>Destination</th><th>Service</th><th>Estimated transit</th><th>Cost</th></tr></thead>
<tbody>
<tr><td>United States</td><td>Standard tracked</td><td>3–7 business days</td><td>[$5.95]</td></tr>
<tr><td>United States</td><td>Priority tracked</td><td>2–3 business days</td><td>[$12.95]</td></tr>
<tr><td>Canada</td><td>International tracked</td><td>7–14 business days</td><td>[$14.95]</td></tr>
<tr><td>Europe &amp; UK</td><td>International tracked</td><td>10–21 business days</td><td>[$19.95]</td></tr>
<tr><td>Rest of world</td><td>International tracked</td><td>14–28 business days</td><td>[$24.95]</td></tr>
<tr><td>Any destination</td><td>Order over [$75]</td><td>—</td><td><strong>Free standard shipping</strong></td></tr>
</tbody>
</table>
<p>Transit times are carrier estimates from the date of dispatch, not from the date of order, and exclude customs delays. Exact cost is always calculated and shown at checkout before you pay.</p>

<h3>3. Digital orders</h3>
<p>Digital Goods have no shipping cost and are delivered instantly. Your download link appears on the order confirmation screen and is emailed to you the moment payment clears. If the email does not arrive, check your spam folder, then check <em>My Account → Downloads</em>, then email us — we will reissue it.</p>

<h3>4. Packaging</h3>
<p>Prints ship flat in rigid board mailers up to A3, and in heavy-duty tubes above that. Records ship in proper LP mailers with the sleeve outside the jacket to prevent seam splits. Books are bagged and boarded. Packaging is recyclable, plastic is kept to the minimum the courier will tolerate, and we reuse clean shipping materials where we can.</p>

<h3>5. Tracking</h3>
<p>Every order gets tracking. You will receive an email with the number when the label is created — note that carriers often take 24–48 hours to show the first scan. If tracking has not updated in <strong>10 business days</strong> (domestic) or <strong>25 business days</strong> (international), contact us and we will open an investigation.</p>

<h3>6. Customs, duties and taxes</h3>
<p>International customers are responsible for any import duty, VAT or customs handling fee charged by their own country. These are not included in our prices and we have no way to predict or control them. We must declare the accurate value and cannot label orders as gifts. If a parcel is refused at customs and returned to us, we will refund the item value minus original and return shipping costs.</p>

<h3>7. Wrong address and failed delivery</h3>
<p>Please check your address at checkout. If you spot a mistake, email us within <strong>12 hours</strong> and we will fix it if the parcel has not shipped. Parcels returned to us because of an incorrect address, or because they went unclaimed, can be reshipped once you pay the new postage.</p>

<h3>8. Damaged, faulty or missing items</h3>
<p><strong>Contact us within 14 days of delivery</strong> with your order number and clear photographs of the item and the packaging. We will send a free replacement, or a full refund including shipping, at your choice. Do not discard damaged packaging until the claim is settled — the carrier may require it. This is on us, not on you.</p>

<h3>9. Returns and refunds — physical goods</h3>
<p>You may return most unused physical items within <strong>30 days of delivery</strong> for a refund of the item price.</p>
<ul>
<li>Items must be unused, unworn, unwashed and in original packaging.</li>
<li>Request a return first — email us for a return authorisation. Unauthorised returns can go missing.</li>
<li>Return postage is paid by you unless the item was faulty, damaged or incorrectly sent.</li>
<li>Refunds are issued to the original payment method within <strong>5–10 business days</strong> of the return arriving and passing inspection.</li>
<li>Original outbound shipping is refunded only where the item was faulty or wrongly sent.</li>
</ul>

<h4>Not returnable</h4>
<ul>
<li><strong>Original one-of-one artwork</strong>, unless it arrives damaged or is not as described.</li>
<li><strong>Custom, personalised or commissioned pieces.</strong></li>
<li><strong>Made-to-order apparel</strong>, unless faulty or misprinted — please use the size chart.</li>
<li><strong>Sealed vinyl or CDs that have been opened</strong>, unless faulty.</li>
<li>Items returned after 30 days, or damaged by the customer.</li>
</ul>

<h3>10. Refunds — digital goods</h3>
<p>Because Digital Goods are delivered instantly and cannot be returned, <strong>all digital sales are final</strong> once the file has been downloaded. We will always refund where:</p>
<ul>
<li>The file is corrupt, incomplete or unreadable and we cannot supply a working replacement.</li>
<li>You were charged twice for the same item.</li>
<li>You bought the wrong item and have not yet downloaded it.</li>
</ul>
<p>Consumers in jurisdictions with a statutory right of withdrawal for digital content keep that right; by downloading immediately you may be asked to acknowledge that the right ends once delivery begins.</p>

<h3>11. Cancellations</h3>
<p>Email us as soon as possible. If the order has not been dispatched we will cancel and refund in full. Once it has shipped, treat it as a return under section 9.</p>

<h3>12. Exchanges</h3>
<p>The fastest route is to return the original for a refund and place a new order, so your size or item is not sold out while the parcel is in transit. For faulty items we ship the replacement immediately at no cost.</p>

<h3>13. Lost parcels</h3>
<p>If a tracked parcel is confirmed lost by the carrier, we will replace it or refund it in full. Parcels marked as delivered but not received should be reported within <strong>7 days</strong>; we will help you open a carrier investigation, but we cannot be responsible for theft after confirmed delivery to the address you gave us.</p>

<h3>14. Contact</h3>
<p>Order problems: <strong>[orders@yourdomain.com]</strong><br>Everything else: <strong>[contact@yourdomain.com]</strong><br>We answer within <strong>2 business days</strong>. Include your order number and it will be faster.</p>
';
}
