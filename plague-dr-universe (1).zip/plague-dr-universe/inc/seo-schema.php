<?php
/**
 * SEO output: meta description, canonical, Open Graph, Twitter cards and
 * schema.org JSON-LD.
 *
 * All output is guarded so a dedicated SEO plugin (Yoast / Rank Math / SEOPress)
 * takes precedence and we never emit duplicate tags.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

/**
 * Is a third-party SEO plugin handling meta output?
 *
 * @return bool
 */
function pdu_seo_plugin_active() {
	return (
		defined( 'WPSEO_VERSION' ) ||
		class_exists( 'RankMath' ) ||
		defined( 'SEOPRESS_VERSION' ) ||
		class_exists( 'All_in_One_SEO_Pack' )
	);
}

/**
 * Best-effort description for the current view.
 *
 * @return string
 */
function pdu_meta_description() {
	if ( is_singular() ) {
		$post = get_queried_object();
		if ( $post instanceof WP_Post ) {
			$text = $post->post_excerpt ? $post->post_excerpt : wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
			$text = trim( preg_replace( '/\s+/', ' ', (string) $text ) );
			if ( $text ) {
				return wp_html_excerpt( $text, 155, '…' );
			}
		}
	}

	if ( is_category() || is_tag() || is_tax() ) {
		$desc = term_description();
		if ( $desc ) {
			return wp_html_excerpt( wp_strip_all_tags( $desc ), 155, '…' );
		}
	}

	if ( is_post_type_archive() ) {
		$obj = get_queried_object();
		if ( $obj && ! empty( $obj->description ) ) {
			return wp_html_excerpt( wp_strip_all_tags( $obj->description ), 155, '…' );
		}
	}

	$tagline = get_bloginfo( 'description' );
	return $tagline
		? $tagline
		: __( 'Dark fantasy graphic novels, original artwork, metal and ambient soundtracks, and limited merch from The Plague Dr Universe.', 'plague-dr-universe' );
}

/**
 * Representative image URL for the current view.
 *
 * @return string
 */
function pdu_share_image() {
	if ( is_singular() && has_post_thumbnail() ) {
		$src = wp_get_attachment_image_src( get_post_thumbnail_id(), 'pdu-hero' );
		if ( $src ) {
			return $src[0];
		}
	}
	$custom = get_theme_mod( 'pdu_share_image', '' );
	return $custom ? $custom : pdu_img( 'plague-doctor-first-ave.jpg' );
}

/**
 * Emit meta description, canonical, Open Graph and Twitter card tags.
 *
 * @return void
 */
function pdu_meta_tags() {
	if ( pdu_seo_plugin_active() ) {
		return;
	}

	$desc  = pdu_meta_description();
	$image = pdu_share_image();
	$title = wp_get_document_title();

	$canonical = '';
	if ( is_singular() ) {
		$canonical = get_permalink();
	} elseif ( is_front_page() ) {
		$canonical = home_url( '/' );
	} elseif ( is_post_type_archive() ) {
		$canonical = get_post_type_archive_link( get_post_type() );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$term = get_queried_object();
		if ( $term instanceof WP_Term ) {
			$link = get_term_link( $term );
			if ( ! is_wp_error( $link ) ) {
				$canonical = $link;
			}
		}
	}

	echo "\n<!-- The Plague Dr Universe — SEO -->\n";
	printf( '<meta name="description" content="%s">' . "\n", esc_attr( $desc ) );

	if ( $canonical ) {
		printf( '<link rel="canonical" href="%s">' . "\n", esc_url( $canonical ) );
	}

	printf( '<meta property="og:site_name" content="%s">' . "\n", esc_attr( get_bloginfo( 'name' ) ) );
	printf( '<meta property="og:type" content="%s">' . "\n", esc_attr( is_singular( 'post' ) ? 'article' : 'website' ) );
	printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
	printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $desc ) );
	printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $image ) );
	printf( '<meta property="og:image:alt" content="%s">' . "\n", esc_attr__( 'The Plague Doctor standing on a rain-soaked Seattle street corner', 'plague-dr-universe' ) );
	if ( $canonical ) {
		printf( '<meta property="og:url" content="%s">' . "\n", esc_url( $canonical ) );
	}
	printf( '<meta property="og:locale" content="%s">' . "\n", esc_attr( get_locale() ) );

	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	printf( '<meta name="twitter:title" content="%s">' . "\n", esc_attr( $title ) );
	printf( '<meta name="twitter:description" content="%s">' . "\n", esc_attr( $desc ) );
	printf( '<meta name="twitter:image" content="%s">' . "\n", esc_url( $image ) );

	$handle = get_theme_mod( 'pdu_twitter_handle', '' );
	if ( $handle ) {
		printf( '<meta name="twitter:creator" content="@%s">' . "\n", esc_attr( ltrim( $handle, '@' ) ) );
	}

	if ( is_singular( 'post' ) ) {
		printf( '<meta property="article:published_time" content="%s">' . "\n", esc_attr( get_the_date( DATE_W3C ) ) );
		printf( '<meta property="article:modified_time" content="%s">' . "\n", esc_attr( get_the_modified_date( DATE_W3C ) ) );
	}
}
add_action( 'wp_head', 'pdu_meta_tags', 2 );

/**
 * Structured data graph: Organization, WebSite (+ SearchAction), and the
 * appropriate node for the current single view.
 *
 * @return void
 */
function pdu_json_ld() {
	$site_url = home_url( '/' );
	$name     = get_bloginfo( 'name' );

	$graph = array();

	// --- Organization -----------------------------------------------------
	$sameas = array();
	foreach ( array( 'instagram', 'youtube', 'bandcamp', 'spotify', 'tiktok', 'x' ) as $network ) {
		$url = get_theme_mod( 'pdu_social_' . $network, '' );
		if ( $url ) {
			$sameas[] = esc_url_raw( $url );
		}
	}

	$org = array(
		'@type'       => 'Organization',
		'@id'         => $site_url . '#organization',
		'name'        => $name,
		'url'         => $site_url,
		'description' => pdu_meta_description(),
		'logo'        => array(
			'@type' => 'ImageObject',
			'url'   => pdu_share_image(),
		),
	);
	if ( $sameas ) {
		$org['sameAs'] = $sameas;
	}
	$email = get_theme_mod( 'pdu_email', '' );
	if ( $email ) {
		$org['contactPoint'] = array(
			array(
				'@type'       => 'ContactPoint',
				'contactType' => 'customer support',
				'email'       => $email,
			),
		);
	}
	$graph[] = $org;

	// --- WebSite ----------------------------------------------------------
	$graph[] = array(
		'@type'           => 'WebSite',
		'@id'             => $site_url . '#website',
		'url'             => $site_url,
		'name'            => $name,
		'description'     => get_bloginfo( 'description' ),
		'publisher'       => array( '@id' => $site_url . '#organization' ),
		'inLanguage'      => get_bloginfo( 'language' ),
		'potentialAction' => array(
			'@type'       => 'SearchAction',
			'target'      => array(
				'@type'       => 'EntryPoint',
				'urlTemplate' => $site_url . '?s={search_term_string}',
			),
			'query-input' => 'required name=search_term_string',
		),
	);

	// --- Current single view ----------------------------------------------
	if ( is_singular() && ! is_front_page() ) {
		$post_id = get_the_ID();
		$img     = has_post_thumbnail() ? wp_get_attachment_image_url( get_post_thumbnail_id(), 'pdu-hero' ) : pdu_share_image();

		$common = array(
			'@id'           => get_permalink() . '#item',
			'name'          => wp_strip_all_tags( get_the_title() ),
			'headline'      => wp_strip_all_tags( get_the_title() ),
			'url'           => get_permalink(),
			'image'         => $img,
			'datePublished' => get_the_date( DATE_W3C ),
			'dateModified'  => get_the_modified_date( DATE_W3C ),
			'description'   => pdu_meta_description(),
			'author'        => array(
				'@type' => 'Person',
				'name'  => get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) ),
			),
			'publisher'     => array( '@id' => $site_url . '#organization' ),
		);

		switch ( get_post_type() ) {
			case 'pdu_track':
				$graph[] = array_merge(
					$common,
					array(
						'@type'    => 'MusicRecording',
						'byArtist' => array( '@type' => 'MusicGroup', 'name' => $name ),
						'duration' => pdu_iso_duration( (string) get_post_meta( $post_id, 'pdu_duration', true ) ),
						'inAlbum'  => array(
							'@type' => 'MusicAlbum',
							'name'  => (string) get_post_meta( $post_id, 'pdu_album', true ),
						),
					)
				);
				break;

			case 'pdu_video':
				$graph[] = array_merge(
					$common,
					array(
						'@type'        => 'VideoObject',
						'thumbnailUrl' => $img,
						'uploadDate'   => get_the_date( DATE_W3C ),
						'duration'     => pdu_iso_duration( (string) get_post_meta( $post_id, 'pdu_duration', true ) ),
						'contentUrl'   => (string) get_post_meta( $post_id, 'pdu_video_url', true ),
					)
				);
				break;

			case 'pdu_chapter':
				$graph[] = array_merge(
					$common,
					array(
						'@type'           => 'Book',
						'bookFormat'      => 'https://schema.org/GraphicNovel',
						'numberOfPages'   => (int) get_post_meta( $post_id, 'pdu_page_count', true ),
						'isPartOf'        => array( '@type' => 'BookSeries', 'name' => $name ),
					)
				);
				break;

			case 'pdu_artwork':
				$graph[] = array_merge(
					$common,
					array(
						'@type'       => 'VisualArtwork',
						'artform'     => (string) get_post_meta( $post_id, 'pdu_dimensions', true ),
						'dateCreated' => (string) get_post_meta( $post_id, 'pdu_year', true ),
						'creator'     => array( '@type' => 'Person', 'name' => $name ),
					)
				);
				break;

			case 'post':
				$graph[] = array_merge( $common, array( '@type' => 'BlogPosting' ) );
				break;

			case 'page':
				// Products are described by WooCommerce's own structured data.
				$graph[] = array_merge( $common, array( '@type' => 'WebPage' ) );
				break;
		}
	}

	$payload = array(
		'@context' => 'https://schema.org',
		'@graph'   => $graph,
	);

	printf(
		'<script type="application/ld+json">%s</script>' . "\n",
		wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
	);
}
add_action( 'wp_head', 'pdu_json_ld', 20 );

/**
 * Convert "4:12" or "1:02:30" to an ISO-8601 duration.
 *
 * @param string $human Human readable duration.
 * @return string
 */
function pdu_iso_duration( $human ) {
	$human = trim( $human );
	if ( ! $human || ! preg_match( '/^\d{1,2}(:\d{2}){1,2}$/', $human ) ) {
		return '';
	}
	$parts = array_reverse( array_map( 'intval', explode( ':', $human ) ) );
	$sec   = $parts[0] ?? 0;
	$min   = $parts[1] ?? 0;
	$hour  = $parts[2] ?? 0;

	return sprintf( 'PT%s%s%s', $hour ? $hour . 'H' : '', $min ? $min . 'M' : '', $sec ? $sec . 'S' : '' );
}

/**
 * Output BreadcrumbList JSON-LD on interior pages.
 *
 * @return void
 */
function pdu_breadcrumb_schema() {
	if ( is_front_page() || pdu_seo_plugin_active() ) {
		return;
	}

	$items = array(
		array(
			'@type'    => 'ListItem',
			'position' => 1,
			'name'     => __( 'Home', 'plague-dr-universe' ),
			'item'     => home_url( '/' ),
		),
	);

	if ( is_singular() ) {
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => 2,
			'name'     => wp_strip_all_tags( get_the_title() ),
			'item'     => get_permalink(),
		);
	} elseif ( is_post_type_archive() ) {
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => 2,
			'name'     => post_type_archive_title( '', false ),
			'item'     => get_post_type_archive_link( get_post_type() ),
		);
	}

	if ( count( $items ) < 2 ) {
		return;
	}

	printf(
		'<script type="application/ld+json">%s</script>' . "\n",
		wp_json_encode(
			array(
				'@context'        => 'https://schema.org',
				'@type'           => 'BreadcrumbList',
				'itemListElement' => $items,
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		)
	);
}
add_action( 'wp_head', 'pdu_breadcrumb_schema', 21 );
