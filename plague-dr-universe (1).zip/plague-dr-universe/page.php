<?php
/**
 * Standard page template.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="<?php echo esc_attr( pdu_content_offset_class() ); ?>">
	<?php
	while ( have_posts() ) :
		the_post();

		get_template_part(
			'template-parts/components/page-header',
			null,
			array(
				'title' => get_the_title(),
				'lede'  => has_excerpt() ? get_the_excerpt() : '',
				'image' => has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'pdu-hero' ) : '',
			)
		);
		?>

		<div class="container section-tight">
			<div class="mx-auto max-w-3xl prose-pdu">
				<?php
				pdu_form_notice( 'sent' );
				pdu_form_notice( 'subscribed' );
				the_content();

				wp_link_pages(
					array(
						'before' => '<nav class="pagination mt-10 flex flex-wrap gap-2" aria-label="' . esc_attr__( 'Page sections', 'plague-dr-universe' ) . '">',
						'after'  => '</nav>',
					)
				);
				?>
			</div>
		</div>

		<?php
		if ( comments_open() || get_comments_number() ) {
			echo '<div class="container pb-20">';
			comments_template();
			echo '</div>';
		}
	endwhile;
	?>
</div>

<?php
get_footer();
