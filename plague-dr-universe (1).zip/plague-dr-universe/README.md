# The Plague Dr Universe — WordPress Theme

A dark, gritty, cinematic WordPress theme and WooCommerce storefront for **The Plague Dr Universe**: a hub that showcases and sells original artwork, music, videos, graphic novels and merchandise from a single rain-soaked Seattle canon.

Classic PHP theme (not FSE) built on Tailwind CSS, with `theme.json` layered on top so the block editor inherits the same palette, fonts and spacing.

---

## Quick start

```bash
npm install     # dev dependencies (Tailwind, PostCSS, Fontsource)
npm run build   # compile assets/src/*.css -> assets/css/*.css
npm run dev     # watch mode
```

1. Copy this folder into `wp-content/themes/plague-dr-universe`.
2. **Appearance → Themes → Activate.**
3. **Appearance → Import Demo Content** — creates every page, menu, taxonomy term and sample chapter/track/artwork/video described below.
4. **Settings → Permalinks** — click Save once to flush rewrite rules (required for the custom post types).
5. **Appearance → Customize** — set the hero copy, social links, contact email and announcement bar.

`assets/css/` is committed, so the theme works the moment it is activated — no build step required on the server.

---

## File tree

```
plague-dr-universe/
├── style.css                       Theme header + .no-js guard (real styles compile to assets/css)
├── functions.php                   Constants, setup, asset loading, perf cleanup, includes
├── header.php                      <head>, skip link, sticky header, search panel, mobile drawer
├── footer.php                      Newsletter, marquee, footer columns, shared <audio> player
├── theme.json                      Editor palette, fonts, spacing, custom template registry
├── screenshot.png                  Theme preview (1200×900)
│
├── front-page.php                  Homepage — composes the nine home template parts
├── index.php  singular.php  single.php  page.php
├── archive.php  search.php  searchform.php  404.php  comments.php
│
├── page-templates/
│   ├── template-universe.php       The Universe — immersive lore hub
│   ├── template-media.php          Media — audio, video, art & comic galleries
│   └── template-contact.php        Contact & community
│
├── template-parts/
│   ├── home/                       hero, pillars, chapters, gallery, soundtracks,
│   │                               videos, store, lore, dispatches
│   ├── components/page-header.php  Reusable page header band (title, lede, image)
│   └── content/                    single, card, none
│
├── inc/
│   ├── template-tags.php           pdu_img, pdu_icon, pdu_audio_track, pdu_breadcrumbs…
│   ├── template-functions.php      Body classes, form handlers, avatar privacy, cart AJAX
│   ├── post-types.php              CPTs + meta boxes
│   ├── enquiries.php               Private storage for contact enquiries & subscribers
│   ├── customizer.php              Hero, announcement, social, contact settings
│   ├── seo-schema.php              Meta description, Open Graph, Twitter, JSON-LD
│   ├── nav-walker.php              PDU_Walker_Nav_Menu (accessible dropdowns)
│   ├── blocks.php                  Editor palette, block patterns, core pattern cleanup
│   ├── woocommerce.php             Store integration (hook + CSS based, no template overrides)
│   ├── demo-content.php            Appearance → Import Demo Content
│   └── demo-copy.php               Privacy, Terms, Shipping & Refund copy
│
└── assets/
    ├── src/{main,editor}.css       Tailwind sources
    ├── css/{main,editor}.css       Compiled output (committed)
    ├── js/main.js                  8 vanilla modules, no jQuery, deferred
    ├── fonts/                      Self-hosted Oswald + Inter (woff2, 400–700)
    └── images/                     Project artwork + local default avatar
```

---

## Design system

| Token | Value | Use |
| --- | --- | --- |
| `ink-900` | `#050507` | Page background (void black) |
| `ink-800` | `#101015` | Cards, raised panels (charred coal) |
| `ink-600` | `#282833` | Borders, dividers (ash grey) |
| `blood-500` | `#b3121b` | Primary accent, CTAs, sale flashes |
| `amber-400` | `#c8912a` | Secondary accent, links, eyebrows |
| `siren-500` | `#1f6fd0` | Cold light, emergency wash |
| `bone-50` | `#faf8f4` | Body text, headings |

**Typography** — Oswald (bold, condensed, uppercase) for display; Inter for body. Both self-hosted as woff2 and preloaded; no Google Fonts request.

**Motion** — every transition respects `prefers-reduced-motion`.

---

## Accessibility

Verified across all templates:

- Exactly one `<h1>` per page, no skipped heading levels
- Skip link to `#main-content`; `<header>`, `<nav>`, `<main>`, `<footer>` landmarks
- Every image carries an `alt` attribute; decorative images use `alt=""`
- All links, buttons and inputs have accessible names (visible text, `aria-label`, or `.screen-reader-text`)
- Nav, search panel, drawer and audio player are keyboard operable with managed focus and `aria-expanded`
- Visible focus rings; contrast meets WCAG AA against the dark palette
- Forms use real `<label>` elements and announce status via `role="status"`

---

## Performance & privacy

- **Zero third-party requests on the front end.** Fonts are self-hosted and the theme ships a local default avatar, so Gravatar never sees a visitor's IP — matching the promise in the privacy policy.
- One stylesheet and one deferred, jQuery-free script for logged-out visitors.
- Emoji script, embeds, and core pattern bloat removed; `block-library` retained because core blocks are used in page content.
- Images are downscaled and progressive; templates request registered sizes (`pdu-hero`, `pdu-card`, `pdu-panel`, `pdu-tile`, `pdu-wide`).
- Asset versions are file-mtime based for safe cache busting.

---

## Content model

**Custom post types** — `pdu_chapter` (graphic novel), `pdu_artwork`, `pdu_track`, `pdu_video`.

**Meta keys** — `pdu_duration`, `pdu_album`, `pdu_audio_url`, `pdu_video_url`, `pdu_chapter_number`, `pdu_page_count`, `pdu_dimensions`, `pdu_year`, `pdu_buy_url`, `pdu_read_url`, `pdu_print_url`.

**Private stores** (Tools menu) — `pdu_enquiry` and `pdu_subscriber`. Contact and newsletter submissions are written to the database *in addition to* being emailed, so a `wp_mail()` failure never loses a message. Subscribers export to CSV; both forms are honeypot-protected and rate limited.

**Pages** — `home`, `the-universe`, `media`, `contact`, `dispatches` (posts), `privacy-policy`, `terms-conditions`, `shipping-refunds`.

**Menus** — `primary`, `footer`, `legal`, `social`.

---

## WooCommerce

Integration lives entirely in `inc/woocommerce.php` using hooks and CSS rather than copied template files, so it will not break when WooCommerce updates its markup. Everything is wrapped in `class_exists( 'WooCommerce' )` / `function_exists()` guards — **the theme runs perfectly with the plugin inactive.**

Includes: theme support with gallery zoom/lightbox/slider, custom shop wrappers with a page-header band, a category rail with icons, 4-up loops, per-product-type add-to-cart labels, custom sale flash, trust badges, an empty-cart message, a licence tab for downloadables, and a live header cart badge (AJAX + `add_to_cart_fragments`).

Expected product categories: `graphic-novels`, `original-artwork`, `music-albums`, `apparel-merch`.

---

## Customizer options

Hero (eyebrow, title, text, two CTAs, background image) · announcement bar · social links (Instagram, YouTube, Bandcamp, Spotify, TikTok, X) · Twitter handle · contact email · location · press contact · social share image.

---

## Verification status

Tested against **WordPress 6.7.7 / PHP 8.2**:

- 40 PHP files, **0 syntax errors**
- Every page, archive, single, search and 404 route returns the correct status with **0 PHP fatals, warnings or notices**
- `theme.json` palette, custom templates and pattern category confirmed loading in the block editor
- Contact and newsletter forms verified for success, invalid input, honeypot, nonce failure, mail failure, and duplicate handling
- Admin screens (themes, customizer, menus, widgets, editor, CPT lists) all load clean

> The legal pages are thorough working drafts, not legal advice — have a lawyer review them before launch.

---

## Credits

Fonts: [Oswald](https://fonts.google.com/specimen/Oswald) and [Inter](https://fonts.google.com/specimen/Inter), SIL Open Font License 1.1, self-hosted via Fontsource.

Theme code released under GPL-2.0-or-later. Artwork and written canon © The Plague Dr Universe.
