<?php
/**
 * Search form.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

$pdu_sf_id = 'pdu-search-' . wp_unique_id();
?>

<form role="search" method="get" class="flex gap-2" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $pdu_sf_id ); ?>">
		<?php esc_html_e( 'Search the universe', 'plague-dr-universe' ); ?>
	</label>

	<input type="search"
			id="<?php echo esc_attr( $pdu_sf_id ); ?>"
			class="flex-1"
			placeholder="<?php esc_attr_e( 'Search chapters, tracks, artwork, store…', 'plague-dr-universe' ); ?>"
			value="<?php echo esc_attr( get_search_query() ); ?>"
			name="s">

	<button type="submit" class="btn btn-primary shrink-0">
		<?php pdu_the_icon( 'search', 16 ); ?>
		<span class="screen-reader-text"><?php esc_html_e( 'Search', 'plague-dr-universe' ); ?></span>
	</button>
</form>
