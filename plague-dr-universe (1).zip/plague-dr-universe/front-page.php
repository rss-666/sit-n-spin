<?php
/**
 * Homepage.
 *
 * Section order mirrors the brief:
 *   hero → trust strip → featured chapters → artwork gallery → soundtracks
 *   → video releases → store grid → lore teaser → dispatches
 *
 * Every section is a modular template part so they can be reordered, removed
 * or reused inside page templates without duplicating markup.
 *
 * @package PlagueDrUniverse
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<?php get_template_part( 'template-parts/home/hero' ); ?>
<?php get_template_part( 'template-parts/home/pillars' ); ?>
<?php get_template_part( 'template-parts/home/chapters' ); ?>
<?php get_template_part( 'template-parts/home/gallery' ); ?>
<?php get_template_part( 'template-parts/home/soundtracks' ); ?>
<?php get_template_part( 'template-parts/home/videos' ); ?>
<?php get_template_part( 'template-parts/home/store' ); ?>
<?php get_template_part( 'template-parts/home/lore' ); ?>
<?php get_template_part( 'template-parts/home/dispatches' ); ?>

<?php
get_footer();
